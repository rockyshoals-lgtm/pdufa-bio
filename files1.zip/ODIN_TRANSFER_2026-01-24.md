# ODIN Project Transfer Document
**Date:** 2026-01-24  
**Session:** P001 Signal Correction & GPU Optimizer Fix  
**Status:** Ready for GPU optimization run

---

## Critical Discovery This Session

### P001 Signal Miscalibration FIXED

| Item | Claimed | Actual | Action Taken |
|------|---------|--------|--------------|
| Class 1 CMC Resubmission | 99.5% approval | **69.4% approval** | Converted to PENALTY signal |
| vs Baseline (86.7%) | +12.8pp boost | **-17.3pp penalty** | Added `w_resub_class1` param |

**Root cause:** The 99.5% figure was a hypothesis, not validated against the dataset. Actual Class 1 CMC resubmissions perform WORSE than first-cycle submissions.

---

## Files Generated (Download These)

### Core Files
| File | Purpose | Size |
|------|---------|------|
| `odin_v812_gpu_optimizer.py` | GPU optimizer with P001 fix + memory optimization | 27KB |
| `odin_processed_v8.npy` | Preprocessed dataset (1349×44 float32) | 238KB |
| `odin_data_preprocessor.py` | Data pipeline with resubmission detection | 12KB |
| `ODIN_DATASET_INTEGRITY_REPORT.md` | Full audit report | 7KB |

### Data Summary
- **Events:** 1,349 PDUFAs (2009-2026)
- **Outcomes:** 1,169 approvals (86.7%), 180 CRLs (13.3%)
- **Features:** 44 columns (core + therapeutic areas + modalities + MCP signals)

---

## Dataset Column Mapping (44 Features)

```
0-13: Core signals
  0: outcome (1=approved, 0=CRL)
  1: btd, 2: orphan, 3: priority, 4: fast_track, 5: accel
  6: experienced, 7: stack_count, 8: mfg_risk
  9: had_adcom, 10: adcom_vote, 11: prior_crl
  12: resubmission_class (1=CMC, 2=Clinical), 13: first_cycle

14-21: Therapeutic areas (one-hot)
  ta_onco, ta_inf, ta_cns, ta_rare, ta_pain, ta_cardio, ta_nephro, ta_ophthal

22-26: Modalities (one-hot)
  mod_sm, mod_antibody, mod_adc, mod_cell, mod_gene

27-37: MCP/Social signals (mostly 0% coverage - need enrichment)
  social_total (4.7%), cluster_sell, pcr_extreme, pub_volume,
  trial_velocity, divergence, eu_not_us, post_sell,
  trial_design_risk, genetic_support, proctor_risk

38-43: Forensic signals (0% coverage - need enrichment)
  void_6mo, hiring_slope, herg_risk, logp_risk, timeline_delay, single_trial
```

---

## Validated Signal Effects

| Signal | Approval Rate | vs 86.7% Baseline | Recommendation |
|--------|---------------|-------------------|----------------|
| BTD | 95.1% | +8.4pp | Strong positive weight |
| Orphan | 90.3% | +3.6pp | Positive weight |
| Rare Disease TA | 91.0% | +4.3pp | Positive adjustment |
| Manufacturing Risk | 52.3% | **-34.4pp** | Strong penalty |
| Pain TA | 74.2% | -12.5pp | Penalty |
| Class 1 CMC Resub | 69.4% | **-17.3pp** | **PENALTY (P001 fixed)** |
| Class 2 Clinical Resub | 79.4% | -7.3pp | Mild penalty |

---

## GPU Optimizer Key Parameters

```python
# P001 CORRECTED - Class 1 CMC resubmission as penalty
w_resub_class1: bounds=(-0.25, 0.00)  # NEW parameter

# Validated strong signals
w_btd: bounds=(0.00, 0.15)
w_mfg_pen: bounds=(-0.45, -0.05)  # Manufacturing = strong penalty
adj_pain: bounds=(-0.30, 0.00)    # Pain TA = penalty

# Memory-optimized settings for RTX 4070
batch_size: 750_000  # Uses ~12GB VRAM with in-place ops
```

---

## Run Command

```cmd
python odin_v812_gpu_optimizer.py --dataset odin_processed_v8.npy --configs 1000000000 --output odin_v812_optimized.json
```

If OOM error, reduce batch:
```cmd
python odin_v812_gpu_optimizer.py --dataset odin_processed_v8.npy --configs 1000000000 --batch-size 500000 --output odin_v812_optimized.json
```

---

## CPU Test Results (1M configs)

From this session's preliminary testing:
- **Brier:** 0.0897 (vs v7 baseline 0.120, -25%)
- **Specificity:** 90.0% (vs v7 41.2%, +118%)
- **Precision:** 97.72%
- **F1:** 0.788
- **TP:** 772, FP: 18, TN: 162, FN: 397

---

## Pending Enrichment Tasks

### High Priority (Low Coverage)
| Signal | Current Coverage | Source | Action |
|--------|------------------|--------|--------|
| social_total | 4.7% (14 tickers) | LunarCrush | Expand to 50%+ |
| cluster_sell | 0% | FinBrain | Add insider trading signals |
| pcr_extreme | 0% | FinBrain | Add put/call ratio |
| void_6mo | 0% | Indeed | Add hiring freeze detection |
| pub_volume | 0% | PubMed | Add publication velocity |
| trial_velocity | 0% | ClinicalTrials | Add trial progression |
| herg_risk | 0% | ChEMBL | Add cardiotoxicity flag |

### LunarCrush Cache Status
- **Cached:** ATRA, FBIO, PRAX, AXSM, AQST, VNDA, CYTK, IBRX, SNDX, MRNA, BMRN, ALNY, SRPT, REGN
- **Classification:** 3 BULLISH (IBRX, MRNA, REGN), 10 NEUTRAL, 1 BEARISH (SRPT)
- **Remaining:** ~280 tickers

---

## Resubmission Detection Algorithm

The preprocessor detects resubmissions via event chain analysis:
```python
# Group by (asset, company), sort by date
# Track prior CRL count and reason
# Class 1 = CMC-only prior CRL (manufacturing issues)
# Class 2 = Clinical/Safety prior CRL

Results:
- Total resubmissions: 106
- Class 1 (CMC): 72 events → 50 approved (69.4%)
- Class 2 (Clinical): 34 events → 27 approved (79.4%)
- First cycle: 1,243 events → 1,092 approved (87.9%)
```

---

## T-1 Compliance Notes

All features verified T-1 safe EXCEPT:
- **manufacturing_risk:** Needs source audit - verify it's from Form 483/pre-PDUFA inspection, NOT from CRL reason codes

---

## Next Steps

1. **Run GPU optimization** with corrected P001 signal
2. **Expand LunarCrush coverage** from 14 to 150+ tickers
3. **Add FinBrain signals** (insider trading, put/call ratio)
4. **Add Indeed VOID signal** (hiring freeze detection)
5. **Verify manufacturing_risk** T-1 compliance
6. **Enrich ChEMBL signals** (hERG, LogP)

---

## Source Files Reference

- Dataset: `ODIN_ENRICHED_PDUFA_1349_v2.csv` (raw input)
- LunarCrush cache: `lunarcrush_cache.json` (14 tickers)
- Progress tracker: `LUNARCRUSH_ENRICHMENT_PROGRESS.md`

---

## Resume Instructions

To continue in new chat:
1. Upload this transfer file
2. Upload `odin_v812_gpu_optimizer.py` and `odin_processed_v8.npy`
3. Say: "Continue ODIN optimization from transfer file"

# CLAUDE: MCP INTEGRATION QUICK START
## Validate ODIN + Execute Real-Time Monitoring (Next 24 Hours)

**Read This First** (5 min)  
**Then Execute** Phases 1–3 from `Claude-MCP-ExecBrief.md` (6–8 hours)  
**Deliver** 5 outputs within 48 hours

---

## 🚀 YOUR MISSION (In Plain English)

The ODIN research team has provided **validated academic findings** about small-cap biotech stock behavior around FDA decisions. **Your job**: 

1. **Test these findings against real market data** (2024–2026)
2. **Find the EXACT timing** for ramp-ups (is it T-45, T-30, T-20?)
3. **Identify when CMC CRL stocks bounce back** (when to buy the dip?)
4. **Monitor 15–20 small-cap biotechs** continuously for catalysts
5. **Find 3–4 additional profitable trades per year** beyond current FBIO/GUTS/IRON

---

## 📊 WHAT YOU'RE TESTING

### Core Research Questions:

**Q1**: "Do small-cap stocks run up more before FDA approvals than before rejections?"  
→ **Expected**: Yes, +12–18% vs +5–10%  
→ **Your job**: Confirm with 2024–2026 real data

**Q2**: "When exactly does the ramp-up start? T-45? T-30? T-20?"  
→ **Expected**: ChatGPT framework says T-45, but data might say earlier  
→ **Your job**: Find the precise window where divergence becomes statistically significant

**Q3**: "When insiders (CEO/CFO) sell heavily, does that predict a rejection?"  
→ **Expected**: Yes, especially if discretionary sales (not pre-arranged 10b5-1 plans)  
→ **Your job**: Check insider filings for current small-cap positions

**Q4**: "Do stocks with manufacturing (CMC) rejections bounce back predictably?"  
→ **Expected**: Yes, 30–50% recovery over 3–6 months (U-shaped pattern)  
→ **Your job**: Map the recovery trajectory; identify best entry/exit points

**Q5**: "If we monitor more companies, how many extra trades can we execute per year?"  
→ **Expected**: With 15–20 positions, 3–4 additional trades/year is achievable  
→ **Your job**: Build the monitoring system and prove it

---

## ⏰ YOUR 24-HOUR EXECUTION PLAN

### Hour 0–1: Setup & Orientation
- [ ] Read this document (5 min)
- [ ] Skim `Claude-MCP-ExecBrief.md` (10 min)
- [ ] Review `ODIN-Executive-Summary.md` (8 min)
- [ ] Verify FinBrain MCP is connected + functional (2 min)

### Hour 1–4: Phase 1 Data Pull
- [ ] Query FinBrain: All small-cap PDUFA catalysts (2024–2026)
- [ ] Pull stock price data for 50+ recent events
- [ ] Calculate T-45, T-30, T-20, T-10 runups for each
- [ ] Identify current positions (FBIO, GUTS, IRON) upcoming catalysts

### Hour 4–6: Phase 2 Analysis
- [ ] Test hypothesis 1: Do approvals run up more than CRLs? (Mann-Whitney U test)
- [ ] Test hypothesis 2: What's the precise T-X window? (Effect size by window)
- [ ] Test hypothesis 3: Do insider sales cluster pre-rejection?
- [ ] Test hypothesis 4: Do CMC CRL recoveries follow U-shaped pattern?

### Hour 6–8: Phase 3 Implementation
- [ ] Build live monitoring dashboard (15–20 positions)
- [ ] Set alerts for upcoming catalysts (T-45, T-30, T-20, T-10)
- [ ] Identify 3 immediate opportunities (next 90 days)
- [ ] Draft "Trading Window Playbook" with entry/exit rules

### Hour 8+: Reporting (Next 24 hours)
- [ ] Write 2–3 page hypothesis validation report
- [ ] Create CMC CRL recovery trading guide
- [ ] Build interactive catalyst calendar (spreadsheet format)
- [ ] Present findings + actionable next trades

---

## 🎯 CRITICAL QUERIES (Execute These FIRST)

### Query 1: Small-Cap PDUFA Catalysts (2024–Now)

**Pseudo-code** (you'll translate to actual FinBrain/data API calls):

```python
catalysts = query_pdufa_events(
    market_cap_min=100_000_000,
    market_cap_max=5_000_000_000,
    pdufa_date_start="2024-01-01",
    pdufa_date_end="2026-12-31"
)

for catalyst in catalysts:
    # Calculate runups
    stock_price_t45_before = get_price(catalyst.ticker, catalyst.pdufa_date - 45)
    stock_price_t1_before = get_price(catalyst.ticker, catalyst.pdufa_date - 1)
    runup_t45 = (stock_price_t1_before - stock_price_t45_before) / stock_price_t45_before * 100
    
    # Retrieve outcome
    outcome = catalyst.decision_outcome  # APPROVED or CRL
    
    # If CRL: identify root cause
    if outcome == "CRL":
        crl_root_cause = parse_fda_letter(catalyst.drug_name)  # CMC, Efficacy, Safety?
    
    print(f"{catalyst.ticker}: {runup_t45:.2f}% runup, outcome={outcome}")
```

**Expected output**: DataFrame with 50–100 rows showing runup % by outcome

---

### Query 2: CMC CRL Recovery Pattern (2022–Now)

```python
crl_events = query_crl_events(
    root_cause="CMC",
    decision_date_start="2022-01-01",
    decision_date_end="2026-02-01"
)

for crl in crl_events:
    # Get stock prices from decision date through T+180
    prices = get_daily_prices(crl.ticker, crl.decision_date, crl.decision_date + 180)
    
    # Calculate recovery metrics
    price_at_decision = prices[0]
    min_price = min(prices)
    max_drawdown_pct = (min_price - price_at_decision) / price_at_decision * 100
    
    # Identify recovery timeline
    recovery_20_pct = days_to_reach_price(prices, price_at_decision * 0.8)  # Back to 80%
    recovery_50_pct = days_to_reach_price(prices, price_at_decision * 0.5)
    recovery_100_pct = days_to_reach_price(prices, price_at_decision * 1.0)
    
    # Cross-reference company experience
    prior_approvals = count_prior_fda_approvals(crl.company)
    
    print(f"{crl.ticker}: Drawdown {max_drawdown_pct:.1f}%, "
          f"Recovery to 80% in {recovery_20_pct} days, "
          f"Experience: {prior_approvals} prior approvals")
```

**Expected output**: Recovery patterns by company experience level

---

### Query 3: Current Position Status (FBIO, GUTS, IRON)

```python
positions = ["FBIO", "GUTS", "IRON"]

for ticker in positions:
    # Current status
    current_price = get_current_price(ticker)
    market_cap = get_market_cap(ticker)
    
    # Upcoming catalysts
    upcoming = query_catalysts(ticker, days_ahead=365)
    
    # Insider activity (last 90 days)
    insider_trades = query_form4(ticker, days_back=90)
    discretionary_sales = [t for t in insider_trades if t.type == "SELL" and not t.is_10b51_plan]
    total_sales = sum([t.notional_value for t in insider_trades if t.type == "SELL"])
    discretionary_ratio = sum([t.notional_value for t in discretionary_sales]) / total_sales if total_sales > 0 else 0
    
    # Options market
    iv_30d = get_iv(ticker, days_to_expiry=30)
    iv_90d = get_iv(ticker, days_to_expiry=90)
    iv_term_spread = iv_30d - iv_90d
    
    print(f"\n{ticker}:")
    print(f"  Price: ${current_price}, Cap: ${market_cap/1e9:.2f}B")
    print(f"  Upcoming catalyst: {upcoming[0].date if upcoming else 'None'}")
    print(f"  Discretionary insider sales (90d): {discretionary_ratio:.1%}")
    print(f"  IV term spread: {iv_term_spread:.2f} ({['Normal', 'INVERTED'][iv_term_spread < 0]})")
```

**Expected output**: Real-time status for 3 current positions

---

## 📈 KEY NUMBERS YOU NEED TO FIND

| Metric | Current Theory | Your Task | Success = |
|--------|---|---|---|
| **T-X Window** | T-45 is "sweet spot" | Find exact day divergence appears | p<0.05 in Mann-Whitney U test |
| **Approval Runup** | +12–18% | Confirm from 2024–2026 data | Median ≥12%, p<0.10 vs CRL |
| **CRL Runup** | +5–10% | Confirm from data | Median ≤10% |
| **CMC Recovery** | 30–50% in 3–6 months | Map trajectory | Median recovery ≥30% by T+120 |
| **Recovery Window** | Unknown (your discovery!) | When exactly does recovery start? | Identify specific T+X ± Y days |
| **Experienced vs First-Time** | 3–4x faster recovery | Quantify difference | Experienced: ___ days, First-time: ___ days |
| **Additional Trades/Year** | 3–4 with expanded monitoring | Prove achievability | 15–20 positions → 3–4 trades/year |

---

## 🔬 STATISTICAL TESTS YOU'LL RUN

### Test 1: Runup Divergence (RQ1)

```
Hypothesis: Approval runups > CRL runups in T-45 window
Test: Mann-Whitney U (non-parametric, robust to outliers)
Data: 50+ PDUFA events, 2024–2026
Result format:
  - Approval median runup: X%
  - CRL median runup: Y%
  - p-value: Z
  - Effect size (Cohen's d): W
  - Interpretation: "Significant at p<0.10" or "No significant difference"
```

### Test 2: Optimal T-X Window (RQ2)

```
Hypothesis: Runup divergence is strongest in T-X window (X = 45, 30, 20, 10?)
Test: Mann-Whitney U for each window; report p-values and effect sizes
Data: Same 50+ events, calculated for T-45, T-30, T-20, T-10 separately
Result format:
  T-45: p=0.08, d=0.35
  T-30: p=0.04, d=0.42
  T-20: p=0.06, d=0.38
  T-10: p=0.15, d=0.20
  → "Optimal entry is T-30" or "T-45 is indeed strongest"
```

### Test 3: CMC Recovery Pattern (RQ4)

```
Hypothesis: CMC CRL stocks recover 30–50% in 3–6 months
Test: Descriptive stats + survival curve (time to recovery milestones)
Data: 30+ CMC CRL events, 2022–2026
Result format:
  - Median max drawdown: -X%
  - Median recovery to -50% (80%): Y days
  - Median recovery to -20% (100%): Z days
  - By experience: Experienced average = A days, First-time = B days
  - Interpretation: "Recovery follows expected pattern" or "Slower/Faster than expected"
```

---

## 💰 THE TRADE OPPORTUNITY (What You'll Quantify)

### Current Cadence:
- 3 active positions: FBIO, GUTS, IRON
- ~1 CMC CRL recovery trade per position per year
- **Annual trades: 3**
- **Average return per trade: +30%**
- **Annual alpha: +90% (cumulative)**

### Expanded Opportunity:
- Monitor 15–20 small-cap positions
- ~1 CMC CRL per 3–4 companies per year
- **Annual trades: 3–4 additional**
- **Average return per trade: +30–35%**
- **Additional annual alpha: +90%–140%**

### Your Job:
**Prove this math with real data. Identify specific 15–20 candidates. Set up automated monitoring.**

---

## 📋 CHECKLIST: "I'm Ready to Start"

- [ ] FinBrain MCP is connected and working
- [ ] I've read ODIN-Executive-Summary.md (understand the thesis)
- [ ] I've skimmed Claude-MCP-ExecBrief.md (know the detailed queries)
- [ ] I have access to historical stock price data (Yahoo, FinBrain, etc.)
- [ ] I can query SEC EDGAR Form 4 filings (for insider trading)
- [ ] I understand Mann-Whitney U test (non-parametric hypothesis test)
- [ ] I can structure results as CSV/JSON (for dashboard + trading system)
- [ ] I'm prepared to work 6–8 hours intensively on this task

**If all boxes checked → START WITH QUERY 1 (Small-Cap PDUFA Catalysts)**

---

## 🎯 WHAT SUCCESS LOOKS LIKE (48-Hour Deliverables)

### Deliverable #1: Hypothesis Validation Report (2–3 pages)
```
ODIN Finding #1: Small-cap runups diverge by outcome (approval +12–18% vs CRL +5–10%)
Status: ✓ CONFIRMED / ⚠ PARTIALLY CONFIRMED / ✗ CONTRADICTED
Real Data Result: Approval median +14.3%, CRL median +6.8%, p=0.06
Confidence: p<0.10 confirms hypothesis; effect size d=0.39 (moderate)

[Repeat for 5 main findings]
```

### Deliverable #2: Optimal Trade Window Discovery (1–2 pages)
```
DISCOVERY: Ramp-up optimal entry window is T-{X} ± {Y} days

Current theory: T-45 is standard
Real data shows: T-30 is statistically strongest (p=0.04), T-45 also valid (p=0.08)
Recommendation: Enter at T-30 to avoid 15 days of false runup; reduces holding period by 25%

Expected return: +12–15% in 15-day window (T-30 to T-15)
Risk-adjusted return: Sharpe ratio = 1.6 (vs 1.2 for T-45 entry)
```

### Deliverable #3: CMC CRL Recovery Playbook (2–3 pages)
```
When a small-cap gets CMC CRL:

IMMEDIATE (T+0 to T+5):
- Stock typically drops 40–70% on announcement day
- Average max drawdown: T+2 to T+7
- Most common bottom: T+5 ± 2 days

ENTRY WINDOW (T+5 to T+15):
- Historical recovery: +20–35% from bottom
- Best entry: When stock reaches -60% from announcement price
- Buy level: $X (specific price for each company)

EXIT WINDOW (T+20 to T+30):
- Recovery continues: +40–60% from bottom
- Optimal exit: T+22 ± 3 days (or at +30% gain, whichever first)
- Exit level: $Y

By Company Experience:
- Experienced (≥1 prior approval): Recovery starts T+3–4, exit T+20
- First-time (0 prior approvals): Recovery starts T+10–12, exit T+30

Class of Resubmission:
- Class 1 (2-month review): Full recovery expected T+60–90
- Class 2 (6-month review): Slower; expect steady drip recovery T+90–180
```

### Deliverable #4: Small-Cap Catalyst Calendar (Spreadsheet)
```
Ticker | Company | Drug | PDUFA Date | Days to PDUFA | CMC Risk | Market Cap | Next Catalyst | Notes
FBIO   | Freq... | FX-... | 2026-03-15 | 43 | High | $400M | T-43 (in range) | Entry signal ready
GUTS   | Guth... | GUT-... | 2026-05-22 | 111 | Med | $200M | T-111 | Monitor T-66
IRON   | Iron... | ...    | 2026-07-10 | 160 | High | $150M | T-160 | Early stage
[15 more positions with same tracking]
```

### Deliverable #5: Live Monitoring Dashboard (HTML/Interactive)
```
Real-time tracking for each position:
- Current price & market cap
- Days to next PDUFA (countdown)
- T-45, T-30, T-20, T-10 dates (calendar events)
- Insider trading activity (last 30 days)
- IV term spread (updated daily)
- Recommendation: MONITOR / ENTER / EXIT / PASS

Alerts trigger at:
- T-45: "Ramp-up zone starting"
- T-30: "Statistical divergence begins"
- T-15: "Final positioning window"
- T-1: "Decision tomorrow"
- T+0 (if CRL): "Buy signal active for recovery trades"
```

---

## ⚡ GO TIME

**Print this page. Start with the 3 critical queries above. You have 6–8 hours to validate the ODIN thesis with real market data.**

**The opportunity is real. The data is available. The playbook is clear.**

**Execute now.**

---

**CLAUDE MCP QUICK START**  
**Prepared**: February 1, 2026, 12:00 AM PST  
**Status**: READY TO EXECUTE  
**Expected Completion**: 48 hours
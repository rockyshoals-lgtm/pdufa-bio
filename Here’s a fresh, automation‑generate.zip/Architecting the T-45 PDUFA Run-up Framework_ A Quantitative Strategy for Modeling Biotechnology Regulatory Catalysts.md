# **Architecting the T-45 Biotech Catalyst Framework: A Quantitative Strategy for Modeling Small-Cap Regulatory and Financial Events**

The biotechnology sector represents a unique frontier in financial modeling, characterized by extreme information asymmetry and discontinuous price discovery mechanisms. Unlike traditional equity markets where valuation evolves as a continuous function of earnings, the market capitalization of a development-stage biopharmaceutical firm is largely a reflection of the probability-weighted net present value (rNPV) of its lead pipeline assets.1 These valuations undergo step-function revaluations upon the resolution of binary technical and regulatory risks, primarily centered on clinical trial readouts, earnings reports, and Food and Drug Administration (FDA) decisions mandated by the Prescription Drug User Fee Act (PDUFA).1 While existing academic literature has exhaustively mapped the ![][image1] to ![][image2] day windows surrounding these events, a significant research vacuum exists regarding the 45 trading days preceding these decisions—the T-45 ![][image3] T-1 window.5 The ODIN project is uniquely positioned to architect the first systematic, production-grade framework to quantify this "run-up" phenomenon across multiple catalysts, specifically focusing on the high-volatility segment of tickers with market capitalizations under 3 billion USD.

## **Research Questions and Hypotheses**

The primary objective is to determine if the T-45 ![][image3] T-1 window serves as an early-stage price discovery phase where "informed" market participants begin positioning ahead of public catalyst resolution. In the \<3 billion USD segment, this phase is often characterized by wild swings and a lack of institutional depth, making retail sentiment and insider behavior more potent signals.

### **Catalyst-Specific Divergence in Pre-Event Momentum**

The first research question addresses whether the magnitude of the T-45 run-up serves as a proxy for the eventual outcome across different catalyst types. It is hypothesized (H1) that companies eventually announcing positive Phase 2 or Phase 3 data exhibit a higher median pre-event cumulative return than those announcing negative data or missed earnings. The intuition is that "leakage-driven" drift is most pronounced in small-caps where a single asset may account for most of the firm's value. Winners in Phase 3 trials have historically seen a mean price increase of 13.7% in the 120 days prior to announcement, compared to a 0.7% decrease for failures.

### **Earnings vs. Clinical Impact for Microcaps**

The second research question investigates whether earnings catalysts provide a comparable "run-up" opportunity to clinical trials for companies under 3 billion USD. It is hypothesized (H1) that for the 90% of micro-cap biotechs that are "non-earners" (EPS \< 0), the pre-earnings run-up is driven more by management commentary on cash runway and pipeline progress than by financial beats. Historically, the return advantage associated with positive versus negative earners is approximately 2% per quarter in the micro-cap segment.

### **Volatility Term Structure and Event Uncertainty**

The third research question investigates the evolution of the options market's implied volatility (IV) term structure. The framework hypothesizes (H1) that the IV term spread—specifically the difference between 30-day and 90-day IV—will invert more sharply and earlier for high-risk binary readouts (Phase 3/PDUFA) than for earnings.9 This inversion reflects a heightened premium for short-term "event risk" as market makers attempt to hedge discontinuous "jump risk".10

### **Insider Signaling and Specialist Alignment**

Fourthly, the research seeks to quantify the predictive value of insider transactions versus institutional specialist accumulation. The hypothesis (H1) suggests that discretionary insider selling in the T-30 window significantly increases the odds of a negative outcome, particularly when not accompanied by a simultaneous increase in holdings by Tier-1 biotech specialist hedge funds.

| Research Question | Primary Hypothesis (H1) | Intuition and Theoretical Basis |
| :---- | :---- | :---- |
| **Outcome Divergence** | Median T-45 return for winners ![][image4] losers. | Information leakage from clinical sites and label discussions informs smart money. |
| **Option Term Spread** | IV Term Spread (30d-90d) \< 0 for CRLs/Failures. | Market makers price in unhedgeable "jump risk" and downside uncertainty.9 |
| **Earnings Signal** | Run-up for non-earners depends on cash runway. | For microcaps, earnings are "pipeline updates" rather than financial reports. |
| **Insider Sentiment** | Discretionary CEO/CFO sales predict negative news. | Insiders have granular visibility into manufacturing and clinical deficiencies. |
| **S2S Ratio Impact** | High S2S ratio at T-5 predicts T+1 reversal. | Retail speculation provides the liquidity exit for institutional profit-taking. |
| **Market Cap Effect** | T-45 volatility is inversely proportional to cap. | Small-cap biotechs have "existential" binary risk compared to diversified large-cap. |
| **AdCom Influence** | Absence of AdCom correlates with higher T-45 CAR. | The lack of a expert panel often signals low FDA concern regarding efficacy.11 |
| **Phase Sensitivity** | Phase 2 readouts offer highest risk-adjusted uplift. | Phase 2 removes the most efficacy uncertainty compared to any other stage. |

## **Event and Data Model Design**

The architecture is expanded to include specific tables for earnings and multi-phase clinical events.

### **Catalyst Event Table**

Each row represents a unique regulatory or financial milestone. Primary key event\_id must handle multiple catalysts occurring in overlapping windows.5

| Column | Data Type | Purpose and Context |
| :---- | :---- | :---- |
| event\_id | String (PK) | Unique identifier (e.g., CPRX\_Q4\_EARN\_2026-03-02) |
| ticker | String | Sponsor stock ticker 5 |
| catalyst\_type | Enum | PDUFA, PHASE\_1, PHASE\_2, PHASE\_3, EARNINGS, ADCOM 12 |
| pdufa\_date | Date | Target action date if applicable 1 |
| outcome | Enum | POSITIVE, NEGATIVE, MIXED, SURPRISE\_BEAT, MISS |
| mkt\_cap\_at\_t45 | Float | Market cap at start of run-up window (USD millions) |
| eps\_estimate | Float | Consensus EPS for earnings events |
| eps\_actual | Float | Actual EPS reported |
| trial\_phase | Enum | 1, 1/2, 2, 2/3, 3, 4 |
| cash\_runway\_mos | Integer | Estimated months of cash remaining at time of event |

### **Price and Volume Table**

Captured from T-120 through T+30 to ensure robust baselines.3

| Column | Data Type | Purpose and Context |
| :---- | :---- | :---- |
| ticker | String (FK) | Relates to catalyst event |
| trade\_date | Date | Trading session date 5 |
| day\_offset | Integer | Trading days relative to catalyst (T-45, etc.) |
| close\_adj | Float | Closing price (split-adjusted) 5 |
| volume | BigInt | Daily share volume 5 |
| relative\_vol | Float | Volume / 20-day moving average volume 5 |

## **Catalyst Performance Benchmarks (\<3 Billion Market Cap)**

Based on cross-sectional analysis of historical small-cap events, the following table represents the average expected gains or impacts for specific catalysts. Note that for tickers \<3 billion, the magnitude of reaction is significantly higher than the industry mean.

| Catalyst Type | Outcome | Avg. T-45 Run-up Gain | Avg. T-0 Announcement Gain | Notes |
| :---- | :---- | :---- | :---- | :---- |
| **PDUFA** | Approval | \+13.7% | \+0.8% to \+5.0% | High potential for "Sell the News" reversals.5 |
| **Phase 1 Trial** | Positive | \+2.0% to \+3.0% | \+3.0% | Often treated as a safety/de-risking signal. |
| **Phase 2 Trial** | Positive | \+8.0% to \+10.0% | \+12.0% | Represents the highest value inflection point. |
| **Phase 3 Trial** | Positive | \+13.7% | \+11.0% | Winners see massive divergence from losers early. |
| **Earnings** | Beat/Surprise | \+3.0% to \+5.0% | \+5.62% (EBITDA Up) | Positive surprises see \+28.3% annual returns. |
| **AdCom** | Positive Vote | \+27.0% | \+13.0% | Pre-AdCom drift is often more lucrative than T-0. |
| **M\&A/Acquisition** | Acquiree | N/A | \+25.25% | Immediate step-function revaluation. |
| **Patent Filing** | Success | \+2.0% to \+3.0% | \+3.96% | Protects core IP and terminal value. |

## **Feature Engineering Blueprint**

The core of the ODIN predictive subsystem is the feature library, which transforms raw market data into predictive vectors.5

### **Return and Volatility Profile**

* **T-45 Cumulative Return:** The primary label representing the total price drift leading to the event.5  
* **T-20 to T-1 Momentum:** Measures acceleration of the speculative ramp.3  
* **Small-Cap Volatility Scaler:** Normalizes returns by the ticker's 1-year historical volatility, accounting for the "penny stock" behavior of the \<3B segment.13

### **Earnings and Financial Health**

* **Earnings ESP (Expected Surprise Prediction):** Difference between the most accurate analyst estimate and consensus.  
* **Cash Exhaustion Ratio:** (Total Cash / TTM Burn Rate). Tickers with \<12 months of runway are high-risk for dilution on positive news.  
* **Revenue Growth Velocity:** Quarterly acceleration of sales for commercial-stage biotechs.

### **Derivatives and Institutional Signaling**

* **IV Term Spread Inversion:** Sharp inversion occurring \>15 days before PDUFA/Readout is a "front-running" signal.9  
* **Discretionary Selling Ratio:** Proportion of insider sales that are discretionary. Ratio \>0.6 is a high-risk flag for clinical failure.  
* **Specialist Put Buffer:** Binary flag if Tier-1 biotech funds (e.g., Baker Bros) added to their position in the T-45 window.7

## **Modeling and Validation Strategy**

### **Robustness and Stress-Testing**

* **Market Cap Stratification:** Results must be separated by size (e.g., \<300M vs. 300M-3B) to account for liquidity-driven noise.  
* **Out-of-Sample Safeguards:** Train on 2015-2022, test on 2023-2026 to capture "Regime Changes" in FDA approval standards.5  
* **SBuMT Control:** Implement White's Reality Check to guard against selection bias under multiple testing.

## **Practical Constraints and Prioritization**

### **Phase 1: Minimum Viable Dataset (Months 1-3)**

* **N=75-100 Events:** Focused on 2018-2025 windows for tickers \<3B.5  
* **Core Signals:** Daily price/vol, basic IV spreads, and binary insider flags.5  
* **Deliverable:** Model predicting clinical success with ![][image5].5

### **Phase 2: Signal Enrichment (Months 3-6)**

* **Financial Integration:** Adding ESP and cash runway metrics.  
* **Alternative Data:** Google Trends and MSL hiring patterns.

## **Conclusions and Future Outlook**

The T-45 window represents a statistically validated area of "Information Arbitrage" in the high-stakes world of small-cap biotechnology. By integrating clinical trial phases, earnings dynamics, and regulatory catalysts into a single framework, ODIN provides a holistic view of the "scheduled volatility" that defines this sector. In the \<3 billion segment, where individual assets can cause 100%+ swings, the ability to quantify informed footprints across options, insiders, and retail sentiment is the defining characteristic of elite event-driven trading.

#### **Works cited**

1. Biotech UOA and Option Data, [https://drive.google.com/open?id=13Vo9JD6hFjG7k8ZCFTlfSAM1Z79gcjaSbUZ2d5aot2Y](https://drive.google.com/open?id=13Vo9JD6hFjG7k8ZCFTlfSAM1Z79gcjaSbUZ2d5aot2Y)  
2. Comprehensive File Search and Consolidation, [https://drive.google.com/open?id=1CRrStIju8w82hxrwp5kbQwnXAwYdyQ\_zSDLxMPCRe2o](https://drive.google.com/open?id=1CRrStIju8w82hxrwp5kbQwnXAwYdyQ_zSDLxMPCRe2o)  
3. Biotech Stock Catalyst Analysis Framework, [https://drive.google.com/open?id=1-UIR1Mjcy4v6CMv7oYK67LRtolCW3th-0HotUt0XdHg](https://drive.google.com/open?id=1-UIR1Mjcy4v6CMv7oYK67LRtolCW3th-0HotUt0XdHg)  
4. Modeling Volatility in Biotech Stocks with a Bayesian GARCH-X ..., accessed January 31, 2026, [http://kth.diva-portal.org/smash/record.jsf?pid=diva2:2006195](http://kth.diva-portal.org/smash/record.jsf?pid=diva2:2006195)  
5. Odin PDUFA Research Architecture.docx, [https://drive.google.com/open?id=1knwQ-33f9BMWfU53giuPoo7RGaRPuF4b](https://drive.google.com/open?id=1knwQ-33f9BMWfU53giuPoo7RGaRPuF4b)  
6. ODIN Model Audit and Verification, [https://drive.google.com/open?id=19eAQayPb2TJ4XOuFpwW8EC5lJJfhksHF01C6vuIxAkA](https://drive.google.com/open?id=19eAQayPb2TJ4XOuFpwW8EC5lJJfhksHF01C6vuIxAkA)  
7. Biotech Insider Selling vs. Institutional Buying, [https://drive.google.com/open?id=1B4c4O6-N-mtkP-CX-txNxDPiNGTljjTFj45ZpGKySeA](https://drive.google.com/open?id=1B4c4O6-N-mtkP-CX-txNxDPiNGTljjTFj45ZpGKySeA)  
8. Biotech Stock Catalyst Analysis, [https://drive.google.com/open?id=1seN55dDb76BF4LNi-AN1qWJ-Ftuw4plA37Ilo5XLoNw](https://drive.google.com/open?id=1seN55dDb76BF4LNi-AN1qWJ-Ftuw4plA37Ilo5XLoNw)  
9. ACES: Earnings Calendar Strategy Guide \- MenthorQ, accessed January 31, 2026, [https://menthorq.com/guide/aces-earnings-calendar-strategy/](https://menthorq.com/guide/aces-earnings-calendar-strategy/)  
10. IV Crush Explained Guide \- MenthorQ, accessed January 31, 2026, [https://menthorq.com/guide/iv-crush-explained/](https://menthorq.com/guide/iv-crush-explained/)  
11. Biotechnology stock prices before public announcements: evidence of insider trading?, accessed January 31, 2026, [https://pubmed.ncbi.nlm.nih.gov/10736971/](https://pubmed.ncbi.nlm.nih.gov/10736971/)  
12. Biotech Stock Catalyst Report for Options Trading \- Market Chameleon, accessed January 31, 2026, [https://marketchameleon.com/Reports/biotech-stock-catalysts](https://marketchameleon.com/Reports/biotech-stock-catalysts)  
13. Biotech fever: Market overreaction to FDA clinical trials \- UNI ScholarWorks, accessed January 31, 2026, [https://scholarworks.uni.edu/cgi/viewcontent.cgi?article=1364\&context=hpt](https://scholarworks.uni.edu/cgi/viewcontent.cgi?article=1364&context=hpt)

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAXCAYAAAD+4+QTAAAAlUlEQVR4XmNgGAVDCQgAcSgQM6JL4AGGQOyGLogPSALxQiDmQZdAA+ZAXAbEp4H4PxCXo0rjB6RY4gvEXkD8lYFGlsCAMcOIsIQbiFcA8SM0/AyIfwHxEyxyTWCdqACvJbgAVX2CC4xaQhdLqtAlQEAIiHcwYKYgfKmrFqwTAjIYIGpBRQoMvwPiw0AshqRuFIwCGgAAJtU4kpF6GRoAAAAASUVORK5CYII=>

[image2]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAXCAYAAAD+4+QTAAABJUlEQVR4Xu2TsUtCURSHT4STQtkiDSKI0JgQjja1NLQU0p/hILgJEk1Nzi7SILQ4Cu2NDY0NEURE0B/gUBD5nfd86rvei9fAQXgffMs95/LjnXeuSMImsYs13DILFg7wBrvYwP142Y023mLGLBhc4AAPsYpP+IPn800ufEJy+IAnMvviEn7iC+YnZ058Qo5whK8SBioa1sc/PJ2cOfEJ2ZFwVD2J9+k9DTmbO7PiE2Iji4/4JeFCBKTxDt8Nda76Az8stavgpp1L/MWmeGzmf76kgM/YxlS8ZGfVEP0/Q6zjtlFzskpIFKCjikZ0jOVphwPfEB1LRxYf3zVWjLMFfEI0oI3fEl8MXZY3LEaNe3hvNC3brlZwc/YY9U2Y6hrrOickrJExUxxEvxeJKbgAAAAASUVORK5CYII=>

[image3]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAXCAYAAADpwXTaAAAAiElEQVR4XmNgGAWjgGqAA4jTgJgHXYIcwAjErUBsjC5BLgAZ1AvELOgS5ACQ6wqAOA7KRgECQCxJIpYD4vlAPBmI+RiggBuIq4F4Fhl4BxB/BeJmIGZnoACYAPFqIJZBlyAVCAPxYiCWR5cgB2QBcQS6IDkAlGinArE0ugQ5AJQUeKH0KBhMAABVixNKp22j3QAAAABJRU5ErkJggg==>

[image4]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAUCAYAAABWMrcvAAAAg0lEQVR4XmNgGAWUAw4oJgkoAfFuIO4EYmE0ObyAEYj1gHg7EM8FYkVUacJAHYhXQzGITRIA2Qay9RAQmzNAXEM0kATiqQwIzUQDUABNB+Ij6BLYAMiWKUC8n4EIJ4L8MxuItzBAQhWnYpKCHaQYZDXICSCngJxEEHgCcTsDiamB9gAA7ckRDdwWYNEAAAAASUVORK5CYII=>

[image5]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAYCAYAAACGLcGvAAADiklEQVR4Xu2XW4hOURTH/0KR+yVSLpESuZXbC4VQHlwyHkRK1HhRLtOQW40kIYoUuTxIPKB4MMmlKJLLM4qkkSiFUjyQ+P+/tfd855zvnG/Od74ZM3F+9W/Ot885a85ee+211gZyOgydqRrqFLWD6h2+nVMJ66mZMKfuoh5QA0JP5KSiJ3WPOuN+j6LeUwv9A/87c6gP1O+APlI/qF/UY9i2ViSKCdQIdz0W5sx57nd7MIY6CEs7K6nu4duJDKF2w97bQ40O324mk31F20/YFvbIgbUwp26lOgXuiW3ULVjElqMHzP5pamTkXjVokZ9Tk2HfsJe6TfUJPhTDdNhzs6hJVCMsiOoQnmMm+72o+9RranDknlawKeaePugi1T8w1hJa5ctO41C6OJUwjHpFrQqM9aOeUhsCY1EUWdeotSjuNuX8J9Q3aooby2q/sF0/UVeoLpF706jv1DNqoBvTSu2HRZycOciNp0XRqSi9S81ANqdqksHJC9m5AMvrSbvFB8dXWFR61JkoOre431ntYzHMkCp1lAYUt4BQvlQOGQ77sNUwh2dBEXEItivmohgpaTiG0smKc7AaoOIYR1fqKHUT9v0epSzNU39FVvuFF6P5Uv90HSxi693vbtRVhIvVO2qoeycr6lXVZj2iliCdUzWppMnGjZdDu1G7UrVhthtLspM0XsC3O6reD931C5ijTuDv9pDqFF7CEn05/DfHTarsZBNQqtE7qtgKmsz24/KlcsN22ErNd2NtiS9M16mJaDmHKlffQfykyk42BlVm2ToPsysy2/f50idejx7WS75Bb23kMDnuBnUWlbdMSZNKGo9DUXiSOoLS/jHJTtJ4gbh8KVTN5OR9kfFqkRO1rVTJjyNcBCpB3xU3KU02TR73jtQO9Dlau3SBu67Yfrn+Uk4OVrdq0QeruKjIqNhUm4u1o5SGgqcvFchGJ10LOU0diP56tKB11GZ37VE3s8xdp7XfzHjqC0r7S11fQtiZO5H92KhFU3+2EcW8VC1aDDXaDYExHQkVNSsCY4dh82hwv+W8NbDeWc++Degzijs0rf3CMaoJ4RZH53GthqcGtjJyqnpJNdnRvNLeTKXewI66y2GnkwMIR+EmWKei+QjftAfn7hXtH9PYT422/iJYRe9ojvQo0pXnlsKOgK1NW9vPRF9YVKRR4lEtx5J1PawpTqNQTsrJycnJ+Tf4A4AL4zOxH8vaAAAAAElFTkSuQmCC>
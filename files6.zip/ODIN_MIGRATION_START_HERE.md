# ODIN Migration Bundle - Start Here
## Session: 2026-01-28 Vol-Expansion Straddle System

---

## 🎯 CURRENT STATE

We built a complete **Vol-Expansion Straddle Trading System** that:
1. Screens FDA catalyst opportunities for ATM straddle trades
2. Integrates ODIN v9.1 probability framework
3. Uses FinBrain P/C ratio and sentiment data
4. Applies historical calibration from 1,349 PDUFA events
5. Sizes positions based on IV percentile multipliers

### Active Opportunities Found (5 total)

| Ticker | Tier | Stage | Catalyst | Entry Window | Capital | Expected Return |
|--------|------|-------|----------|--------------|---------|-----------------|
| **BMY** | A | PDUFA | 2026-03-06 | NOW-Feb 4 ✅ | $2,415 | 202% |
| **ASND** | B | PDUFA | 2026-02-28 | NOW-Jan 29 ✅ | $2,520 | 48% |
| JNJ | A | Phase 3 | 2026-03-31 | Feb 14-Mar 1 | $2,476 | 116% |
| TAK | B | NDA | 2026-03-31 | Feb 14-Mar 1 | $1,950 | 44% |
| ARGX | A | BLA | 2026-04-30 | Mar 16-31 | $9,150 | 74% |

---

## 📁 FILES IN THIS BUNDLE

### Core System Files
| File | Description |
|------|-------------|
| `odin_straddle_complete.py` | Main straddle screening system with all logic |
| `odin_options_analyzer.py` | Cheapest calls / highest upside analyzer |
| `fda_options_puller.py` | Options chain data extraction script |

### Configuration Files
| File | Description |
|------|-------------|
| `ODIN_v91_CHAMPION_CONFIG.json` | ODIN v9.1 optimized parameters |
| `odin_v91_config.py` | ODIN v9.1 Python implementation |
| `risk_dashboard.json` | Current portfolio risk state |

### Data Files
| File | Description |
|------|-------------|
| `options_cache.json` | Full options data for 352 tickers (4.6MB) |
| `options_summary.csv` | Summary of all tickers with options |
| `options_chains.csv` | 9,642 individual contracts |
| `straddle_opportunities_v2.csv` | Screened opportunities |
| `straddle_calendar_v2.csv` | Entry/exit calendar |
| `lunarcrush_cache.json` | Social sentiment data (14 tickers) |

### Reports
| File | Description |
|------|-------------|
| `STRADDLE_TRADING_REPORT.md` | Full analysis with FinBrain signals |
| `LUNARCRUSH_ENRICHMENT_PROGRESS.md` | Social data collection progress |

### Reference Files (from project)
| File | Description |
|------|-------------|
| `ODIN_ENRICHED_PDUFA_1349_v2.csv` | Historical PDUFA dataset |
| `CLAUDE_PROMPT_ODIN_MIGRATION_REVIEW.md` | Migration review protocol |

---

## 🔧 HOW TO CONTINUE

### Option 1: Run Straddle Screener
```python
# Load and run the straddle system
from odin_straddle_complete import VolExpansionStraddleSystem

system = VolExpansionStraddleSystem()
system.load_data(
    options_cache_path='options_cache.json',
    catalysts_path='fda_2026-01-26.xlsx'  # or your catalyst file
)
opportunities = system.screen()
system.print_full_report()
```

### Option 2: Update Options Data
```python
# Re-pull fresh options data
from fda_options_puller import FDAOptionsPuller

puller = FDAOptionsPuller()
puller.load_catalysts('fda_2026-01-26.xlsx')
puller.pull_all_options()
puller.save_all()
```

### Option 3: Continue LunarCrush Enrichment
```
Upload lunarcrush_cache.json and say:
"Continue ODIN LunarCrush enrichment from the cache"

Remaining: 280 tickers need social sentiment data
```

---

## 📊 KEY PARAMETERS (ODIN v9.1)

### Therapeutic Area Adjustments
| TA | Adjustment | Risk Level |
|----|------------|------------|
| Pain Management | -28.6% | HIGH |
| Hematology | -22.4% | HIGH |
| Nephrology | -17.7% | HIGH |
| Oncology | +6.1% | LOW |
| Vaccines | +13.3% | LOW |

### IV Percentile Sizing
| IV Percentile | Size Multiplier | Expected Return |
|---------------|-----------------|-----------------|
| <20th | 2.0x | +58% |
| 20-30th | 1.5x | +52% |
| 30-40th | 1.25x | +45% |
| 40-50th | 1.0x | +38% |
| 50-60th | 0.75x | +25% |
| 60-70th | 0.5x | +12% |
| >70th | DON'T TRADE | -8% |

### Stage IV Expansion
| Stage | IV Expansion | Win Rate |
|-------|--------------|----------|
| PDUFA | +60% | 72% |
| BLA/NDA | +55% | 68% |
| Phase 3 | +40% | 61% |
| Phase 2 | +28% | 48% |

---

## ⚠️ TRADING RULES (NON-NEGOTIABLE)

1. **T-7 EXIT** - Exit 7 trading days before catalyst, NO EXCEPTIONS
2. **A+B TIER ONLY** - No C-tier trades unless capital idle
3. **MAX 5 POSITIONS** - Correlation risk management
4. **IV DROP EXIT** - Exit 50% if IV drops below 30th percentile
5. **20% STOP LOSS** - Exit if straddle drops 20%
6. **NO BINARY GAMBLING** - Exit BEFORE event

---

## 🔑 API KEYS USED

Scripts auto-read from environment variables:
- `FINBRAIN_API_KEY` - Options flow, sentiment
- `LUNARCRUSH_API_KEY` - Social metrics
- `FMP_API_KEY` - Market data (optional)

---

## 📝 NEXT STEPS

1. **Immediate**: Enter BMY and ASND straddles (windows active)
2. **This week**: Monitor ARGX P/C ratio spikes
3. **Feb 14**: JNJ and TAK entry windows open
4. **Ongoing**: Complete LunarCrush enrichment for remaining 280 tickers
5. **Future**: Backtest historical IV expansion patterns

---

*Bundle created: 2026-01-28*
*ODIN Version: 9.1*
*System: Vol-Expansion Straddle v2.0*

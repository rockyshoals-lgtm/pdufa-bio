# ODIN Vol-Expansion Straddle System - Final Report
## Generated: 2026-01-28

---

## 📊 EXECUTIVE SUMMARY

| Metric | Value |
|--------|-------|
| Total Opportunities | 5 |
| A-Tier Trades | 3 (BMY, JNJ, ARGX) |
| B-Tier Trades | 2 (ASND, TAK) |
| Expected Portfolio Return | 62.7% on deployed capital |
| Win Rate (Historical) | 68% avg |
| Capital Required | $18,511 (18.5% of $100K) |

---

## 🎯 TOP TRADE: BMY (Bristol-Myers Squibb)

### Trade Specs
| Field | Value |
|-------|-------|
| **Tier** | A-tier (BEST) |
| **Stage** | PDUFA Priority Review |
| **Catalyst Date** | 2026-03-06 (36 days) |
| **ODIN Probability** | 86% (TIER_1) |
| **Entry Window** | 2026-01-20 to 2026-02-04 ✅ ACTIVE NOW |
| **EXIT DATE** | 2026-02-27 (T-7, HARD STOP ⛔) |

### IV Analysis
| Field | Value |
|-------|-------|
| Current IV | 30% |
| IV Percentile | 10th (EXTREMELY CHEAP 🟢🟢) |
| Expected IV Expansion | +60% |
| Peak IV Estimate | 48% |
| Size Multiplier | 2.0x (max edge) |

### Straddle Pricing
| Field | Value |
|-------|-------|
| ATM Strike | $55.00 |
| Entry Cost | $1.05/contract |
| Peak Value Est | $3.17/contract |
| **Capital Efficiency** | **202%** (EXCEPTIONAL) |

### Position Sizing
| Field | Value |
|-------|-------|
| Capital Allocation | $2,415 |
| Contracts | 23 |
| Stop Loss | $0.84/contract (20%) |
| Max Loss | $2,415 |
| **Expected Profit** | **$3,406** |

### FinBrain Options Flow
| Date | P/C Ratio | Call Volume | Put Volume | Signal |
|------|-----------|-------------|------------|--------|
| 2026-01-14 | 0.54 | 10,495 | 5,667 | Neutral |
| 2026-01-15 | 0.35 | 15,121 | 5,292 | Bullish |
| 2026-01-23 | 0.31 | 10,106 | 3,133 | Bullish |
| 2026-01-28 | 0.63 | 14,758 | 9,298 | Neutral |

**P/C Trend**: 0.54 → 0.63 (slight put increase, but call-dominant overall)  
**FinBrain Sentiment**: +0.196 (POSITIVE)  
**Signal**: No warning flags - normal pre-catalyst positioning

---

## 💊 IMMEDIATE ENTRY: ASND (Ascendis Pharma)

### Trade Specs
| Field | Value |
|-------|-------|
| **Tier** | B-tier |
| **Stage** | PDUFA Priority Review |
| **Catalyst Date** | 2026-02-28 (30 days) |
| **ODIN Probability** | 86% (TIER_1) |
| **Entry Window** | 2026-01-14 to 2026-01-29 ✅ LAST DAY TOMORROW |
| **EXIT DATE** | 2026-02-21 (T-7, HARD STOP ⛔) |

### IV Analysis
| Field | Value |
|-------|-------|
| Current IV | 53% |
| IV Percentile | 20th (CHEAP 🟢) |
| Expected IV Expansion | +60% |
| Peak IV Estimate | 85% |
| Size Multiplier | 2.0x |

### Straddle Pricing
| Field | Value |
|-------|-------|
| ATM Strike | $230.00 |
| Entry Cost | $25.20/contract |
| Peak Value Est | $37.39/contract |
| Capital Efficiency | 48% |

### Position Sizing
| Field | Value |
|-------|-------|
| Capital Allocation | $2,520 |
| Contracts | 1 |
| Expected Profit | $854 |

### FinBrain Options Flow ⚠️ WATCH
| Date | P/C Ratio | Signal |
|------|-----------|--------|
| 2026-01-15 | 0.45 | Neutral |
| 2026-01-19 | **2.89** | ⚠️ PUT SPIKE |
| 2026-01-21 | 0.12 | Very Bullish |
| 2026-01-28 | 0.10 | Very Bullish |

**P/C Analysis**: 
- Jan 19 saw massive put spike (2.89 ratio) - could be hedging or bearish positioning
- Since then, ratio collapsed to 0.10 (10 calls for every put)
- **Interpretation**: Smart money may have hedged but now removed those hedges = bullish

---

## 💉 WATCH LIST: JNJ (Johnson & Johnson)

### Trade Specs
| Field | Value |
|-------|-------|
| **Tier** | A-tier |
| **Stage** | Phase 3 |
| **Catalyst Date** | 2026-03-31 (61 days) |
| **ODIN Probability** | 68% (TIER_3) |
| **Entry Window** | 2026-02-14 to 2026-03-01 (WAITING) |
| **EXIT DATE** | 2026-03-24 |

### IV Analysis
| Field | Value |
|-------|-------|
| Current IV | 28% |
| IV Percentile | 10th (EXTREMELY CHEAP 🟢🟢) |
| Capital Efficiency | 116% |

### FinBrain Options Flow
| Date | P/C Ratio | Signal |
|------|-----------|--------|
| 2026-01-22 | 0.60 | Neutral |
| 2026-01-26 | 0.91 | ⚠️ Put buying |
| 2026-01-28 | **0.35** | ✅ Call surge |

**P/C Analysis**: Strong call buying today (41K calls vs 14K puts) after put accumulation. This reversal pattern is bullish.

---

## 🧬 WATCH LIST: ARGX (argenx)

### Trade Specs
| Field | Value |
|-------|-------|
| **Tier** | A-tier |
| **Stage** | BLA Filing |
| **Catalyst Date** | 2026-04-30 (91 days) |
| **ODIN Probability** | 88% (TIER_1) |
| **Entry Window** | 2026-03-16 to 2026-03-31 (WAITING) |
| **EXIT DATE** | 2026-04-23 |

### IV Analysis
| Field | Value |
|-------|-------|
| Current IV | 40% |
| IV Percentile | 10th (EXTREMELY CHEAP 🟢🟢) |
| Capital Efficiency | 74% |
| Capital Required | $9,150 (largest position) |

### FinBrain Options Flow ⚠️ VOLATILE
| Date | P/C Ratio | Signal |
|------|-----------|--------|
| 2026-01-15 | 0.10 | Very Bullish |
| 2026-01-19 | **5.33** | ⚠️ MASSIVE PUT SPIKE |
| 2026-01-26 | **5.17** | ⚠️ ANOTHER PUT SPIKE |
| 2026-01-28 | 0.51 | Neutral |

**P/C Analysis**: 
- Two massive put spikes (5.33 and 5.17) - unusual activity
- Now normalized to 0.51
- **Caution**: Large put buying may indicate institutional hedging or concerns
- **Recommendation**: Monitor closely before entry window

---

## 🏥 WATCH LIST: TAK (Takeda)

### Trade Specs
| Field | Value |
|-------|-------|
| **Tier** | B-tier |
| **Stage** | NDA Filing |
| **Catalyst Date** | 2026-03-31 (61 days) |
| **ODIN Probability** | 66% (TIER_3) |
| **Entry Window** | 2026-02-14 to 2026-03-01 (WAITING) |
| **EXIT DATE** | 2026-03-24 |

### IV Analysis
| Field | Value |
|-------|-------|
| Current IV | 28% |
| IV Percentile | 10th (EXTREMELY CHEAP 🟢🟢) |
| Capital Efficiency | 44% |

---

## 📅 EXECUTION CALENDAR

| Action | Date | Ticker | Notes |
|--------|------|--------|-------|
| **ENTER** | NOW-Jan 29 | ASND | Last day tomorrow! |
| **ENTER** | NOW-Feb 4 | BMY | Active window |
| EXIT | Feb 21 | ASND | T-7 HARD STOP |
| ENTER | Feb 14-Mar 1 | JNJ, TAK | Entry window opens |
| EXIT | Feb 27 | BMY | T-7 HARD STOP |
| ENTER | Mar 16-31 | ARGX | Entry window opens |
| EXIT | Mar 24 | JNJ, TAK | T-7 HARD STOP |
| EXIT | Apr 23 | ARGX | T-7 HARD STOP |

---

## 🛡️ RISK MANAGEMENT

### Portfolio Risk Dashboard
| Metric | Value | Status |
|--------|-------|--------|
| Active Positions | 5/5 max | ⚠️ AT MAX |
| Capital Deployed | $18,511 (18.5%) | ✅ OK |
| Max Loss (Worst Case) | $18,511 | ❌ EXCEEDS 5% LIMIT |
| Correlated Max Loss | $13,420 | |
| Portfolio Vega | 420 | |
| Expected Profit | $11,605 | |
| Expected Return | 62.7% | |

### Risk Mitigation Actions
1. **ARGX Concentration**: $9,150 in single position - consider reducing to 0.5 contracts (not possible) or skipping
2. **Sector Correlation**: All 5 are pharma - 45% correlation assumed
3. **Stop Losses**: 20% drawdown on any position = exit

---

## ⚠️ FINBRAIN RED FLAGS

| Ticker | Flag | Action |
|--------|------|--------|
| ASND | P/C spike 2.89 on Jan 19 | ⚠️ Monitor - now resolved |
| ARGX | Two P/C spikes >5.0 | ⚠️ Investigate before entry |
| BMY | None | ✅ Clear |
| JNJ | None | ✅ Clear |
| TAK | No data | ℹ️ Use caution |

---

## 📋 TRADING RULES (NON-NEGOTIABLE)

1. **T-7 EXIT IS ABSOLUTE** - Exit 7 trading days before catalyst, NO EXCEPTIONS
2. **ONLY A+B TIER** - No C-tier unless capital is completely idle  
3. **MAX 5 POSITIONS** - We're at max, no new entries until exits
4. **IV DROP → EXIT 50%** - If IV percentile drops below 30% mid-hold
5. **STOP LOSS 20%** - If straddle drops 20%, exit immediately
6. **PROFIT TARGET 70%** - Take profit at 70% of estimated peak value
7. **NO BINARY GAMBLING** - Exit before event, not at it

---

## 🎯 IMMEDIATE ACTIONS

### Today (Jan 28)
- [ ] **ENTER BMY** - Buy 23 straddles @ $1.05 ATM ($55 strike)
- [ ] **ENTER ASND** - Buy 1 straddle @ $25.20 ATM ($230 strike) - LAST DAY TOMORROW

### This Week
- [ ] Set calendar reminders for T-7 exits
- [ ] Monitor ARGX P/C ratio for normalization

### Next Month
- [ ] Feb 14: Enter JNJ and TAK when window opens
- [ ] Feb 21: EXIT ASND (T-7)
- [ ] Feb 27: EXIT BMY (T-7)

---

*Report generated by ODIN Vol-Expansion Straddle System v2.0*
*Data sources: Options Cache, FDA Catalyst Database, FinBrain API, ODIN v9.1*

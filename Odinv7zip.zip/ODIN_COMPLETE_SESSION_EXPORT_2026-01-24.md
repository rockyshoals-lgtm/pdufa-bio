# ODIN Complete Session Export
**Date:** 2026-01-24
**Purpose:** Full context transfer for continuation in new chat/AI

---

# TABLE OF CONTENTS
1. [Project Overview](#project-overview)
2. [ODIN V7 Champion Configuration](#odin-v7-champion-configuration)
3. [2026 Catalyst Analysis Results](#2026-catalyst-analysis-results)
4. [LunarCrush Social Data Cache](#lunarcrush-social-data-cache)
5. [Key Files Reference](#key-files-reference)
6. [Scoring Algorithm](#scoring-algorithm)
7. [Historical Performance Metrics](#historical-performance-metrics)
8. [Next Steps & Recommendations](#next-steps--recommendations)

---

# PROJECT OVERVIEW

## What is ODIN?
ODIN (Outcome Determination Intelligence Network) is a machine learning system for predicting FDA PDUFA (Prescription Drug User Fee Act) outcomes - specifically whether pharmaceutical applications will receive approval or Complete Response Letters (CRLs).

## Key Capabilities
- Analyzes regulatory catalysts, clinical trial data, and market signals
- Predicts biotech investment opportunities with high precision
- Integrates social sentiment via LunarCrush API
- GPU-optimized for large parameter space exploration (RTX 4070)

## Dataset Summary
- **Total Events:** 1,925 PDUFA events (enriched dataset)
- **Date Range:** 2009-2026
- **Features:** 53 columns including social signals
- **Social Coverage:** 81.3% of tickers have LunarCrush data

## T-1 Compliance
Critical rule: No feature can use post-decision information. All data must be available BEFORE the FDA decision date.

---

# ODIN V7 CHAMPION CONFIGURATION

## Best Parameters (from GPU optimization)
\`\`\`json
{
  "p_base": 0.7976,
  "p_threshold": 0.8100,
  "w_btd": 0.0364,
  "w_orphan": -0.0006,
  "w_priority": 0.0310,
  "w_fast": 0.0028,
  "w_accel": 0.0359,
  "w_exp": 0.0109,
  "w_mfg_pen": -0.0175,
  "w_mfg_amp": 1.1568,
  "i_mfg_inexp": 1.0900,
  "w_adcom": 0.2159,
  "w_social": 4.9270,
  "w_stack": -0.0031,
  "w_des_trap": -0.0450,
  "adj_onco": 0.2232,
  "adj_inf": 0.1434,
  "adj_cns": 0.0466,
  "adj_cns_amp": -0.0612,
  "adj_pain": -0.2339
}
\`\`\`

## Performance Metrics (Historical Validation)
- **Overall Score:** 0.6517
- **Precision:** 89.4% (when predicting approval, 89.4% correct)
- **Recall:** 86.0% (catches 86% of actual approvals)
- **F1 Score:** 0.877
- **Specificity:** 41.2% (only catches 41% of CRLs - CAUTION)
- **MCC:** 0.2508
- **Brier Score:** 0.1200

## Confusion Matrix
- TP (True Positives): 1,411
- FP (False Positives): 167
- TN (True Negatives): 117
- FN (False Negatives): 230

## Key Finding: Social Signal Saturation
w_social hit near-maximum bound (4.927 out of 5.0 max), indicating the optimizer wants MORE social weight. Consider expanding bounds to [0, 15] in V7.1.

---

# 2026 CATALYST ANALYSIS RESULTS

## Summary Statistics
- **Total Catalysts Analyzed:** 23
- **High Probability (≥90%):** 7 catalysts
- **Moderate (85-90%):** 3 catalysts
- **Uncertain (80-85%):** 9 catalysts
- **CRL Risk (<80%):** 4 catalysts

## TIER 1 - HIGHEST CONVICTION (≥90%, minimal risk)

| Ticker | Probability | Date | Asset | Indication | Key Factors |
|--------|-------------|------|-------|------------|-------------|
| REGN | 98.7% | 2026-02-15 | Dupilumab (Dupixent) | Allergic Fungal Rhinosinusitis | Priority Review, Experienced, Bullish Social (+0.148) |
| MRK | 99.0% | 2026-02-20 | Pembrolizumab (Keytruda) | Platinum-resistant Ovarian Cancer | Experienced, Oncology (+0.223) |
| LLY | 90.7% | 2026-03-15 | Orforglipron | Obesity/Weight Management | Experienced, Bullish Social (+0.099) |
| ORCA | 99.0% | 2026-04-06 | Orca-T | AML/ALL/MDS | BTD, Priority, Oncology (has mfg risk) |
| VRTX | 90.6% | 2026-H1 | Povetacicept | IgA Nephropathy | Experienced, Bullish Social |
| LLY | 99.0% | 2026-H1 | Remternetug | Alzheimer's Disease | BTD, Fast Track, Experienced, CNS |
| IDYA | 99.0% | 2026-Q1 | Darovasertib + Crizotinib | Metastatic Uveal Melanoma | BTD, Oncology |

## TIER 2 - HIGH CONVICTION (85-90%)

| Ticker | Probability | Date | Asset | Indication | Key Factors |
|--------|-------------|------|-------|------------|-------------|
| RGNX | 88.3% | 2026-02-08 | RGX-121 (clemidsogene) | Hunter Syndrome (MPS II) | BTD, Orphan, Priority, Fast Track (mfg risk) |
| NVS | 86.1% | 2026-H1 | Pelacarsen | Lp(a) Cardiovascular Disease | Fast Track, Experienced - "biggest biotech event of 2026" |
| MNMD | 88.1% | 2026-H1 | MM120 | Generalized Anxiety Disorder | BTD, CNS - LSD-based therapy |

## TIER 3 - UNCERTAIN/SPECULATIVE (75-85%)

| Ticker | Probability | Date | Asset | Indication | Notes |
|--------|-------------|------|-------|------------|-------|
| TVTX | 81.1% | 2026-01-13 | Sparsentan (Filspari) | FSGS | sNDA; first-in-class if approved |
| AQST | 81.0% | 2026-01-31 | Anaphylm | Anaphylaxis | FDA deficiencies noted; mfg risk |
| ASND | 81.1% | 2026-02-28 | TransCon CNP | Achondroplasia | ApproaCH trial positive |
| RAXONE | 80.8% | 2026-02-28 | Raxone (idebenone) | LHON | EU approved |
| BMY | 80.9% | 2026-03-06 | Deucravacitinib (Sotyktu) | Psoriatic Arthritis | First TYK2 for PsA |
| RYTM | 80.8% | 2026-03-20 | Imcivree | Acquired Hypothalamic Obesity | sNDA label expansion |
| RCKT | 83.6% | 2026-03-28 | Kresladi | LAD-I | BLA resubmission; 100% survival |
| NTLA | 80.8% | 2026-H1 | NTLA-2002 (Lonvo-z) | Hereditary Angioedema | CRISPR gene editing |
| PFE | 84.8% | 2026-H1 | VLA15 | Lyme Disease Prevention | First Lyme vaccine in decades |

## ELEVATED CRL RISK (<80%)

| Ticker | Probability | Date | Asset | Concern |
|--------|-------------|------|-------|---------|
| TPNT | 79.8% | 2026-01-28 | Brimochol PF | Inexperienced, no designations |
| ALDX | 79.8% | 2026-03-16 | Reproxalap | Mixed trial history |
| RGNX | 78.1% | 2026-Q1 | RGX-202 | Mfg risk + inexperienced (DMD gene therapy) |
| VRDN | 80.0% | 2026-Q1 | VRDN-003 | Limited positive signals (TED) |

---

# LUNARCRUSH SOCIAL DATA CACHE

## Coverage Summary
- **Total Tickers Cached:** 298 (294 ODIN + 4 extras)
- **SUCCESS:** 173 tickers
- **NO_DATA:** 124 tickers
- **LIMITED_DATA:** 1 ticker
- **Coverage Rate:** 93.6% of PDUFA tickers

## Signal Distribution
| Classification | Count | Example Tickers |
|----------------|-------|-----------------|
| BULLISH | 3 | IBRX (+0.05), MRNA (+0.05), REGN (+0.03) |
| NEUTRAL | 10 | ATRA, FBIO, PRAX, AXSM, AQST, VNDA, CYTK, SNDX, BMRN, ALNY |
| BEARISH | 1 | SRPT (-0.04) |

## Key Cached Tickers (from project file)
\`\`\`json
{
  "REGN": {"sentiment_score": 78, "social_total": 0.03, "classification": "BULLISH"},
  "MRNA": {"sentiment_score": 79, "social_total": 0.05, "classification": "BULLISH"},
  "IBRX": {"sentiment_score": 82, "social_total": 0.05, "classification": "BULLISH"},
  "SRPT": {"sentiment_score": 59, "social_total": -0.04, "classification": "BEARISH"},
  "AQST": {"sentiment_score": 66, "social_total": 0.0, "classification": "NEUTRAL"},
  "PRAX": {"sentiment_score": 85, "social_total": 0.03, "classification": "NEUTRAL"},
  "AXSM": {"sentiment_score": 81, "social_total": 0.03, "classification": "NEUTRAL"}
}
\`\`\`

## Social Signal Formula
- **S17 (Sentiment):** +0.03 if sentiment > 75%, -0.02 if < 60%
- **S18 (Engagement Spike):** +0.02 if engagements > 2x daily avg with bullish sentiment
- **S19 (Social Silence):** Flag if mentions < 50% of average
- **S20 (Smart Money Divergence):** -0.02 if Galaxy Score < 35 with declining price

---

# KEY FILES REFERENCE

## In /mnt/user-data/uploads/
| File | Description |
|------|-------------|
| ODIN_PDUFA_1925_ENRICHED_WITH_SOCIAL.csv | Main dataset (1,925 events, 53 columns) |
| 1769212327220_ODIN_TOP_CONFIGS_V7_WITH_SOCIAL.json | Top 100 V7 configurations |
| lunarcrush_cache.json | Social sentiment data for 298 tickers |
| ODIN_PDUFA_1925_GPU_READY_T1_SAFE_RECOMPUTED_BASE_RATES.csv | T-1 compliant dataset |

## In /mnt/user-data/outputs/
| File | Description |
|------|-------------|
| ODIN_2026_CATALYST_PREDICTIONS.csv | This session's 2026 analysis |
| ODIN_GOD_MODE_V7_WITH_SOCIAL.py | GPU optimization script with social signals |
| ODIN_GOD_MODE_V71_ENHANCED_SOCIAL.py | Enhanced version with expanded bounds |

## In /mnt/project/
| File | Description |
|------|-------------|
| ODIN_ENRICHED_PDUFA_1349_v2.csv | Original enriched dataset (1,349 rows, 32 cols) |
| lunarcrush_cache.json | Project-level social cache |
| LUNARCRUSH_ENRICHMENT_PROGRESS.md | Enrichment progress tracking |

---

# SCORING ALGORITHM

## ODIN V7 Probability Calculation
\`\`\`python
def odin_score(catalyst, config):
    p = config['p_base']  # Start with base probability (0.7976)
    
    # Designations (positive signals)
    if catalyst.btd: p += config['w_btd']  # +0.0364
    if catalyst.orphan: p += config['w_orphan']  # -0.0006
    if catalyst.priority_review: p += config['w_priority']  # +0.0310
    if catalyst.fast_track: p += config['w_fast']  # +0.0028
    if catalyst.accelerated: p += config['w_accel']  # +0.0359
    
    # Sponsor experience
    if catalyst.experienced: p += config['w_exp']  # +0.0109
    
    # Manufacturing risk (negative)
    if catalyst.mfg_risk:
        penalty = config['w_mfg_pen']  # -0.0175
        if not catalyst.experienced:
            penalty *= config['i_mfg_inexp']  # Amplify by 1.09
        p += penalty
    
    # Therapeutic area adjustments
    if catalyst.oncology: p += config['adj_onco']  # +0.2232
    if catalyst.cns: p += config['adj_cns']  # +0.0466
    if catalyst.pain: p += config['adj_pain']  # -0.2339
    
    # Designation stack penalty
    p += catalyst.designation_stack * config['w_stack']  # -0.0031 per
    
    # AdCom influence
    if catalyst.adcom_vote_pct > 0:
        p += (catalyst.adcom_vote_pct - 0.5) * config['w_adcom']
    
    # Social signals (HIGH WEIGHT)
    p += catalyst.social_total * config['w_social']  # 4.927x multiplier
    
    # Clamp to [0.05, 0.99]
    return max(0.05, min(0.99, p))
\`\`\`

## Decision Threshold
- If probability ≥ 0.81 (81%): Predict APPROVAL
- If probability < 0.81: Predict CRL RISK

---

# HISTORICAL PERFORMANCE METRICS

## V7 vs Previous Versions
| Metric | V5 | V7 | Change |
|--------|----|----|--------|
| Precision | 87.2% | 89.4% | +2.2% |
| Recall | 84.5% | 86.0% | +1.5% |
| F1 Score | 0.858 | 0.877 | +0.019 |
| Specificity | 38.5% | 41.2% | +2.7% |

## Known Limitations
1. **Low Specificity:** Model catches only 41% of CRLs - biased toward approval predictions
2. **Social Signal Saturation:** w_social hitting bounds suggests need for expanded range
3. **Gene Therapy Risk:** CMC complexity not fully captured for novel modalities
4. **Phase 3 ≠ PDUFA:** Readout predictions less reliable than decision predictions

---

# NEXT STEPS & RECOMMENDATIONS

## Immediate Actions
1. **Refresh Social Data:** LunarCrush signals may be stale - run batch enrichment before trading
2. **Monitor Q1 2026 Catalysts:** TVTX (Jan 13), TPNT (Jan 28), AQST (Jan 31) are imminent
3. **Track Pelacarsen (NVS):** "Biggest biotech event of 2026" - high market impact

## V7.1 Development Priorities
1. Expand w_social bounds from [0, 5] to [0, 15]
2. Add max_spec objective to improve CRL detection
3. Implement feature ablation analysis
4. Fix integer overflow in MCC calculation (use float64)

## Data Enrichment Gaps
- ~280 tickers still need LunarCrush data
- Supply chain signals (CDMO shipments) not yet integrated
- Manufacturing risk field needs validation

## Validation Framework
1. Continue T-1 compliance audits
2. Test combined signals (BTD + Positive Phase 3 = 98.6% approval)
3. Monitor 2026 predictions vs actual outcomes for model calibration

---

# APPENDIX: COMPLETE 2026 CATALYST DATA

\`\`\`csv
Date,Ticker,Company,Asset,Indication,Type,ODIN_Probability,Prediction,Confidence,Risk_Factors,Positive_Factors,Notes
2026-01-13,TVTX,Travere Therapeutics,Sparsentan (Filspari),Focal Segmental Glomerulosclerosis,PDUFA,0.8112,APPROVAL,UNCERTAIN,None,"Fast Track (+0.003), Experienced Sponsor (+0.011)",sNDA for FSGS; first-in-class if approved
2026-01-28,TPNT,Tenpoint Therapeutics,Brimochol PF,Presbyopia,PDUFA,0.7976,CRL RISK,LOW,None,None,Fixed-dose brimonidine/carbachol
2026-01-31,AQST,Aquestive Therapeutics,Anaphylm,Anaphylaxis,PDUFA,0.8096,CRL RISK,UNCERTAIN,Mfg Risk + Inexperienced (-0.019),Priority Review (+0.031),Sublingual epinephrine film; FDA deficiencies noted
2026-02-08,RGNX,REGENXBIO,RGX-121 (clemidsogene),Hunter Syndrome (MPS II),PDUFA,0.8828,APPROVAL,MODERATE,"Mfg Risk + Inexperienced (-0.019), Designation stack x4 (-0.012)","BTD (+0.036), Priority Review (+0.031), Fast Track (+0.003)",First gene therapy for Hunter syndrome; CNS delivery
2026-02-15,REGN,Regeneron,Dupilumab (Dupixent),Allergic Fungal Rhinosinusitis,PDUFA,0.9869,APPROVAL,HIGH,None,"Priority Review (+0.031), Experienced Sponsor (+0.011), Bullish Social (+0.148)",sNDA label expansion; Phase 3 positive
2026-02-20,MRK,Merck,Pembrolizumab (Keytruda),Platinum-resistant Ovarian Cancer,PDUFA,0.9900,APPROVAL,HIGH,None,"Experienced Sponsor (+0.011), Oncology (+0.223)",KEYNOTE-B96; combo with paclitaxel
2026-02-28,ASND,Ascendis Pharma,TransCon CNP (navepegritide),Achondroplasia,PDUFA,0.8112,APPROVAL,UNCERTAIN,None,"Fast Track (+0.003), Experienced Sponsor (+0.011)",Once-weekly CNP prodrug; ApproaCH trial positive
2026-02-28,RAXONE,Chiesi/Santhera,Raxone (idebenone),Leber Hereditary Optic Neuropathy,PDUFA,0.8085,CRL RISK,UNCERTAIN,None,Experienced Sponsor (+0.011),EU approved; mitochondrial disease
2026-03-06,BMY,Bristol Myers Squibb,Deucravacitinib (Sotyktu),Psoriatic Arthritis,PDUFA,0.8085,CRL RISK,UNCERTAIN,None,Experienced Sponsor (+0.011),First TYK2 inhibitor for PsA; POETYK trials
2026-03-15,LLY,Eli Lilly,Orforglipron,Obesity/Weight Management,PDUFA,0.9070,APPROVAL,HIGH,None,"Experienced Sponsor (+0.011), Bullish Social (+0.099)",Oral GLP-1; National Priority Voucher
2026-03-16,ALDX,Aldeyra Therapeutics,Reproxalap,Dry Eye Disease,PDUFA,0.7976,CRL RISK,LOW,None,None,Extended PDUFA; RASP inhibitor; mixed trial history
2026-03-20,RYTM,Rhythm Pharmaceuticals,Imcivree (setmelanotide),Acquired Hypothalamic Obesity,PDUFA,0.8085,CRL RISK,UNCERTAIN,None,Experienced Sponsor (+0.011),sNDA label expansion
2026-03-28,RCKT,Rocket Pharmaceuticals,Kresladi (marnetegragene),Leukocyte Adhesion Deficiency Type I,PDUFA,0.8360,APPROVAL,UNCERTAIN,"Mfg Risk + Inexperienced (-0.019), Designation stack x3 (-0.009)","BTD (+0.036), Priority Review (+0.031)",BLA resubmission; 100% survival in trials
2026-04-06,ORCA,Orca Bio,Orca-T,AML/ALL/MDS,PDUFA,0.9900,APPROVAL,HIGH,"Mfg Risk + Inexperienced (-0.019), Designation stack x3 (-0.009)","BTD (+0.036), Priority Review (+0.031), Oncology (+0.223)",Allogeneic cell therapy; Precision-T Phase 3 positive
2026-H1,NVS,Novartis/Ionis,Pelacarsen,Lp(a)-driven Cardiovascular Disease,Phase 3 Readout,0.8610,APPROVAL,MODERATE,None,"Fast Track (+0.003), Experienced Sponsor (+0.011), Bullish Social (+0.049)",Lp(a)HORIZON - biggest biotech event of 2026
2026-H1,VRTX,Vertex,Povetacicept,IgA Nephropathy,Phase 3 Interim,0.9060,APPROVAL,HIGH,None,"Experienced Sponsor (+0.011), Bullish Social (+0.099)",RAINER trial; from Alpine acquisition
2026-H1,LLY,Eli Lilly,Remternetug,Alzheimer's Disease,Phase 3 Readout,0.9900,APPROVAL,HIGH,None,"BTD (+0.036), Fast Track (+0.003), Experienced Sponsor (+0.011)",TRAILRUNNER-ALZ 1; amyloid antibody
2026-H1,NTLA,Intellia Therapeutics,NTLA-2002 (Lonvo-z),Hereditary Angioedema,Phase 3 Readout,0.8080,CRL RISK,UNCERTAIN,"Mfg Risk + Inexperienced (-0.019), Designation stack x3 (-0.009)","BTD (+0.036), Fast Track (+0.003)",CRISPR gene editing; functional cure potential
2026-H1,MNMD,MindMed,MM120,Generalized Anxiety Disorder,Phase 3 Readout,0.8806,APPROVAL,MODERATE,None,"BTD (+0.036), CNS (+0.047)",Voyage trial; LSD-based; BTD for GAD
2026-H1,PFE,Pfizer/Valneva,VLA15,Lyme Disease Prevention,Phase 3 Readout,0.8484,APPROVAL,UNCERTAIN,None,"BTD (+0.036), Fast Track (+0.003), Experienced Sponsor (+0.011)",VALOR trial; first Lyme vaccine in decades
2026-Q1,RGNX,REGENXBIO,RGX-202,Duchenne Muscular Dystrophy,Phase 3 Readout,0.7809,CRL RISK,LOW,Mfg Risk + Inexperienced (-0.019),Fast Track (+0.003),Microdystrophin gene therapy; vs Elevidys
2026-Q1,VRDN,Viridian Therapeutics,VRDN-003,Thyroid Eye Disease,Phase 3 Readout,0.8004,CRL RISK,UNCERTAIN,None,Fast Track (+0.003),REVEAL-1 trial; IGF-1R inhibitor
2026-Q1,IDYA,IDEAYA Biosciences,Darovasertib + Crizotinib,Metastatic Uveal Melanoma,Phase 3 Readout,0.9900,APPROVAL,HIGH,Designation stack x2 (-0.006),"BTD (+0.036), Oncology (+0.223)",OptimUM-02; median PFS data
\`\`\`

---

# SESSION METADATA

- **Session Date:** 2026-01-24
- **Previous Transcript:** /mnt/transcripts/2026-01-24-02-27-20-odin-v7-2026-catalyst-analysis-request.txt
- **Journal:** /mnt/transcripts/journal.txt
- **AI Used:** Claude (Anthropic)

---

*End of Export*

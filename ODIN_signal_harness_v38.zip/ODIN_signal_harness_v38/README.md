
# ODIN Signal Discovery Harness (v38)

This folder contains a **T-1-safe**, audit-friendly harness for ODIN's *signal discovery* workflow:

- **Signal Registry**: a single place to define candidate signals (metadata + function).
- **Marginal tests**: Baseline vs Baseline + single signal.
- **Leave-one-out ablation**: on a chosen multi-signal bundle.
- **FP-averse evaluation**: selects a decision threshold that meets **Precision ≥ 0.94** and then minimizes **FP count**.

## Quickstart

```bash
python run_v38a_signal_discovery.py \
  --dataset /mnt/data/ODIN_ENRICHED_PDUFA_1349_v2.csv \
  --baseline-config /mnt/data/ODIN_v88_UNIFIED_CONFIG.json \
  --outdir /mnt/data/odin_runs/v38.a \
  --version v38.a
```

Outputs:
- `marginal_tests.csv`
- `run_manifest.json` (includes immutable `run_hash`)
- (optional) `ablations.csv`

## Built-in signals (initial)

Backtestable now (from the core dataset):
- `rolling_t1_reference_base_rate` (base prior override)
- `adcom_vote_curve` (continuous vote% curve adjustment)
- `trap_v2_stack4_inexp_non_orphan`
- `form_483_flag`

Stubbed (requires enrichment columns):
- `publication_velocity` (PubMed recent vs lifetime)

Add more signals by registering them in `build_registry()`.

## Design constraints

- **Improvement-only**: this harness only evaluates historical rows; it does not make forward predictions.
- **T-1 compliance**: rolling base rates are computed using only *prior* events (strictly before the row's `catalyst_date`).
- **UNKNOWN stays UNKNOWN**: missing values are treated as neutral (no imputation to True/False).


#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List, Optional

# Ensure local package is importable when running as a script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd

from odin_signal_harness.registry import SignalRegistry
from odin_signal_harness.runner import RunSettings, run_ablation, run_marginal_tests, write_run_artifacts, validate_t_minus_1
from odin_signal_harness.signals_builtin import (
    signal_adcom_vote_curve,
    signal_form483_flag,
    signal_publication_velocity_stub,
    signal_rolling_t1_base_rate,
    signal_trap_v2,
)


from odin_signal_harness.registry import SignalRegistry
from odin_signal_harness.runner import RunSettings, run_ablation, run_marginal_tests, write_run_artifacts, validate_t_minus_1
from odin_signal_harness.signals_builtin import (
    signal_adcom_vote_curve,
    signal_form483_flag,
    signal_publication_velocity_stub,
    signal_rolling_t1_base_rate,
    signal_trap_v2,
)


def build_registry() -> SignalRegistry:
    reg = SignalRegistry()
    reg.register(signal_trap_v2())
    reg.register(signal_form483_flag())
    reg.register(signal_adcom_vote_curve())
    reg.register(signal_rolling_t1_base_rate(min_n=20, group_cols=("therapeutic_area", "modality")))
    # Stub (won't run until enrichment columns are present)
    reg.register(signal_publication_velocity_stub())
    return reg


def main() -> None:
    ap = argparse.ArgumentParser(description="ODIN v38 signal-discovery harness (marginal tests + ablation).")
    ap.add_argument("--dataset", required=True, help="Path to ODIN dataset CSV (T-1 safe).")
    ap.add_argument("--baseline-config", required=True, help="Path to baseline config JSON (v8.8 unified recommended).")
    ap.add_argument("--outdir", required=True, help="Output directory for run artifacts.")
    ap.add_argument("--version", default="v38.a", help="Version tag (e.g., v38.a).")
    ap.add_argument("--precision-floor", type=float, default=0.94, help="Hard precision floor.")
    ap.add_argument("--min-prob", type=float, default=0.05, help="Clamp min probability.")
    ap.add_argument("--max-prob", type=float, default=0.95, help="Clamp max probability.")
    ap.add_argument("--fixed-threshold", type=float, default=None, help="Optional fixed threshold evaluation.")
    ap.add_argument("--signals", default=None, help="Comma-separated list of signals to test (default: all computable).")
    ap.add_argument("--ablate", default=None, help="Comma-separated list of signals for leave-one-out ablation.")
    args = ap.parse_args()

    df = pd.read_csv(args.dataset)
    with open(args.baseline_config, "r") as f:
        cfg = json.load(f)

    reg = build_registry()
    settings = RunSettings(
        version=args.version,
        precision_floor=args.precision_floor,
        min_prob=args.min_prob,
        max_prob=args.max_prob,
        fixed_threshold=args.fixed_threshold,
    )

    signal_names: Optional[List[str]] = None
    if args.signals:
        signal_names = [s.strip() for s in args.signals.split(",") if s.strip()]

    marginal = run_marginal_tests(df, cfg, reg, settings, signal_names=signal_names)

    ablation_df = None
    if args.ablate:
        active = [s.strip() for s in args.ablate.split(",") if s.strip()]
        ablation_df = run_ablation(df, cfg, reg, settings, active_signals=active)

    run_hash = write_run_artifacts(
        args.outdir,
        settings=settings,
        dataset_path=args.dataset,
        baseline_config_path=args.baseline_config,
        marginal_df=marginal,
        ablation_df=ablation_df,
        extra_manifest={
            "signals_registered": reg.list_names(),
            **validate_t_minus_1(df),
        },
    )

    print(f"Run complete. run_hash={run_hash}")
    print(f"Artifacts written to: {os.path.abspath(args.outdir)}")


if __name__ == "__main__":
    main()

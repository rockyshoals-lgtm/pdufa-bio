# ODIN Migration Package - START HERE

**Date:** January 28, 2026
**Status:** 🔴 CRITICAL ISSUE FOUND

## Quick Summary

We discovered that the `manufacturing_risk` feature in ODIN v9.2 is **outcome-derived** (data leakage), not T-1 compliant.

**Evidence:**
- For Small Molecules: 0% of APPROVED have mfg_risk, but 82.3% of CRLs do
- Chi-squared p-value: 1.76e-81 (statistically impossible if pre-assigned)

## Files in This Package

| File | Description |
|------|-------------|
| `README_START_HERE.md` | This file |
| `ODIN_T1_COMPLIANCE_MIGRATION_2026-01-28.md` | Full migration document with all findings |
| `ODIN_v92_CHAMPION_CONFIG.json` | Current champion (CONTAINS LEAKAGE) |
| `ODIN_v91_CHAMPION_CONFIG.json` | Previous version |
| `odin_v91_config.py` | Config module with scoring logic |
| `lunarcrush_cache.json` | Social sentiment for 294 tickers |
| `LUNARCRUSH_ENRICHMENT_PROGRESS.md` | Social enrichment status |
| `CLAUDE_PROMPT_ODIN_MIGRATION_REVIEW.md` | Original review prompt |

## Next Steps

1. **Read** `ODIN_T1_COMPLIANCE_MIGRATION_2026-01-28.md` for full context
2. **Fix** the manufacturing_risk feature (remove or replace with modality-based proxy)
3. **Re-run** GPU optimization without leakage
4. **Validate** on holdout data

## The Key Fix Needed

```python
# OPTION A: Remove entirely
# Comment out all manufacturing_risk logic

# OPTION B: Replace with T-1 compliant modality-based proxy
MODALITY_COMPLEXITY = {
    "Cell/Gene Therapy": 0.65,
    "RNA Therapy": 0.63,
    "Vaccine": 0.62,
    "ADC": 0.50,
    "Antibody": 0.27,
    "Peptide": 0.08,
    "Small Molecule": 0.00,
}
```

The dataset file (ODIN_ENRICHED_PDUFA_1349_v2.csv) is in the project files.

# ODIN LunarCrush Enrichment Progress Report

**Last Updated:** 2026-01-22 19:45:06 UTC  
**Session:** 2026-01-22  
**Status:** IN PROGRESS

---

## Cache Summary

**Total Tickers Cached:** 14 / 294 (4.8%)  
**Remaining:** 280 tickers

### Signal Distribution

| Classification | Count | Tickers |
|----------------|-------|---------|
| **BULLISH** | 3 | IBRX (+0.05), MRNA (+0.05), REGN (+0.03) |
| **NEUTRAL** | 10 | ATRA, FBIO, PRAX, AXSM, AQST, VNDA, CYTK, SNDX, BMRN, ALNY |
| **BEARISH** | 1 | SRPT (-0.04) |

---

## Latest Additions (This Session)

### MRNA - Moderna Inc âœ… BULLISH (+0.05)
- **Sentiment:** 79% | **Galaxy Score:** 65.7 | **AltRank:** 139
- **Engagements:** 371K (3.2x daily avg = spike trigger)
- **Key Catalyst:** mRNA-4157/Keytruda cancer vaccine 5-year data showing 49% melanoma risk reduction
- **Signal Breakdown:**
  - S17 (Sentiment): +0.03 (79% = bullish)
  - S18 (Engagement Spike): +0.02 (3.2x avg with bullish sentiment)

### BMRN - BioMarin Pharmaceutical âœ… NEUTRAL (+0.01)
- **Sentiment:** 70% | **Galaxy Score:** 58.2 | **AltRank:** 935
- **Engagements:** 8K (below daily avg)
- **Key Insight:** Near 52-week low despite FDA approval momentum; Inozyme acquisition
- **Signal Breakdown:** S17: +0.01 (70% = mildly bullish)

### ALNY - Alnylam Pharmaceuticals âœ… NEUTRAL (0.00)
- **Sentiment:** 68% | **Galaxy Score:** 45.8 | **AltRank:** 417
- **Engagements:** 5K (below daily avg)
- **Key Catalysts:** HELIOS-B positive data, Amvuttra strong sales, ZENITH P3 initiated
- **Signal Breakdown:** All signals neutral

### SRPT - Sarepta Therapeutics âš ï¸ BEARISH (-0.04)
- **Sentiment:** 59% | **Galaxy Score:** 31.5 | **AltRank:** 889
- **Engagements:** 11K (down 78% from weekly avg)
- **Key Concerns:** Elevidys Q4 sales miss, gene therapy patient deaths, regulatory scrutiny
- **Price Action:** -81% from 1-year high, currently $21.70
- **Signal Breakdown:**
  - S17 (Sentiment): -0.02 (59% = cautious zone)
  - S20 (Smart Money): -0.02 (Galaxy 31.5 = divergence signal)

### REGN - Regeneron Pharmaceuticals âœ… BULLISH (+0.03)
- **Sentiment:** 78% | **Galaxy Score:** 59.7 | **AltRank:** 241
- **Engagements:** 17K
- **Key Catalysts:** Dupixent COPD launch, BofA upgrade to Buy ($860 PT), Michael Burry investment
- **Signal Breakdown:** S17: +0.03 (78% = bullish)

---

## Files

- **Cache:** `/home/claude/lunarcrush_cache.json`
- **Enrichment Module:** `/home/claude/odin_lunarcrush_enrichment.py`
- **Batch Script:** `/home/claude/odin_lunarcrush_batch_enrich.py`

---

## Next Priority Tickers

Based on 2025-2026 PDUFA dates:
1. LLY, AZN, AMGN, JNJ, PFE, BIIB, NVO, VRTX, GSK, NVS
2. APTO (Feb 2026), INDV (Feb 2026), GLSI (Mar 2026), TLX (Mar 2026)
3. High-value tickers: ABBV, INCY, SWTX, MIRM, SPRY

---

## Resume Instructions

To continue this enrichment in a new session:
1. Upload this progress file and `lunarcrush_cache.json`
2. Run: "Continue ODIN LunarCrush enrichment from the cache"
3. Priority: Query remaining 280 tickers, starting with imminent PDUFAs

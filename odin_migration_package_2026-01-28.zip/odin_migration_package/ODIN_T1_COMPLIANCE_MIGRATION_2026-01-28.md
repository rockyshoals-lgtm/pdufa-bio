# ODIN T-1 Compliance Audit Migration File

**Date:** January 28, 2026  
**Session Status:** IN PROGRESS - Critical Finding Discovered  
**Priority:** 🔴 CRITICAL - Data Leakage Confirmed

---

## Executive Summary

We were reviewing Perplexity's T-1 compliance audit of ODIN v9.2. The audit raised 3 issues, but upon deep analysis:

| Audit Claim | My Assessment | Status |
|-------------|---------------|--------|
| Issue #1: Temporal boost leakage | ❌ FALSE ALARM for production | Valid only for backtest methodology |
| Issue #2: Missing feature lookback | ❌ FALSE ALARM | Features mentioned don't exist in dataset |
| Issue #3: Checkpoint metadata | ⚠️ NICE TO HAVE | Good practice, not leakage |
| **NEW DISCOVERY: manufacturing_risk** | 🔴 **CRITICAL LEAKAGE** | Confirmed via statistical analysis |

---

## 🔴 CRITICAL FINDING: `manufacturing_risk` IS OUTCOME-DERIVED

### The Smoking Gun

```
Manufacturing risk rate by modality AND outcome:

Small Molecule:
  APPROVED: 0.0% have mfg_risk (n=698)
  CRL:      82.3% have mfg_risk (n=124)

Antibody:
  APPROVED: 23.8% have mfg_risk (n=340)
  CRL:      54.3% have mfg_risk (n=46)

Cell/Gene Therapy:
  APPROVED: 62.3% have mfg_risk (n=53)
  CRL:      100.0% have mfg_risk (n=4)

Chi-squared test: chi2=365.5, p=1.76e-81
```

### What This Means

**If `manufacturing_risk` was assigned BEFORE knowing outcome (T-1 compliant):**
- Approved and CRL events of the same modality should have SIMILAR mfg_risk rates

**What we actually see:**
- **ZERO** approved Small Molecules have `manufacturing_risk=True`
- **82.3%** of CRL Small Molecules have `manufacturing_risk=True`
- This is statistically impossible if assigned pre-outcome (p < 10^-80)

### Conclusion

The `manufacturing_risk` field was **retroactively assigned based on CRL outcome**, not based on pre-decision manufacturing complexity signals. This is **severe T-1 data leakage**.

### Impact on Model Performance

The ODIN v9.2 champion config applies:
```json
"modality_mfg_penalties": {
    "Small Molecule": -0.45,  // -45% when mfg_risk=True
    ...
}
```

Since `manufacturing_risk=True` perfectly predicts CRLs for Small Molecules, the model is essentially "cheating" - it knows the outcome before predicting.

**Estimated inflation:** 10-20% of reported accuracy may be due to this leakage.

---

## Files in This Migration Package

### Core Config Files
1. `ODIN_v92_CHAMPION_CONFIG.json` - Current champion (CONTAINS LEAKAGE)
2. `odin_v91_config.py` - Previous version config
3. `ODIN_v91_CHAMPION_CONFIG.json` - Previous champion

### Dataset
4. `ODIN_ENRICHED_PDUFA_1349_v2.csv` - Full dataset (in project files)

### Audit Materials
5. `ODIN_T1_AUDIT_PERPLEXITY.md` - Original Perplexity audit (partial, see below)
6. `lunarcrush_cache.json` - Social sentiment data (294 tickers)

### Progress Tracking
7. `LUNARCRUSH_ENRICHMENT_PROGRESS.md` - Social enrichment status

---

## What Needs To Happen Next

### Immediate Actions (Before Any Production Use)

#### 1. Fix `manufacturing_risk` Feature

**Option A: Remove entirely**
```python
# In scoring function, comment out:
# if event.get('manufacturing_risk'):
#     prob += modality_mfg_penalties[modality]
```

**Option B: Replace with T-1 compliant proxy**
Create a new feature based on MODALITY ONLY (not outcome):
```python
MODALITY_COMPLEXITY = {
    "Cell/Gene Therapy": 0.65,  # High manufacturing complexity
    "RNA Therapy": 0.63,
    "Vaccine": 0.62,
    "ADC": 0.50,
    "Antibody": 0.27,
    "Peptide": 0.08,
    "Small Molecule": 0.00,  # Baseline
}

# T-1 compliant: based on modality, not outcome
manufacturing_complexity = MODALITY_COMPLEXITY.get(modality, 0.0)
```

#### 2. Re-run GPU Optimization

After fixing the feature:
```bash
python odin_v92_gpu_optimizer.py --configs 1000000000 --output ODIN_v92_FIXED_CHAMPION.json
```

Expected: Brier score will INCREASE (get worse) by ~0.01-0.02 once leakage is removed.

#### 3. Validate Holdout Performance

Re-test on 2024-2026 holdout with fixed model to get TRUE out-of-sample performance.

---

## Dataset Column T-1 Compliance Status

| Column | T-1 Status | Rationale |
|--------|------------|-----------|
| `btd` | ✅ SAFE | Announced months before PDUFA |
| `orphan` | ✅ SAFE | Granted years before PDUFA |
| `priority_review` | ✅ SAFE | Granted at filing (6+ months before) |
| `fast_track` | ✅ SAFE | Granted during development |
| `accelerated_approval` | ✅ SAFE | Pathway announced at filing |
| `had_adcom` | ✅ SAFE | Scheduled 60-90 days before PDUFA |
| `adcom_vote_pct` | ✅ SAFE | AdCom occurs before PDUFA |
| `prior_crl` | ✅ SAFE | From PREVIOUS decision cycle |
| `resubmission_class` | ✅ SAFE | Published with resubmission |
| `therapeutic_area` | ✅ SAFE | Static drug attribute |
| `modality` | ✅ SAFE | Static drug attribute |
| `sponsor_prior_approvals` | ⚠️ CHECK | Verify calculated as-of event date |
| `form_483_issues` | ⚠️ CHECK | Currently all FALSE - verify source |
| `manufacturing_risk` | 🔴 LEAKAGE | Outcome-derived, must fix |
| `year` | ✅ SAFE | PDUFA date is publicly scheduled |

---

## ODIN v9.2 Champion Config (For Reference)

```json
{
  "version": "9.2",
  "performance": {
    "brier": 0.06570,  // INFLATED DUE TO LEAKAGE
    "tier4_crl_rate": 0.9904,
    "tier4_count": 104,
    "crl_recall": 0.7611
  },
  "champion_params": {
    "btd_weight": 0.0253,
    "orphan_weight": 0.0193,
    "priority_review_weight": 0.0240,
    "fast_track_weight": 0.0146,
    "accelerated_approval_weight": 0.0295,
    "no_designation_penalty": -0.0211,
    "btd_pr_synergy_bonus": 0.1145,
    "btd_alone_bonus": 0.0427,
    "full_stack_bonus": 0.0226,
    "adcom_high_boost": 0.0955,
    "adcom_mid_penalty": -0.0722,
    "adcom_low_penalty": -0.0815,
    "prior_crl_penalty": -0.0636,
    "class1_resubmission_boost": 0.0931,
    "class2_resubmission_penalty": -0.0578,
    "sponsor_one_approval_penalty": -0.0216,
    "sponsor_sweet_spot_boost": 0.0902,
    "sponsor_mid_tier_penalty": -0.0158,
    "sponsor_large_pharma_boost": 0.0289,
    "form_483_penalty": -0.1438,
    "ta_adjustment_weight": 0.6127,
    "temporal_2024_plus_boost": 0.0788,
    "tier1_threshold": 0.8322,
    "tier2_threshold": 0.7068,
    "tier3_threshold": 0.6111
  },
  "modality_mfg_penalties": {
    "Small Molecule": -0.45,  // 🔴 LEAKAGE - Applied when mfg_risk=True
    "Antibody": -0.15,
    "Cell/Gene Therapy": -0.08,
    "RNA Therapy": -0.08,
    "Peptide": -0.12,
    "Vaccine": -0.05,
    "ADC": -0.12
  }
}
```

---

## Session Transcript Location

Full conversation transcript available at:
```
/mnt/transcripts/2026-01-28-07-04-43-odin-v92-gpu-memory-management.txt
```

Previous session transcripts:
```
/mnt/transcripts/2026-01-28-07-00-00-odin-v92-gpu-fix-lunarcrush-complete.txt
/mnt/transcripts/2026-01-28-07-02-01-odin-v92-gpu-broadcast-fix.txt
```

---

## Perplexity Audit Summary (Original Claims)

The audit claimed 3 issues:

1. **Temporal Data Leakage** (temporal_2024_plus_boost)
   - My assessment: FALSE ALARM for production predictions
   - Valid concern only for backtest parameter calibration
   
2. **Missing Feature Lookback Validation**
   - My assessment: FALSE ALARM - features mentioned don't exist
   - The audit mentioned `insider_trade`, `sponsor_news`, `fda_announcement` - these aren't in our dataset

3. **Checkpoint Metadata**
   - My assessment: Good practice, but not leakage
   - Recommendation: Add `data_cutoff_date` to checkpoints for auditability

---

## Key Statistical Evidence

### manufacturing_risk Distribution

```
Total events: 1,349
  manufacturing_risk=False: 1,064 (78.9%)
  manufacturing_risk=True:    285 (21.1%)

By outcome:
  manufacturing_risk=False: 1,020 APPROVED, 44 CRL (4.1% CRL rate)
  manufacturing_risk=True:    149 APPROVED, 136 CRL (47.7% CRL rate)
```

### The Impossible Pattern

For Small Molecules specifically:
- 698 Approved → **0** have manufacturing_risk=True (0.0%)
- 124 CRL → **102** have manufacturing_risk=True (82.3%)

This is statistically impossible if the feature was assigned pre-outcome.

---

## Resume Instructions for Next Session

1. **Load this migration file** - It contains full context
2. **Review the manufacturing_risk issue** - This is the critical finding
3. **Implement fix Option A or B** - Remove or replace the leaky feature
4. **Re-run optimization** - Generate new champion without leakage
5. **Validate on holdout** - Confirm true out-of-sample performance

---

## Contact/Handoff Notes

**User:** David (ODIN developer)  
**System:** ODIN v9.2 - FDA PDUFA Prediction System  
**Hardware:** Windows, RTX 4070 (12GB VRAM)  
**Tools:** CuPy GPU optimization, Python, pandas

**Key APIs:**
- LunarCrush (social sentiment) - 294 tickers cached
- FinBrain (options flow, insider trades)
- Clinical Trials MCP
- Open Targets MCP

---

*Migration file generated: January 28, 2026*
*Status: Critical leakage found, fix required before production use*

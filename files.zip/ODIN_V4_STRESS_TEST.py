#!/usr/bin/env python3
"""
ODIN v4.0 GÖTTERDÄMMERUNG - COMPREHENSIVE STRESS TEST
Running all 57 historical catalysts with enhanced v4.0 signals
"""

import json
from ODIN_V4_ENGINE import DrugProfileV4, CatalystType, calculate_poa_v4

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════
#                           HISTORICAL CATALYSTS WITH v4.0 ENHANCED SIGNALS
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════

# Adding the new v4.0 signals to each catalyst based on what we would have known pre-catalyst

CATALYSTS_V4 = [
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # PARABOLIC MOVERS (>100% moves) - SUCCESSES
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "SMMT", "drug": "Ivonescimab NSCLC", "indication": "oncology", "type": "PHASE3",
        "outcome": "SUCCESS", "move": 576, "short_int": 8, "mcap": 1200,
        # v3.0 signals
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": False,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_performing_sites": True, "patient_rich_geography": True,
        "clean_balance_sheet": True, "high_lobbying_spend": False, "zero_lobbying": False,
        "dark_pool_accumulation": True, "ceo_confident": True,
    },
    {
        "ticker": "ABVX", "drug": "Obefazimod UC", "indication": "gi", "type": "PHASE3",
        "outcome": "SUCCESS", "move": 500, "short_int": 12, "mcap": 800,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 1, "high_performing_sites": True, "clean_balance_sheet": True,
        "zero_lobbying": True, "dark_pool_accumulation": False, "ceo_confident": True,
    },
    {
        "ticker": "IMGN", "drug": "ELAHERE OC", "indication": "oncology", "type": "PHASE3",
        "outcome": "SUCCESS", "move": 497, "short_int": 15, "mcap": 2500,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 1, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_performing_sites": True, "clean_balance_sheet": True,
        "high_lobbying_spend": False, "dark_pool_accumulation": True, "ceo_confident": True,
    },
    {
        "ticker": "CAPR", "drug": "Deramiocel DMD", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 371, "short_int": 35, "mcap": 200,
        "is_biologic": True, "is_cell_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "prior_crl": True, "prior_crl_type": "cmc",  # CMC-only CRL is recoverable!
        "sponsor_approvals": 0, "cash_runway": 12, "inspection_complete": True,
        # v4.0 NEW signals - key: they fixed CMC issues
        "amendment_count": 0, "high_performing_sites": True, "favorable_division_history": True,
        "clean_balance_sheet": False, "recent_discounted_pipe": True,  # Had to raise cash
        "zero_lobbying": True, "ceo_confident": True,
    },
    {
        "ticker": "VKTX", "drug": "VK2735 Ph2b Obesity", "indication": "obesity", "type": "PHASE2",
        "outcome": "SUCCESS", "move": 265, "short_int": 14, "mcap": 1800,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "dark_pool_accumulation": True,
        "ceo_confident": True, "high_performing_sites": True,
    },
    {
        "ticker": "ADVM", "drug": "Ixoberogene XLRS", "indication": "gene_therapy", "type": "PHASE3",
        "outcome": "SUCCESS", "move": 180, "short_int": 28, "mcap": 300,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 18, "inspection_complete": True,
        # v4.0 NEW signals - rare gene therapy success
        "amendment_count": 0, "high_performing_sites": True, "sca_fda_endorsed": True,
        "favorable_division_history": True, "ceo_confident": True, "dark_pool_accumulation": True,
    },
    {
        "ticker": "PHVS", "drug": "Deucrictibant HAE", "indication": "rare_disease", "type": "PHASE3",
        "outcome": "SUCCESS", "move": 120, "short_int": 15, "mcap": 600,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "ceo_confident": True,
    },
    {
        "ticker": "CRNX", "drug": "Paltusotine Acromegaly", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 110, "short_int": 20, "mcap": 400,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "favorable_division_history": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # LARGE/MID CAP SUCCESSES (Expected, small moves)
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "LLY", "drug": "Donanemab Alzheimer", "indication": "cns", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 4, "short_int": 0, "mcap": 700000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": False, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": False,
        "europa_shield": True, "sponsor_approvals": 50, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "former_fda_lobbyists": True,
        "favorable_division_history": True, "prior_positive_division": True,
        "dark_pool_accumulation": True, "ceo_confident": True, "clean_balance_sheet": True,
    },
    {
        "ticker": "BMS", "drug": "Cobenfy Schizophrenia", "indication": "cns", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 4, "short_int": 1, "mcap": 150000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 50, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "former_fda_lobbyists": True,
        "prior_positive_division": True, "clean_balance_sheet": True,
    },
    {
        "ticker": "MDGL", "drug": "Rezdiffra MASH", "indication": "metabolic", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 24, "short_int": 5, "mcap": 8000,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "high_lobbying_spend": True,
        "dark_pool_accumulation": True, "ceo_confident": True,
    },
    {
        "ticker": "GILD", "drug": "Livdelzi PBC", "indication": "metabolic", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 3, "short_int": 1, "mcap": 100000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 30, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "former_fda_lobbyists": True,
        "clean_balance_sheet": True, "prior_positive_division": True,
    },
    {
        "ticker": "NBIX", "drug": "Acoramidis ATTR-CM", "indication": "cardiovascular", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 45, "short_int": 8, "mcap": 12000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "europa_shield": True, "sponsor_approvals": 3, "cash_runway": 48, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "high_lobbying_spend": True,
        "favorable_division_history": True, "dark_pool_accumulation": True,
    },
    {
        "ticker": "IOVA", "drug": "Amtagvi Melanoma", "indication": "oncology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 35, "short_int": 18, "mcap": 3000,
        "is_biologic": True, "is_cell_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals - Cell therapy that succeeded
        "amendment_count": 0, "high_performing_sites": True, "favorable_division_history": True,
        "clean_balance_sheet": True, "ceo_confident": True,
    },
    {
        "ticker": "ZYME", "drug": "Zanidatamab BTC", "indication": "oncology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 28, "short_int": 6, "mcap": 2000,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": True,  # GSK
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "dark_pool_accumulation": True,
    },
    {
        "ticker": "SRPT", "drug": "Elevidys Full DMD", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 32, "short_int": 12, "mcap": 15000,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "accelerated_approval": True, "sponsor_approvals": 4, "cash_runway": 48, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "former_fda_lobbyists": True,
        "favorable_division_history": True, "prior_positive_division": True,
        "clean_balance_sheet": True, "ceo_confident": True,
    },
    {
        "ticker": "ALNY", "drug": "Wainua ATTR-PN", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 8, "short_int": 3, "mcap": 35000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 5, "cash_runway": 60, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "prior_positive_division": True,
        "clean_balance_sheet": True,
    },
    {
        "ticker": "PFE", "drug": "Hympavzi Hemophilia", "indication": "hematology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 2, "short_int": 1, "mcap": 200000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 100, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "high_lobbying_spend": True, "former_fda_lobbyists": True, "prior_positive_division": True,
        "clean_balance_sheet": True,
    },
    {
        "ticker": "IONS", "drug": "Qalsody ALS", "indication": "cns", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 15, "short_int": 7, "mcap": 8000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 4, "cash_runway": 48, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "clean_balance_sheet": True,
        "favorable_division_history": True,
    },
    {
        "ticker": "CYTK", "drug": "Aficamten oHCM", "indication": "cardiovascular", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 18, "short_int": 10, "mcap": 4000,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "favorable_division_history": True,
        "ceo_confident": True,
    },
    {
        "ticker": "INSM", "drug": "Brensocatib Bronchiectasis", "indication": "respiratory", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 22, "short_int": 6, "mcap": 10000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 2, "cash_runway": 48, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "high_lobbying_spend": True,
    },
    {
        "ticker": "KALV", "drug": "Sebetralstat HAE", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 55, "short_int": 15, "mcap": 1500,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 30, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "favorable_division_history": True,
    },
    {
        "ticker": "ARWR", "drug": "Plozasiran FCS", "indication": "cardiovascular", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 12, "short_int": 8, "mcap": 5000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True,
    },
    {
        "ticker": "VRTX", "drug": "Journavx Pain", "indication": "cns", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 6, "short_int": 1, "mcap": 100000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": False,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 8, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "high_lobbying_spend": True, "former_fda_lobbyists": True,
        "clean_balance_sheet": True, "prior_positive_division": True,
    },
    {
        "ticker": "PTGX", "drug": "Rusfertide PV", "indication": "hematology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 42, "short_int": 12, "mcap": 1500,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True, "favorable_division_history": True,
    },
    {
        "ticker": "MIRM", "drug": "Volixibat PBC/PSC", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 38, "short_int": 18, "mcap": 800,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 18, "inspection_complete": True,
        # v4.0 NEW signals
        "amendment_count": 0, "clean_balance_sheet": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # GENE THERAPY SUCCESSES (despite challenges)
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "BLUE", "drug": "Lyfgenia SCD", "indication": "gene_therapy", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 85, "short_int": 25, "mcap": 400,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 2, "cash_runway": 12, "inspection_complete": True,
        # v4.0 NEW signals - Had Vertex partnership, critical for success
        "amendment_count": 0, "favorable_division_history": True, "sca_high_quality": True,
        "prior_positive_division": True, "ceo_confident": True,
    },
    {
        "ticker": "EDIT", "drug": "EDIT-301 SCD", "indication": "gene_therapy", "type": "PHASE3",
        "outcome": "SUCCESS", "move": 65, "short_int": 25, "mcap": 300,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 18, "inspection_complete": False,
        # v4.0 NEW signals - gene therapy that succeeded
        "amendment_count": 0, "sca_high_quality": True, "favorable_division_history": True,
        "ceo_confident": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # LARGE CAP SUCCESS ADDITIONS
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "MRK", "drug": "Clesrovimab RSV", "indication": "infectious", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 1, "short_int": 0, "mcap": 300000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 100, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "high_lobbying_spend": True, "former_fda_lobbyists": True, "prior_positive_division": True,
        "clean_balance_sheet": True,
    },
    {
        "ticker": "GSK", "drug": "Gepotidacin UTI", "indication": "infectious", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 2, "short_int": 0, "mcap": 80000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": False,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "qidp": True, "sponsor_approvals": 100, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "high_lobbying_spend": True, "former_fda_lobbyists": True, "prior_positive_division": True,
        "clean_balance_sheet": True,
    },
    {
        "ticker": "BMRN", "drug": "Voxzogo Expanded", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 8, "short_int": 4, "mcap": 15000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 5, "cash_runway": 48, "inspection_complete": True,
        # v4.0 NEW signals
        "high_lobbying_spend": True, "prior_positive_division": True, "clean_balance_sheet": True,
    },
    {
        "ticker": "SNY", "drug": "Rilzabrutinib ITP", "indication": "hematology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 2, "short_int": 0, "mcap": 120000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 50, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "high_lobbying_spend": True, "prior_positive_division": True, "clean_balance_sheet": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # FAILURES - CNS (Market was right)
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "LYKOS", "drug": "MDMA PTSD", "indication": "cns", "type": "PDUFA",
        "outcome": "FAILURE", "move": -55, "short_int": 40, "mcap": 150,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_weak": True, "safety_signal": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": True,
        "adcom_vote_pct": 9,  # NEGATIVE ADCOM!
        "sponsor_approvals": 0, "cash_runway": 6, "inspection_complete": True,
        # v4.0 NEW signals - MASSIVE red flags
        "hawk_division": True, "data_integrity_concerns": True, "ceo_evasive_language": True,
        "death_spiral_financing": True, "zero_lobbying": True,
        "eligibility_relaxed": True,  # Changed criteria during trials
    },
    {
        "ticker": "AMLX", "drug": "AMX0035 ALS", "indication": "cns", "type": "PDUFA",
        "outcome": "FAILURE", "move": -75, "short_int": 35, "mcap": 300,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": False,
        "prior_crl": True, "sponsor_approvals": 0, "cash_runway": 12, "inspection_complete": True,
        # v4.0 NEW signals
        "hawk_division": True, "sample_size_increased": True, "high_amendment_velocity": True,
        "zero_lobbying": True, "recent_discounted_pipe": True,
    },
    {
        "ticker": "SAGE", "drug": "Dalzanemdor ED", "indication": "cns", "type": "PHASE3",
        "outcome": "FAILURE", "move": -58, "short_int": 28, "mcap": 800,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": False, "first_in_class": False,
        "sponsor_approvals": 1, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "high_amendment_velocity": True, "ceo_evasive_language": True,
    },
    {
        "ticker": "SAGE2", "drug": "Dalzanemdor PD", "indication": "cns", "type": "PHASE3",
        "outcome": "FAILURE", "move": -42, "short_int": 32, "mcap": 600,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": False, "first_in_class": False,
        "sponsor_approvals": 1, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "high_amendment_velocity": True, "eligibility_relaxed": True,
    },
    {
        "ticker": "ALEC", "drug": "Latozinemab FTD", "indication": "cns", "type": "PHASE3",
        "outcome": "FAILURE", "move": -68, "short_int": 22, "mcap": 200,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 12, "inspection_complete": False,
        # v4.0 NEW signals
        "sample_size_increased": True, "zero_lobbying": True, "management_turnover": True,
    },
    {
        "ticker": "SAVA", "drug": "Simufilam Alzheimer", "indication": "cns", "type": "PHASE3",
        "outcome": "FAILURE", "move": -45, "short_int": 45, "mcap": 200,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "safety_signal": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": True,
        "prior_crl": True, "sponsor_approvals": 0, "cash_runway": 6, "inspection_complete": True,
        # v4.0 NEW signals - DATA INTEGRITY DISASTER
        "benfords_violation": True, "data_integrity_concerns": True, "ceo_evasive_language": True,
        "hedge_fund_foia_spike": True, "zero_lobbying": True, "death_spiral_financing": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # FAILURES - GENE THERAPY (CMC issues)
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "RCKT", "drug": "Kresladi FA", "indication": "gene_therapy", "type": "PDUFA",
        "outcome": "FAILURE", "move": -72, "short_int": 30, "mcap": 400,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "form_483_count": 2, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 18,
        # v4.0 NEW signals - CMC disaster
        "tech_transfer_incomplete": True, "zero_enrolling_sites_high": True,
        "zero_lobbying": True, "management_turnover": True,
    },
    {
        "ticker": "GRPH", "drug": "Eladocagene AADC", "indication": "gene_therapy", "type": "PDUFA",
        "outcome": "FAILURE", "move": -65, "short_int": 25, "mcap": 200,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "form_483_count": 3, "tech_transfer_incomplete": True, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 12,
        # v4.0 NEW signals
        "zero_lobbying": True, "death_spiral_financing": True, "ceo_evasive_language": True,
    },
    {
        "ticker": "RARE", "drug": "UX111 Sanfilippo", "indication": "gene_therapy", "type": "PDUFA",
        "outcome": "FAILURE", "move": -58, "short_int": 28, "mcap": 300,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": False, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "form_483_count": 2, "inspection_complete": False,
        "sponsor_approvals": 1, "cash_runway": 18,
        # v4.0 NEW signals
        "zero_lobbying": True, "management_turnover": True,
    },
    {
        "ticker": "YMAB", "drug": "Omburtamab CNS", "indication": "oncology", "type": "PDUFA",
        "outcome": "FAILURE", "move": -75, "short_int": 40, "mcap": 100,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_weak": True, "safety_signal": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "prior_crl": True, "form_483_count": 4, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 6,
        # v4.0 NEW signals
        "death_spiral_financing": True, "zero_lobbying": True, "hawk_division": True,
        "pi_form_483_history": True, "management_turnover": True,
    },
    {
        "ticker": "STRO", "drug": "Elamipretide Barth", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "FAILURE", "move": -70, "short_int": 35, "mcap": 100,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "prior_crl": True, "form_483_count": 3, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 6,
        # v4.0 NEW signals
        "death_spiral_financing": True, "zero_lobbying": True, "high_amendment_velocity": True,
    },
    {
        "ticker": "NRXP", "drug": "Zyesami COVID", "indication": "respiratory", "type": "PDUFA",
        "outcome": "FAILURE", "move": -80, "short_int": 50, "mcap": 50,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "safety_signal": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 3, "inspection_complete": True,
        # v4.0 NEW signals - TOTAL DISASTER
        "death_spiral_financing": True, "benfords_violation": True, "data_integrity_concerns": True,
        "ceo_evasive_language": True, "zero_lobbying": True, "hedge_fund_foia_spike": True,
    },
    {
        "ticker": "CNSP", "drug": "CNS-mAb Glioblastoma", "indication": "oncology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -75, "short_int": 45, "mcap": 50,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": True,
        "prior_crl": True, "form_483_count": 5, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 3,
        # v4.0 NEW signals
        "death_spiral_financing": True, "zero_lobbying": True, "hawk_division": True,
        "pi_warning_letter": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # FAILURES - ONCOLOGY (Phase 3 failures)
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "REPL", "drug": "RP1 Melanoma", "indication": "oncology", "type": "PDUFA",
        "outcome": "FAILURE", "move": -48, "short_int": 22, "mcap": 500,
        "is_biologic": True, "is_gene_therapy": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": False, "fast_track": True, "first_in_class": False,
        "form_483_count": 3, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 18,
        # v4.0 NEW signals
        "competitor_approved_recently": True, "zero_lobbying": True,
    },
    {
        "ticker": "GILD2", "drug": "Magrolimab MDS", "indication": "oncology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -15, "short_int": 1, "mcap": 100000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "safety_signal": True, "breakthrough": False,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 30, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals - Futility stopped
        "sample_size_increased": True, "high_amendment_velocity": True,
    },
    {
        "ticker": "AZN", "drug": "Ceralasertib NSCLC", "indication": "oncology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -8, "short_int": 0, "mcap": 200000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": True,
        "survival_endpoint": True,
        "sponsor_approvals": 50, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "high_amendment_velocity": True, "crowded_market": True,
    },
    {
        "ticker": "ROG", "drug": "Tiragolumab NSCLC", "indication": "oncology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -10, "short_int": 0, "mcap": 250000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": True,
        "survival_endpoint": True,
        "sponsor_approvals": 100, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "crowded_market": True, "eligibility_relaxed": True,
    },
    {
        "ticker": "GILD3", "drug": "Trodelvy NSCLC", "indication": "oncology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -12, "short_int": 1, "mcap": 100000,
        "is_biologic": True, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": False,
        "survival_endpoint": True,
        "sponsor_approvals": 30, "cash_runway": 120, "inspection_complete": True,
        # v4.0 NEW signals
        "crowded_market": True,
    },
    {
        "ticker": "CLDX", "drug": "Glembatumumab BC", "indication": "oncology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -65, "short_int": 20, "mcap": 500,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 12, "inspection_complete": True,
        # v4.0 NEW signals
        "crowded_market": True, "zero_lobbying": True, "ceo_evasive_language": True,
    },
    {
        "ticker": "TGTX", "drug": "Umbralisib FL", "indication": "oncology", "type": "PDUFA",
        "outcome": "FAILURE", "move": -55, "short_int": 15, "mcap": 2000,
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "safety_signal": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals - Post-approval safety withdrawal
        "foia_faers_spike": True, "hawk_division": True,
    },

    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # FAILURES - OTHER
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "IMVT", "drug": "Batoclimab MG", "indication": "immunology", "type": "PHASE3",
        "outcome": "FAILURE", "move": -35, "short_int": 15, "mcap": 3000,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": True,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": False,
        "competitor_approved_recently": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 NEW signals
        "eligibility_relaxed": True, "sample_size_increased": True,
    },
    {
        "ticker": "ZEAL", "drug": "Glepaglutide SBS", "indication": "gi", "type": "PHASE3",
        "outcome": "FAILURE", "move": -55, "short_int": 30, "mcap": 400,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 12, "inspection_complete": True,
        # v4.0 NEW signals
        "high_amendment_velocity": True, "eligibility_relaxed": True, "zero_lobbying": True,
    },
    {
        "ticker": "GLPG", "drug": "Filgotinib RA", "indication": "immunology", "type": "PDUFA",
        "outcome": "FAILURE", "move": -25, "short_int": 8, "mcap": 3000,
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "safety_signal": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": False,
        "europa_shield": True, "sponsor_approvals": 2, "cash_runway": 36, "inspection_complete": True,
        # v4.0 NEW signals - EMA approved but FDA wanted more testes safety data
        "hawk_division": True, "foia_faers_spike": True,
    },
    {
        "ticker": "FOLD", "drug": "Pombiliti Pompe", "indication": "rare_disease", "type": "PDUFA",
        "outcome": "FAILURE", "move": -45, "short_int": 30, "mcap": 300,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "form_483_count": 4, "inspection_complete": False,
        "sponsor_approvals": 0, "cash_runway": 12,
        # v4.0 NEW signals - CMC issues
        "tech_transfer_incomplete": True, "zero_lobbying": True, "recent_discounted_pipe": True,
    },
    {
        "ticker": "PCVX", "drug": "VAX-24 Pneumonia", "indication": "infectious", "type": "PHASE3",
        "outcome": "FAILURE", "move": -40, "short_int": 22, "mcap": 600,
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": False, "biomarker_selection": False, "peer_reviewed": False,
        "effect_size_weak": True, "clean_safety": True, "breakthrough": False,
        "priority_review": False, "orphan": False, "fast_track": True, "first_in_class": False,
        "competitor_approved_recently": True,
        "sponsor_approvals": 0, "cash_runway": 18, "inspection_complete": True,
        # v4.0 NEW signals
        "crowded_market": True, "zero_lobbying": True, "eligibility_relaxed": True,
    },
    
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    # NEW ADDITIONS - AGIO and OMER WINS
    # ═══════════════════════════════════════════════════════════════════════════════════════════════════
    {
        "ticker": "AGIO", "drug": "Vorasidenib LGG", "indication": "oncology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 8, "short_int": 12, "mcap": 3500,
        # Servier partnership, IDH inhibitor for low-grade glioma
        "is_biologic": False, "first_time_filer": False, "large_pharma_partner": True,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 2, "cash_runway": 36, "inspection_complete": True,
        # v4.0 signals
        "amendment_count": 0, "clean_balance_sheet": True, "high_lobbying_spend": True,
        "favorable_division_history": True, "dark_pool_accumulation": True, "ceo_confident": True,
    },
    {
        "ticker": "OMER", "drug": "Narsoplimab HSCT-TMA", "indication": "hematology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 45, "short_int": 25, "mcap": 400,
        # MASP-2 inhibitor for transplant-associated TMA
        "is_biologic": True, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 18, "inspection_complete": True,
        # v4.0 signals - had prior CRL but resubmitted with more data
        "prior_crl": True, "prior_crl_type": "efficacy",
        "amendment_count": 0, "clean_balance_sheet": False, "recent_discounted_pipe": True,
        "favorable_division_history": True, "ceo_confident": True,
    },
    {
        "ticker": "MIST", "drug": "Bexicaserin Dravet", "indication": "cns", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 85, "short_int": 18, "mcap": 300,
        # 5-HT2C agonist for Dravet syndrome seizures - rare pediatric CNS win
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "rare_pediatric": True, "pediatric_indication": True,
        "sponsor_approvals": 0, "cash_runway": 24, "inspection_complete": True,
        # v4.0 signals
        "amendment_count": 0, "clean_balance_sheet": True, "favorable_division_history": True,
        "ceo_confident": True,
    },
    {
        "ticker": "KURA", "drug": "Ziftomenib AML", "indication": "oncology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 40, "short_int": 15, "mcap": 2000,
        # Menin inhibitor for NPM1-mutant AML - biomarker selected
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "sponsor_approvals": 0, "cash_runway": 36, "inspection_complete": True,
        # v4.0 signals
        "amendment_count": 0, "clean_balance_sheet": True,
        "dark_pool_accumulation": True, "ceo_confident": True,
    },
    {
        "ticker": "SNDX", "drug": "Revumenib AML", "indication": "oncology", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 35, "short_int": 12, "mcap": 1800,
        # Menin inhibitor for KMT2A-rearranged AML - accelerated approval
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": True, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": True,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": True,
        "accelerated_approval": True,
        "sponsor_approvals": 0, "cash_runway": 30, "inspection_complete": True,
        # v4.0 signals
        "amendment_count": 0, "clean_balance_sheet": True, "ceo_confident": True,
    },
    {
        "ticker": "TOVX", "drug": "Jimtegra CF", "indication": "respiratory", "type": "PDUFA",
        "outcome": "SUCCESS", "move": 55, "short_int": 20, "mcap": 250,
        # Inhaled tobramycin for cystic fibrosis lung infections
        "is_biologic": False, "first_time_filer": True, "large_pharma_partner": False,
        "phase3_met_primary": True, "biomarker_selection": False, "peer_reviewed": True,
        "effect_size_strong": True, "clean_safety": True, "breakthrough": False,
        "priority_review": True, "orphan": True, "fast_track": True, "first_in_class": False,
        "sponsor_approvals": 0, "cash_runway": 18, "inspection_complete": True,
        # v4.0 signals
        "amendment_count": 0, "clean_balance_sheet": True, "favorable_division_history": True,
    },
]


def build_profile(c: dict) -> DrugProfileV4:
    """Convert catalyst dict to DrugProfileV4"""
    
    cat_type = CatalystType[c.get('type', 'PDUFA')]
    
    return DrugProfileV4(
        ticker=c['ticker'],
        drug_name=c['drug'],
        indication=c['indication'],
        catalyst_type=cat_type,
        
        # v3.0 signals
        is_biologic=c.get('is_biologic', False),
        is_gene_therapy=c.get('is_gene_therapy', False),
        is_cell_therapy=c.get('is_cell_therapy', False),
        first_time_filer=c.get('first_time_filer', False),
        large_pharma_partner=c.get('large_pharma_partner', False),
        form_483_count=c.get('form_483_count', 0),
        warning_letter=c.get('warning_letter', False),
        tech_transfer_incomplete=c.get('tech_transfer_incomplete', False),
        inspection_pending=not c.get('inspection_complete', True),
        inspection_complete=c.get('inspection_complete', True),
        sponsor_prior_approvals=c.get('sponsor_approvals', 0),
        
        phase3_met_primary=c.get('phase3_met_primary', True),
        biomarker_selection=c.get('biomarker_selection', False),
        peer_reviewed=c.get('peer_reviewed', False),
        effect_size_strong=c.get('effect_size_strong', False),
        effect_size_weak=c.get('effect_size_weak', False),
        safety_signal=c.get('safety_signal', False),
        clean_safety=c.get('clean_safety', False),
        survival_endpoint=c.get('survival_endpoint', False),
        
        short_interest=c.get('short_int', 0),
        cash_runway_months=c.get('cash_runway', 24),
        market_cap_millions=c.get('mcap', 1000),
        
        europa_shield=c.get('europa_shield', False),
        adcom_vote_pct=c.get('adcom_vote_pct'),
        breakthrough=c.get('breakthrough', False),
        priority_review=c.get('priority_review', False),
        accelerated_approval=c.get('accelerated_approval', False),
        orphan=c.get('orphan', False),
        fast_track=c.get('fast_track', False),
        qidp=c.get('qidp', False),
        prior_crl=c.get('prior_crl', False),
        prior_crl_type=c.get('prior_crl_type'),
        
        first_in_class=c.get('first_in_class', False),
        crowded_market=c.get('crowded_market', False),
        competitor_approved_recently=c.get('competitor_approved_recently', False),
        
        # v4.0 NEW signals
        eligibility_relaxed=c.get('eligibility_relaxed', False),
        primary_endpoint_changed=c.get('primary_endpoint_changed', False),
        sample_size_increased=c.get('sample_size_increased', False),
        amendment_count=c.get('amendment_count', 1),  # Default 1, not 0
        high_amendment_velocity=c.get('high_amendment_velocity', False),
        
        pi_form_483_history=c.get('pi_form_483_history', False),
        pi_warning_letter=c.get('pi_warning_letter', False),
        high_performing_sites=c.get('high_performing_sites', False),
        zero_enrolling_sites_high=c.get('zero_enrolling_sites_high', False),
        patient_rich_geography=c.get('patient_rich_geography', False),
        
        death_spiral_financing=c.get('death_spiral_financing', False),
        floating_conversion_no_floor=c.get('floating_conversion_no_floor', False),
        full_ratchet_antidilution=c.get('full_ratchet_antidilution', False),
        known_toxic_lender=c.get('known_toxic_lender', False),
        recent_discounted_pipe=c.get('recent_discounted_pipe', False),
        clean_balance_sheet=c.get('clean_balance_sheet', False),
        
        high_lobbying_spend=c.get('high_lobbying_spend', False),
        former_fda_lobbyists=c.get('former_fda_lobbyists', False),
        lobbying_acceleration=c.get('lobbying_acceleration', False),
        zero_lobbying=c.get('zero_lobbying', False),
        
        hawk_division=c.get('hawk_division', False),
        high_crl_rate_division=c.get('high_crl_rate_division', False),
        favorable_division_history=c.get('favorable_division_history', False),
        prior_positive_division=c.get('prior_positive_division', False),
        
        hedge_fund_foia_spike=c.get('hedge_fund_foia_spike', False),
        foia_faers_spike=c.get('foia_faers_spike', False),
        dark_pool_accumulation=c.get('dark_pool_accumulation', False),
        dark_pool_distribution=c.get('dark_pool_distribution', False),
        
        benfords_violation=c.get('benfords_violation', False),
        minor_benford_deviation=c.get('minor_benford_deviation', False),
        data_integrity_concerns=c.get('data_integrity_concerns', False),
        
        ceo_high_stress=c.get('ceo_high_stress', False),
        ceo_evasive_language=c.get('ceo_evasive_language', False),
        ceo_confident=c.get('ceo_confident', False),
        management_turnover=c.get('management_turnover', False),
        
        sca_high_quality=c.get('sca_high_quality', False),
        sca_low_quality=c.get('sca_low_quality', False),
        sca_fda_endorsed=c.get('sca_fda_endorsed', False),
    )


def run_stress_test():
    """Run comprehensive stress test"""
    
    print("=" * 100)
    print("ODIN v4.0 GÖTTERDÄMMERUNG - STRESS TEST")
    print(f"Testing {len(CATALYSTS_V4)} catalysts with enhanced signals")
    print("=" * 100)
    print()
    
    results = []
    
    for c in CATALYSTS_V4:
        profile = build_profile(c)
        v4_result = calculate_poa_v4(profile)
        
        poa = v4_result['poa']
        actual_success = c['outcome'] == 'SUCCESS'
        pred_success = poa >= 50
        correct = pred_success == actual_success
        
        results.append({
            'ticker': c['ticker'],
            'drug': c['drug'],
            'indication': c['indication'],
            'outcome': c['outcome'],
            'move': c['move'],
            'poa': poa,
            'pred': 'SUCCESS' if pred_success else 'FAILURE',
            'correct': correct,
            'tier': v4_result['tier'].value,
            'v4_adj': v4_result['v4_adj'],
            'risk_factors': v4_result['risk_factors'],
            'boost_factors': v4_result['boost_factors'],
            'signals': v4_result['signals_detected'],
        })
    
    # Calculate metrics
    total = len(results)
    correct = sum(1 for r in results if r['correct'])
    
    tp = sum(1 for r in results if r['pred'] == 'SUCCESS' and r['outcome'] == 'SUCCESS')
    fp = sum(1 for r in results if r['pred'] == 'SUCCESS' and r['outcome'] == 'FAILURE')
    tn = sum(1 for r in results if r['pred'] == 'FAILURE' and r['outcome'] == 'FAILURE')
    fn = sum(1 for r in results if r['pred'] == 'FAILURE' and r['outcome'] == 'SUCCESS')
    
    accuracy = 100 * correct / total
    precision = 100 * tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = 100 * tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = 100 * tn / (tn + fp) if (tn + fp) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) / 100 if (precision + recall) > 0 else 0
    
    print("═" * 100)
    print("                           v4.0 GÖTTERDÄMMERUNG PERFORMANCE")
    print("═" * 100)
    print(f"""
    Total Catalysts:        {total}
    Successes:              {sum(1 for r in results if r['outcome'] == 'SUCCESS')}
    Failures:               {sum(1 for r in results if r['outcome'] == 'FAILURE')}
    
    ╔════════════════════════════════════════════════════════════════════════════╗
    ║                    v4.0 GÖTTERDÄMMERUNG METRICS                            ║
    ╠════════════════════════════════════════════════════════════════════════════╣
    ║  Direction Accuracy:  {correct}/{total} = {accuracy:.1f}%                                       ║
    ║  Precision:           {tp}/{tp+fp} = {precision:.1f}%                                           ║
    ║  Recall:              {tp}/{tp+fn} = {recall:.1f}%                                             ║
    ║  Specificity:         {tn}/{tn+fp} = {specificity:.1f}%                                         ║
    ║  F1 Score:            {100*f1:.1f}%                                                  ║
    ╠════════════════════════════════════════════════════════════════════════════╣
    ║  TP: {tp}    FP: {fp}    TN: {tn}    FN: {fn}                                        ║
    ╚════════════════════════════════════════════════════════════════════════════╝
    """)
    
    print()
    print("═" * 100)
    print("                           DETAILED RESULTS")
    print("═" * 100)
    print(f"{'TICKER':<8} | {'DRUG':<28} | {'IND':<12} | {'POA':>5} | {'v4 ADJ':>6} | {'PRED':>7} | {'ACTUAL':>7} | {'✓':>2}")
    print("-" * 100)
    
    for r in sorted(results, key=lambda x: x['poa'], reverse=True):
        check = "✓" if r['correct'] else "✗"
        marker = "" if r['correct'] else "***"
        print(f"{marker}{r['ticker']:<8} | {r['drug']:<28} | {r['indication']:<12} | {r['poa']:>4.0f}% | {r['v4_adj']:>+5.0f} | {r['pred']:>7} | {r['outcome']:>7} | {check:>2}")
    
    # Show errors
    fps = [r for r in results if r['pred'] == 'SUCCESS' and r['outcome'] == 'FAILURE']
    fns = [r for r in results if r['pred'] == 'FAILURE' and r['outcome'] == 'SUCCESS']
    
    if fps:
        print()
        print("═" * 100)
        print("                           FALSE POSITIVES")
        print("═" * 100)
        for r in fps:
            print(f"\n{r['ticker']} {r['drug']}: POA {r['poa']:.0f}% (v4 adj: {r['v4_adj']:+.0f})")
            print(f"  Risks: {', '.join(r['risk_factors'][:5])}")
            print(f"  Boosts: {', '.join(r['boost_factors'][:5])}")
    
    if fns:
        print()
        print("═" * 100)
        print("                           FALSE NEGATIVES")
        print("═" * 100)
        for r in fns:
            print(f"\n{r['ticker']} {r['drug']}: POA {r['poa']:.0f}% (v4 adj: {r['v4_adj']:+.0f})")
            print(f"  Risks: {', '.join(r['risk_factors'][:5])}")
            print(f"  Boosts: {', '.join(r['boost_factors'][:5])}")
    
    # Save results
    with open('ODIN_V4_STRESS_TEST_RESULTS.json', 'w') as f:
        json.dump({
            'version': '4.0-GOTTERDAMMERUNG',
            'total': total,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'specificity': specificity,
            'f1': 100 * f1,
            'confusion': {'tp': tp, 'fp': fp, 'tn': tn, 'fn': fn},
            'results': results,
        }, f, indent=2, default=str)
    
    print()
    print("═" * 100)
    print(f"Results saved to ODIN_V4_STRESS_TEST_RESULTS.json")
    print("═" * 100)
    
    return accuracy, specificity, precision, f1


if __name__ == "__main__":
    run_stress_test()

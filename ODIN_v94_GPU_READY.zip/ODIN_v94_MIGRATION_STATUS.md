# ODIN v9.4 Migration Status Report
**Date:** January 29, 2026  
**Session:** Continuation from compacted context

---

## Executive Summary

| Metric | v9.1 Champion | v9.4 (old TA) | v9.4.1 (recalibrated) |
|--------|---------------|---------------|----------------------|
| Brier Score | **0.08864** | 0.10774 | 0.10538 |
| vs Baseline | -11.0% | +21.5% | +18.9% |
| TIER_4 Count | 28 | 42 | 65 |
| TIER_4 CRL Rate | 85.7% | 92.9% | **100%** |
| CRL Recall @85% | 76.7% | 78.9% | 78.5% |
| Constraints | ✅ | ✅ | ✅ |

**Finding:** v9.4.1 with recalibrated TA adjustments achieves perfect TIER_4 detection but Brier score is degraded. GPU optimization needed.

---

## Key Discoveries

### 1. TA Adjustments Were Miscalibrated
The v9.4 config had TA adjustments from 1,349-record dataset applied to 1,904-record dataset:

| Therapeutic Area | Old Adj | New Adj | Impact |
|-----------------|---------|---------|--------|
| Pain Management | -28.6% | -12.8% | +15.7% (was over-penalized) |
| Hematology | -22.4% | -7.6% | +14.8% (was over-penalized) |
| "Other" | -1.9% | -10.7% | -8.8% (was under-penalized) |
| Metabolic/Endocrine | -6.7% | +3.4% | +10.1% (actually good outcomes) |

### 2. Dataset Enhancement
Added `crl_count` and `resubmission_class` columns:
- 151 events with prior_crl=True
- 7 Class 1 (Manufacturing only) 
- 144 Class 2 (Clinical/Mixed issues)

### 3. RCKT Validation
With correct facts (verified via web search):
- **Actual:** 1 CRL (not 2), No BTD (has RMAT/Orphan/Priority/Fast Track)
- **v9.4 Score:** 72.0% (within 70-75% target range)
- **Tier:** TIER_3

---

## Files Ready for GPU Optimization

```
/home/claude/odin_v94_bundle/migration_bundle_v94/
├── ODIN_ENRICHED_PDUFA_v4_ENHANCED.csv    # 1,904 records with crl_count
├── ODIN_v94.1_GPU_START.json              # Starting config (recalibrated)
├── odin_v94_gpu_optimizer.py              # GPU optimizer (25 parameters)
├── odin_v94_config.py                     # Scoring module
├── odin_v94_scoring.py                    # Alternative scoring
└── ODIN_v94_GPU_OPTIMIZER_README.md       # Usage guide
```

---

## Next Steps (GPU Optimization)

### On Your RTX 4070:

1. **Quick Test (~30 sec)**
```bash
python odin_v94_gpu_optimizer.py --quick --csv ODIN_ENRICHED_PDUFA_v4_ENHANCED.csv
```

2. **Standard Run (~15 min)**  
```bash
python odin_v94_gpu_optimizer.py --configs 100000000 --csv ODIN_ENRICHED_PDUFA_v4_ENHANCED.csv
```

3. **Billion-Parameter Search (~2 hrs)**
```bash
python odin_v94_gpu_optimizer.py --billion --csv ODIN_ENRICHED_PDUFA_v4_ENHANCED.csv
```

### Target Metrics:
- Brier Score: < 0.085 (beat v9.1 champion)
- TIER_4 Count: ≥ 15
- TIER_4 CRL Rate: ≥ 50%
- CRL Recall @85%: ≥ 55%

---

## LunarCrush Enrichment Status

14/294 tickers cached (4.8%):
- **BULLISH:** IBRX (+0.05), MRNA (+0.05), REGN (+0.03)
- **NEUTRAL:** ATRA, FBIO, PRAX, AXSM, AQST, VNDA, CYTK, SNDX, BMRN, ALNY
- **BEARISH:** SRPT (-0.04)

Priority tickers remaining: LLY, AZN, AMGN, JNJ, PFE, BIIB + imminent PDUFAs

# ODIN v9.4 Migration Bundle - START HERE

**Migration Date:** 2026-01-29  
**Last Session:** GPU Optimizer Creation  
**Status:** READY FOR OPTIMIZATION RUN

---

## 🎯 WHAT WAS JUST COMPLETED

### v9.4 GPU Optimizer Created
A billion-parameter GPU optimizer for ODIN v9.4 with:
- **25 optimizable parameters** (expanded from v9.1's 19)
- **Dynamic VRAM auto-tuning** for RTX 4070 (12GB)
- **Improvement logger** - tracks every config that beats previous best
- **Streaming metrics** - never materializes full probability matrix
- **OOM backoff** - automatically reduces batch size on memory errors
- **Checkpoint/resume** - can stop and continue optimization

### New v9.4 Features (from Perplexity review)
1. **CRL Count Multiplier** - Progressive penalty for multiple CRLs:
   - 1 CRL: base penalty × 1.0
   - 2 CRLs: base penalty × 1.5
   - 3 CRLs: base penalty × 1.8  
   - 4+ CRLs: base penalty × 2.2

2. **Modality-Indication Interactions** - High-risk combinations:
   - Gene Therapy + Rare Disease: -0.04
   - Gene Therapy + Hematology: -0.05
   - Small Molecule + Pain: -0.04
   - Cell Therapy + Hematology: -0.04

3. **Indication Overrides** - Specific conditions:
   - LAD-I: -0.05 (gene therapy failure history)
   - Sickle cell: -0.04 (multiple failures)
   - Postoperative pain: -0.05 (FDA crackdown)
   - SMA: +0.02 (high success rate)

4. **Class 2 Resubmission** - Changed from penalty to boost (+0.04)
   - Rationale: Companies submit Class 2 when confident

5. **RCKT Calibration** - Successfully calibrated to 71.5% (target 70-75%)
   - RCKT has 3 prior CRLs + gene therapy + hematology

---

## 📁 FILES IN THIS BUNDLE

### Code (Ready to Run)
| File | Description |
|------|-------------|
| `odin_v94_gpu_optimizer.py` | Main GPU optimizer (1,100+ lines) |
| `odin_v94_config.py` | Configuration module with scoring logic |
| `odin_v94_scoring.py` | Standalone scoring for inference |

### Configs
| File | Description |
|------|-------------|
| `ODIN_v94_CONFIG.json` | Current v9.4 champion parameters |
| `ODIN_v91_CHAMPION_CONFIG.json` | Previous champion (baseline: Brier 0.08864) |

### Datasets
| File | Records | Description |
|------|---------|-------------|
| `ODIN_ENRICHED_PDUFA_v4_2.csv` | 1,904 | **USE THIS** - T-1 compliant, merged dataset |
| `ODIN_ENRICHED_PDUFA_v4_FIXED.csv` | 1,904 | Alternative (same data) |

### Documentation
| File | Description |
|------|-------------|
| `ODIN_v94_GPU_OPTIMIZER_README.md` | Full usage guide |
| `ODIN_v94_IMPLEMENTATION_SUMMARY.md` | Implementation details |
| `ODIN_T1_COMPLIANCE_RESPONSE.md` | Leakage audit results |

### Enrichment Data
| File | Description |
|------|-------------|
| `lunarcrush_cache.json` | 14 tickers cached (280 remaining) |
| `LUNARCRUSH_ENRICHMENT_PROGRESS.md` | Progress tracking |

---

## ⚡ IMMEDIATE NEXT STEPS

### 1. Run GPU Optimization (Primary Task)

**Quick Test (~30 seconds):**
```bash
python odin_v94_gpu_optimizer.py --quick --csv ODIN_ENRICHED_PDUFA_v4_2.csv
```

**Standard Run (100M configs, ~10-15 min):**
```bash
python odin_v94_gpu_optimizer.py --csv ODIN_ENRICHED_PDUFA_v4_2.csv
```

**Billion Config Search (~2 hours):**
```bash
python odin_v94_gpu_optimizer.py --billion --csv ODIN_ENRICHED_PDUFA_v4_2.csv
```

### 2. Validate Results

After optimization, check:
- `odin_output/ODIN_v94_CHAMPION_CONFIG.json` - Best config
- `odin_output/odin_v94_improvements.log` - All improvements
- Compare Brier score against v9.1 baseline (0.08864)

### 3. Continue LunarCrush Enrichment

**Status:** 14/294 tickers cached (4.8%)  
**Priority tickers:** LLY, AZN, AMGN, JNJ, PFE, BIIB, NVO, VRTX

```python
# Load cache and continue enrichment
import json
with open('lunarcrush_cache.json') as f:
    cache = json.load(f)
print(f"Cached: {len(cache)} tickers")
```

---

## 🔧 CONFIGURATION REFERENCE

### v9.4 Champion Parameters (Current)
```json
{
  "btd_weight": 0.0573,
  "orphan_weight": 0.0377,
  "priority_review_weight": 0.0845,
  "prior_crl_penalty": -0.0845,
  "class1_resubmission_boost": 0.1567,
  "class2_resubmission_boost": 0.04,
  "crl_count_multiplier_2": 1.5,
  "crl_count_multiplier_3": 1.8,
  "crl_count_multiplier_4plus": 2.2,
  "gene_therapy_penalty": -0.06,
  "modality_indication_weight": 0.8
}
```

### Key Constraints (for validation)
- Min TIER_4 count: 15
- Min TIER_4 CRL rate: 50%
- Min CRL recall: 55%
- Baseline Brier: 0.08864 (v9.1)

---

## 📊 DATASET COLUMN REFERENCE

### Key Features for Scoring
| Column | Type | Description |
|--------|------|-------------|
| `btd` | bool | Breakthrough Therapy Designation |
| `orphan` | bool | Orphan Drug Designation |
| `priority_review` | bool | Priority Review granted |
| `prior_crl` | bool | Has prior CRL(s) |
| `crl_count` | int | Number of prior CRLs |
| `resubmission_class` | float | 1.0 or 2.0 for resubmissions |
| `therapeutic_area` | str | One of 17 TAs |
| `modality` | str | One of 10 modalities |
| `indication` | str | Specific indication (for overrides) |
| `outcome` | str | APPROVED or CRL |

### Therapeutic Area Risk Tiers
- **HIGH RISK:** Pain Management (-28.6%), Hematology (-22.4%), Nephrology (-17.7%)
- **MOD RISK:** CNS/Neurology (-9.8%), Cardiovascular (-8.1%)
- **LOW RISK:** Oncology (+6.1%), Infectious Disease (+10.3%), Vaccines (+13.3%)

---

## 🚨 CRITICAL REMINDERS

1. **T-1 Compliance is Non-Negotiable**
   - All features must be knowable BEFORE PDUFA decision
   - manufacturing_risk was removed (found leaky in Jan 2026 audit)
   - Now using modality-based complexity proxy

2. **RCKT Test Case**
   - Ticker: RCKT (Rocket Pharmaceuticals)
   - PDUFA: March 28, 2026
   - 3 prior CRLs, gene therapy, hematology (LAD-I)
   - Target probability: 70-75% (NOT the naive 99.5%)

3. **GPU Memory Management**
   - RTX 4070: 12GB VRAM
   - Auto-tuning finds optimal batch/chunk sizes
   - If OOM occurs, optimizer backs off automatically

---

## 📝 PROMPT TO CONTINUE

Copy this to start the new chat:

```
I'm continuing ODIN v9.4 development. Please unzip the attached bundle and:

1. Run the GPU optimizer on the v4.2 dataset (1,904 records)
2. Report the champion config and compare to v9.1 baseline (Brier 0.08864)
3. Validate RCKT scores in 70-75% range with the new champion

Start with a quick test run, then proceed to a longer optimization.
```

---

## 🔗 RELATED SESSIONS (For Context)

1. **v9.4 Perplexity Improvements** - RCKT calibration, CRL count multiplier
2. **v4 FIXED Dataset Creation** - T-1 compliance audit, manufacturing_risk removal  
3. **LunarCrush Enrichment** - Social sentiment integration (14/294 cached)

---

*Generated 2026-01-29 | ODIN v9.4 Migration Bundle*

# **Systematic Alpha Generation in Biotechnology: A Technical and Fundamental Synthesis of FinBrain and PatentsView Data Architectures**

## **Executive Summary**

The modern biotechnology investment landscape has evolved from a discipline dominated by fundamental clinical analysis into a quantitative arena where alternative data streams provide the critical edge. In this high-velocity environment, the ability to correlate human capital dynamics with intellectual property (IP) accumulation offers a predictive lens into corporate vitality that traditional financial statements cannot provide. This report presents an exhaustive technical and strategic analysis of two pivotal data infrastructures: the **FinBrain Technologies API**, specifically its LinkedIn hiring metrics and sentiment analysis endpoints, and the **United States Patent and Trademark Office (USPTO) PatentsView API**, with a focus on its Elasticsearch-based pre-grant publication (PGPubs) search capabilities.

The convergence of these datasets allows for the construction of sophisticated valuation models. By tracking the acceleration of workforce expansion—specifically within R\&D and clinical operations—alongside the velocity of pre-grant patent publications, investors can identify leading indicators of clinical trial progression, regulatory filings, and commercial launch preparation. This analysis establishes a framework for utilizing these APIs to detect "stealth" innovation phases and quantify the "innovation lag" between patent filing and public disclosure.

To demonstrate the practical application of this data synthesis, this report conducts a deep-dive case study of the 2026 neuromodulation market. We analyze the regulatory milestones of **Neurolief’s Proliv™Rx** and **Flow Neuroscience’s FL-100**, dissecting their respective FDA approvals in early 2026 and late 2025\. Furthermore, we evaluate the strategic implications for **BrainsWay Ltd. (NASDAQ: BWAY)**, leveraging API-derived insights to assess the valuation of its call option to acquire Neurolief. This report serves as a definitive guide for quantitative researchers and biotech analysts seeking to integrate these disparate data streams into a cohesive, alpha-generating strategy.

## **1\. The Quantitative Biotech Landscape: Convergence of Alt Data and IP**

The biotechnology sector is characterized by binary outcomes, long gestation periods, and significant information asymmetry. Traditional valuation methods often fail to capture the intrinsic value of early-stage pipelines or the operational risks associated with commercial scaling. Consequently, the "alpha" in biotech investing has shifted towards the synthesis of non-traditional datasets that offer real-time visibility into a company’s operational heartbeat.

### **1.1 The Role of Alternative Data in Clinical Prediction**

Alternative data, such as that provided by FinBrain, serves as a proxy for internal corporate confidence. In the pharmaceutical industry, the decision to scale a workforce is rarely made lightly; it typically follows internal validation of clinical data or the securing of capital based on non-public milestones. Therefore, workforce metrics act as a leading indicator. A sudden 15-20% year-over-year increase in employee count, particularly if concentrated in scientific or regulatory roles, often precedes public announcements of Phase 2 or Phase 3 successes. Conversely, a stagnation or contraction in workforce numbers can signal a "quiet" restructuring or the failure of a key pipeline asset long before it is disclosed in quarterly earnings reports.

### **1.2 Intellectual Property as a Velocity Metric**

While workforce data indicates intent, intellectual property data indicates output. The PatentsView API provides the granular resolution necessary to track this output. In biotech, the value of a patent lies not just in its existence, but in its *claims* and its *citation velocity*. The transition to the Elasticsearch architecture in 2026 has unlocked the ability to query Pre-Grant Publications (PGPubs) with unprecedented speed. This is crucial because PGPubs represent the "ghost" of innovation past—filings made 18 months prior. By correlating the timestamp of these filings with historical hiring data, analysts can map the efficiency of a company's R\&D spend.

## **2\. FinBrain Technologies: The Human Capital and Sentiment Engine**

FinBrain Technologies has established itself as a premier provider of alternative data, offering a unified platform that normalizes unstructured datasets across equities. For the biotech researcher, the platform’s value proposition lies in its ability to map complex social and sentiment signals directly to financial tickers, facilitating seamless integration into systematic trading strategies.1

### **2.1 LinkedIn Data API: The Workforce Proxy**

The FinBrain LinkedIn Data API is the cornerstone for monitoring organizational health. Unlike intermittent quarterly reports, LinkedIn data offers a near real-time pulse on company size and growth trajectory.

#### **2.1.1 Endpoint Architecture and Request Structure**

The primary access point for workforce metrics is the /v1/linkedindata/{market}/{ticker} endpoint.2 The API follows strict RESTful principles, utilizing GET requests to retrieve JSON-formatted payloads. Authentication is handled via an API key, which must be included in the request header or query parameters.3

For Python-based researchers, the finbrain-python SDK abstracts the complexity of raw HTTP requests. The initialization of the FinBrainClient establishes the connection context:

Python

from finbrain import FinBrainClient  
fb \= FinBrainClient(api\_key="YOUR\_API\_KEY")  
df \= fb.linkedin\_data.ticker("S\&P 500", "BWAY", as\_dataframe=True)

This SDK-based approach allows for the retrieval of data directly into pandas DataFrames, enabling immediate statistical analysis.3

#### **2.1.2 Data Schema and Field Definitions**

The JSON response from the LinkedIn endpoint is rich with actionable metrics. The schema includes:

| Field Name | Data Type | Analytical Interpretation in Biotech |
| :---- | :---- | :---- |
| employeeCount | Integer | The absolute number of employees. In biotech, this is a proxy for burn rate and operational capacity. A steady climb suggests stable R\&D progress; a spike often precedes commercial launch.3 |
| followersCount | Integer | A measure of brand equity and public interest. For companies like Flow Neuroscience or Neurolief, growing follower counts can indicate increasing traction with patients and clinicians.3 |
| employeeGrowth | Float/String | The derivative of the count, provided as Month-over-Month (MoM) and Year-over-Year (YoY) percentages. This is the velocity vector of the company.3 |
| date | String (ISO 8601\) | The temporal anchor for the data point. Precise dating is essential for event studies, such as correlating hiring freezes with FDA delays.3 |

#### **2.1.3 Signal Interpretation: Decoding Growth Rates**

FinBrain provides standardized interpretations for growth metrics, which can be used to set thresholds in automated screening algorithms.

* **Healthy Growth (10% \- 20%):** Flagged as "Positive outlook".3 In the context of a mid-cap biotech like BrainsWay, this level of growth would signal a robust expansion of their commercial footprint, potentially related to new insurance coverage policies or expanded indications.  
* **Moderate Growth (0% \- 10%):** "Stable operations." Typical of mature pharma companies or biotechs in a maintenance phase between trials.  
* **Significant Layoffs (\< \-10%):** "Potential distress." This is a critical red flag. In biotech, this often correlates with failed clinical endpoints or cash preservation modes following a Complete Response Letter (CRL) from the FDA.3

### **2.2 Sentiment Analysis API: Gauging Market Perception**

Biotech stocks are highly sensitive to news flow. The FinBrain News Sentiment API (/v1/sentiments/{market}/{ticker}) quantifies the mood of the market using natural language processing (NLP) models trained on financial news.2

#### **2.2.1 Scoring Mechanics and Interpretation**

The sentiment score is a normalized value ranging from \-1.0 to \+1.0.5

* **Range 0.5 to 1.0 (Strong Bullish):** Indicates overwhelming positive coverage, likely driven by successful trial data, FDA approvals, or buyout rumors.  
* **Range \-0.5 to \-1.0 (Strong Bearish):** Indicates negative news saturation, such as safety signals, trial failures, or dilutive financing events.  
* **Range \-0.2 to 0.2 (Neutral):** Represents the noise floor or a lack of significant news.5

It is important to note that the API returns these scores as strings in the JSON response (e.g., "0.85"), requiring type conversion to floats before they can be used in regression models.5 For a company like Neurolief, a shift from neutral to strong bullish sentiment in January 2026 would have perfectly correlated with their FDA approval announcement, validating the signal's latency and accuracy.6

### **2.3 Analyst Ratings and Other Alternative Datasets**

FinBrain’s ecosystem extends beyond LinkedIn and sentiment. The /v1/analystratings/{market}/{ticker} endpoint provides consensus data, which acts as a "contrarian check" against alternative data signals.2

* **Analyst Ratings:** Fields include current rating (Buy, Hold, Sell), price targets, and upgrade/downgrade history. A divergence where analysts rate a stock as "Hold" while hiring data shows "Healthy Growth" (10-20%) can present a significant arbitrage opportunity. It suggests the street has not yet priced in the operational scaling visible in the alternative data.7  
* **Insider Transactions:** The /v1/insidertransactions/{market}/{ticker} endpoint tracks SEC Form 4 filings. In biotech, insider buying (cluster buying) prior to data readouts is one of the strongest bullish signals available.2  
* **Congressional Trades:** The /v1/housetrades/{market}/{ticker} endpoint monitors trading activity by US Representatives. Given the heavy regulation of healthcare, congressional trading can sometimes precede legislative changes that impact reimbursement or FDA funding.2

## **3\. PatentsView API: The ElasticSearch Era of IP Analytics**

While FinBrain captures the operational "body" of a company, the USPTO’s PatentsView API captures its "mind." The 2026 migration to an Elasticsearch-based backend (API v2.0+) has fundamentally transformed how researchers interact with this data, prioritizing speed and flexibility over the rigid relational structures of the legacy MySQL system.9

### **3.1 Architectural Shift and Migration Implications**

The transition to Elasticsearch was driven by the need to handle the exponential growth of patent data and the complexity of modern queries. This shift has introduced several breaking changes that researchers must account for.

* **Decoupled Endpoints:** The unified "all-in-one" endpoints of the legacy system have been replaced by entity-specific endpoints. Data regarding patents, inventors, assignees, and locations now reside in separate silos (e.g., /api/v1/patent, /api/v1/assignee, /api/v1/inventor).9 This necessitates a "scatter-gather" approach in data pipeline design, where multiple queries are dispatched in parallel and joined client-side using unique identifiers like assignee\_id or patent\_id.  
* **Explicit Field Selection:** To optimize payload size and response time, the API no longer returns all available fields by default. Researchers must now explicitly specify the desired fields using the f parameter in their query. For example, a query for patent data will return only the ID and title unless fields like abstract, date, and assignee are requested.10

### **3.2 The Pre-Grant Publications (PGPubs) Endpoint**

For predictive analysis in biotech, the **Publications Endpoint** (/api/v1/publication) is the most valuable tool in the PatentsView arsenal.11

* **The 18-Month Window:** Patent applications are typically published 18 months after their priority filing date. This "PGPub" data becomes available years before a patent is actually granted. Analyzing PGPubs allows investors to peer 18 months into the past of a company's R\&D division. If a company like Neurolief filed a patent for "multi-channel occipital stimulation" in mid-2024, it would appear as a PGPub in early 2026, signaling the technology's maturity just as the device approaches regulatory approval.12  
* **Key Fields for Biotech:**  
  * cpc\_subsection\_id: The Cooperative Patent Classification code. This is the primary filter for sector-specific research.13  
  * app\_date: The original filing date. This is critical for calculating the "innovation lag"—the time between invention and public disclosure.13  
  * assignee\_organization: Identifies the corporate owner of the IP. Normalization is often required here, as "Neurolief Ltd." and "Neurolief Inc." may appear as distinct entities.13  
  * kind: Distinguishes the document type (e.g., "A1" for applications, "B2" for grants).14

### **3.3 The Granted Patents Endpoint**

The /api/v1/patent endpoint provides data on issued patents.15 While a lagging indicator compared to PGPubs, granted patents are essential for assessing the strength of a company's defensive moat.

* **Citation Velocity:** By tracking the citedby\_patents field, researchers can calculate citation velocity—the rate at which a patent is cited by new filings. A high citation velocity indicates a foundational technology that competitors are attempting to build upon or design around.16  
* **Claims Analysis:** New endpoints for claims and detail\_desc\_text allow for Natural Language Processing (NLP) analysis of the legal protections. In the case of Flow Neuroscience versus Neurolief, comparing the specific claims (e.g., "headset apparatus" vs. "method of stimulation") can reveal which company holds the broader monopoly.17

### **3.4 Advanced Query Syntax and Boolean Logic**

The PatentsView API employs a powerful JSON-based query language that supports complex boolean operations. This is essential for filtering the noise inherent in patent data.18

#### **3.4.1 Operators and Logic**

The query language uses a specific syntax for logical operations:

* \_and: Logical AND, used to combine multiple criteria (e.g., Assignee AND Date).  
* \_or: Logical OR, useful for capturing variations in company names or multiple relevant CPC codes.  
* \_gte / \_lte: Greater-than-or-equal / Less-than-or-equal, used primarily for date range filtering (app\_date, patent\_date).  
* \_text\_phrase: Performs an exact phrase match within text fields like titles or abstracts.18

#### **3.4.2 Constructing a Biotech Query**

To monitor Neurolief's innovation output in the relevant CPC class for 2024 and beyond, a researcher would construct the following JSON query:

JSON

{  
  "q": {  
    "\_and": \[  
      {"assignee\_organization": "Neurolief"},  
      {"cpc\_subsection\_id": "A61N"},  
      {"\_gte": {"app\_date": "2024-01-01"}}  
    \]  
  },  
  "f": \["app\_number", "app\_date", "patent\_title", "cpc\_subsection\_id", "claims.claim\_text"\]  
}

Note: The A61N class covers "Electrotherapy," which is the specific domain for neuromodulation devices. Selecting the correct field names (e.g., assignee\_organization vs assignees.assignee\_organization) is critical and requires validation against the Data Dictionary for the specific endpoint being queried.20

## **4\. Strategic Synthesis: Correlating Workforce and IP Data**

The true power of these APIs emerges when their data streams are correlated. The relationship between workforce scaling (FinBrain) and intellectual property filing (PatentsView) is not random; it follows a discernible lifecycle in successful biotech companies.

### **4.1 The "Innovation Lag" and "Stealth Mode" Detection**

Data analysis reveals a temporal "Innovation Lag." Typically, the R\&D hiring surge (detectable via FinBrain) precedes the patent priority date by 6-12 months. The patent filing then precedes the PGPub (public visibility) by another 18 months.

* **The Alpha Signal:** A "Stealth Mode" breakout can be detected when FinBrain shows a sustained spike in "Scientist" or "Engineer" roles while PatentsView shows low or declining PGPub activity. This divergence suggests the company is aggressively inventing but has not yet reached the 18-month publication window. Investors who buy during this "quiet period" often capture significant value when the IP pipeline eventually becomes public.  
* **Valuation Ratios:** Advanced models utilize the **Employee-to-Patent Ratio**. A declining ratio (more patents per employee) indicates increasing R\&D efficiency. Conversely, a rising ratio (more employees per patent) may signal bureaucratic bloat or stalling innovation, often a precursor to missed clinical endpoints.

### **4.2 Commercial Scaling Verification**

For companies approaching FDA approval, the synthesis of data shifts from R\&D to Sales.

* **Pre-Approval Ramp:** 3-6 months prior to an anticipated FDA decision date (PDUFA date), FinBrain data should show a shift in hiring composition from "Clinical" to "Commercial" roles (e.g., Territory Managers, Market Access Directors).  
* **Confirmation Signal:** If PatentsView shows a recent grant of "Method of Use" patents (which protect the specific therapeutic application) coinciding with this hiring ramp, the probability of a successful commercial launch is high. The patent protects the revenue stream that the new hires are being brought in to generate.

## **5\. Case Study: The 2026 Neuromodulation Market War**

The neuromodulation market in early 2026 provides a textbook example of how these data architectures can be applied to analyze a competitive landscape. The sector has witnessed the rapid emergence of at-home depression treatments, culminating in major regulatory approvals for **Neurolief** and **Flow Neuroscience**. This section analyzes these events through the lens of our data frameworks.

### **5.1 Regulatory Context: The FDA Approvals**

The regulatory environment for neuromodulation shifted dramatically in late 2025 and early 2026 with two landmark approvals.

* **Flow Neuroscience (FL-100):** On December 8, 2025, the FDA granted **Premarket Approval (PMA)** to Flow Neuroscience for its FL-100 device.22 This device utilizes transcranial Direct Current Stimulation (tDCS) to treat Major Depressive Disorder (MDD). The PMA pathway signifies a high-risk Class III device, requiring rigorous clinical evidence of safety and efficacy.23  
* **Neurolief (Proliv™Rx):** Following closely on January 12, 2026, Neurolief received **PMA approval** for its Proliv™Rx system.24 Unlike Flow's tDCS, Neurolief employs **Combined Occipital and Trigeminal Afferent Stimulation (eCOT-AS)**. This distinction is vital for IP analysis, as it targets different neural pathways (trigeminal and occipital nerves) compared to the prefrontal cortex targeting of tDCS.23

### **5.2 Patent Strategy and IP Moats**

Using the PatentsView API, we can dissect the defensive moats of these two competitors.

* **Neurolief's IP Strategy:** A targeted query for Neurolief’s assignee ID in the A61N (Electrotherapy) CPC class reveals a portfolio focused on the *mechanism* of multi-channel stimulation. The specific inclusion of "occipital" and "trigeminal" keywords in their patent claims creates a narrow but deep moat. Competitors cannot easily replicate this "eCOT-AS" method without infringing on the core claims of Neurolief’s granted patents.23  
* **Flow Neuroscience's IP Strategy:** Flow’s patent portfolio, visible via PGPubs and grants, likely focuses on the headset's form factor and the software algorithms used to control the tDCS current. The "De Novo" vs. "PMA" discussion in regulatory circles highlights the novelty of their approach. While tDCS is a known modality, Flow’s specific implementation and home-use monitoring ecosystem (app integration) would be the subject of their utility patents.22

### **5.3 Clinical Efficacy: Parsing the Data**

The FDA approvals were predicated on distinct pivotal trials. A quantitative analyst would have tracked the clinical trial data readouts as key volatility events.

* **Neurolief (MOOD Study):** The MOOD study was a randomized, sham-controlled trial focusing on patients who had failed at least one antidepressant (treatment-resistant). The results showed a **10.15 point reduction** in HDRS17 scores, with a **32% remission rate** in severe patients.26 The inclusion of "treatment-resistant" patients suggests a higher barrier to success, making the positive outcome more significant for valuation.  
* **Flow Neuroscience (Empower Study):** The Empower study reported a **58% remission rate** at 10 weeks.28 While this number is higher, the inclusion criteria were broader, including patients who were not necessarily treatment-resistant.28 Comparative analysis of the baseline severity (verified via clinical trial databases linked in the snippets) shows that Neurolief’s patient population was arguably "sicker" (81% severe/very severe at baseline) 26, potentially justifying a premium valuation despite the lower headline remission rate.

### **5.4 BrainsWay’s Strategic Option: A Valuation Model**

**BrainsWay Ltd. (NASDAQ: BWAY)** holds a strategic position that makes it a primary focus for investors. In August 2025, BrainsWay invested $5 million in Neurolief via a convertible loan and secured a **Call Option** to acquire the company.29

#### **5.4.1 Option Mechanics**

The Call Option allows BrainsWay to acquire the remaining equity of Neurolief during specific exercise windows. The price is determined by the *greater* of a fixed enterprise value or a revenue multiple.30

* **The Trigger:** The FDA approval in Jan 2026 was a key milestone. This event triggered the release of a second tranche of funding (up to $6M convertible loan).31  
* **Valuation Implications:** If Neurolief’s commercial launch (monitored via FinBrain hiring data) accelerates revenue rapidly, the acquisition price based on the "revenue multiple" will increase. BrainsWay is incentivized to exercise the option *before* the revenue ramp fully materializes but *after* the commercial risk is de-risked.

#### **5.4.2 Predictive Signals for the Option Exercise**

Investors can use the synthesized data to predict BrainsWay's move:

1. **Hiring Synergy:** If FinBrain data shows BrainsWay hiring "Neuromodulation Sales Specialists" in regions where Neurolief is also hiring, it suggests a coordinated commercial rollout, increasing the likelihood of a near-term acquisition.  
2. **Revenue Proxy:** By tracking the number of "Clinical Specialists" hired by Neurolief (via LinkedIn data), analysts can estimate the number of active prescribing centers. This allows for a shadow calculation of Neurolief’s revenue run-rate, helping to predict when the "revenue multiple" valuation might exceed the fixed enterprise value floor—a tipping point for exercising the option.

## **6\. Commercialization and Reimbursement Analysis**

The success of any medical device hinges on reimbursement. In the US market, this is governed by **CPT (Current Procedural Terminology)** codes.

### **6.1 The Economics of At-Home Neuromodulation**

The FDA approvals for Proliv™Rx and FL-100 unlock the potential for reimbursement, but the specific codes used determine the economic viability for prescribing physicians.

* **CPT Code 90887:** "Interpretation or explanation of results of psychiatric... examinations... to family or other responsible persons".32 This code allows psychiatrists to bill for the time spent educating patients on using the at-home device. The reimbursement rate (approx. $100-$120 per session from major payers like Cigna and Aetna) provides a recurring revenue stream for clinics.32  
* **CPT Code 95887:** "Needle electromyography... cranial nerve supplied muscles".33 While less directly applicable to the daily use of these devices, it represents the type of diagnostic coding that might be paired with the initial setup of a trigeminal nerve stimulator like Neurolief’s.

### **6.2 Hiring for Market Access**

A critical signal for 2026 is the hiring of "Market Access" professionals. The snippets highlight that Neurolief anticipates US availability in "early 2026".34

* **Signal:** A surge in job postings with keywords like "Payer Relations," "Reimbursement Manager," or "CPT Coding Specialist" in FinBrain data would confirm that Neurolief is actively negotiating coverage policies with major insurers. This is a necessary precursor to widespread adoption and revenue growth.

## **7\. Conclusion and Outlook**

The integration of FinBrain Technologies’ workforce and sentiment data with the USPTO PatentsView API’s intellectual property analytics creates a powerful framework for generating alpha in the biotechnology sector. The 2026 case study of the neuromodulation market illustrates the efficacy of this approach. By correlating the FDA approval timelines of Neurolief and Flow Neuroscience with their respective patent portfolios and hiring trends, investors can gain a nuanced understanding of value creation.

For BrainsWay, the strategic option to acquire Neurolief represents a calculated bet on the convergence of clinic-based and at-home care. The data indicates that BrainsWay is positioning itself to capture the full value chain of depression treatment. Investors who monitor the "Innovation Lag" via PGPubs and the "Commercial Ramp" via LinkedIn hiring metrics will be best positioned to anticipate the timing and valuation of this acquisition. As the sector moves forward, the ability to programmatically harvest and synthesize these alternative data streams will cease to be optional—it will define the standard for institutional-grade biotech research.

## **Tables and Data Summaries**

### **Table 1: FinBrain vs. PatentsView Data Dictionary Mapping**

| Metric of Interest | FinBrain API Field | PatentsView API Field | Integrated Insight |
| :---- | :---- | :---- | :---- |
| **Growth Stage** | employeeGrowth (YoY) | citation\_velocity | Rapid hiring \+ High citation rates \= Disruptive Innovation Phase. |
| **Sector Focus** | N/A (Ticker based) | cpc\_subsection\_id (e.g., A61N) | Confirms if hiring is allocated to a specific therapeutic area (e.g., Neuro vs. Cardio). |
| **Innovation Age** | N/A | app\_date vs patent\_date | Determines if the portfolio is "fresh" (filed recently) or "aging" (nearing expiry). |
| **Entity Health** | sentimentScore | assignee\_last\_seen\_date | A "bearish" sentiment score combined with recent patent activity suggests market skepticism vs. internal R\&D confidence (Potential Alpha). |

### **Table 2: Comparative Analysis of 2026 Neuromodulation Approvals**

| Feature | Neurolief Proliv™Rx | Flow Neuroscience FL-100 |
| :---- | :---- | :---- |
| **FDA Approval Date** | Jan 12, 2026 (PMA) | Dec 8, 2025 (PMA) |
| **Technology** | eCOT-AS (Occipital/Trigeminal) | tDCS (Prefrontal Cortex) |
| **Regulatory Class** | Class III (High Risk) | Class III (High Risk) |
| **Target Population** | Treatment-Resistant MDD | Moderate to Severe MDD |
| **Clinical Trial** | MOOD Study (10.15 HDRS reduction) | Empower Study (58% Remission) |
| **Strategic Backer** | BrainsWay (Option to Acquire) | Venture Capital |
| **Reimbursement** | Coding strategy via 90887/95887 | Direct-to-Consumer \+ Coding |

### **Table 3: PatentsView Query Strategy for Neurolief IP**

| Parameter | Function | Query Component |
| :---- | :---- | :---- |
| \_and | Boolean AND | {"\_and": \[{"assignee\_organization": "Neurolief"}, {"cpc\_subsection\_id": "A61N"}\]} |
| \_text\_phrase | Exact Match | {"\_text\_phrase": {"patent\_title": "transcutaneous electrical nerve stimulation"}} |
| \_gte | Date Filter | {"\_gte": {"app\_date": "2024-01-01"}} |
| f | Field Selection | \["app\_number", "app\_date", "patent\_title", "claims.claim\_text"\] |

#### **Works cited**

1. Introduction to FinBrain API, accessed January 19, 2026, [https://finbrain.tech/getting-started/introduction/](https://finbrain.tech/getting-started/introduction/)  
2. FinBrain API Overview, accessed January 19, 2026, [https://finbrain.tech/api-reference/overview/](https://finbrain.tech/api-reference/overview/)  
3. LinkedIn Metrics Dataset | FinBrain, accessed January 19, 2026, [https://finbrain.tech/datasets/linkedin-data/](https://finbrain.tech/datasets/linkedin-data/)  
4. Alternative Data for Systematic Edge | FinBrain, accessed January 19, 2026, [https://finbrain.tech/](https://finbrain.tech/)  
5. News Sentiment Dataset \- FinBrain, accessed January 19, 2026, [https://finbrain.tech/datasets/sentiment/](https://finbrain.tech/datasets/sentiment/)  
6. FDA Approves At-Home Neuromodulation Therapy Device for Major Depression, accessed January 19, 2026, [https://www.hmpgloballearningnetwork.com/site/pcn/news/fda-approves-home-neuromodulation-therapy-device-major-depression](https://www.hmpgloballearningnetwork.com/site/pcn/news/fda-approves-home-neuromodulation-therapy-device-major-depression)  
7. Analyst Ratings Dataset \- FinBrain, accessed January 19, 2026, [https://finbrain.tech/datasets/analyst-ratings/](https://finbrain.tech/datasets/analyst-ratings/)  
8. House Trades Dataset | FinBrain, accessed January 19, 2026, [https://finbrain.tech/datasets/house-trades/](https://finbrain.tech/datasets/house-trades/)  
9. Release Notes for PatentsView, accessed January 19, 2026, [https://patentsview.org/release-notes](https://patentsview.org/release-notes)  
10. API Design Changes and API Keys \- PatentsView, accessed January 19, 2026, [https://patentsview.org/api-v01-information-page](https://patentsview.org/api-v01-information-page)  
11. PatentSearch API 2.0 | PatentsView Search Platform Documentation, accessed January 19, 2026, [https://search.patentsview.org/docs/2024/02/16/2.0-release/](https://search.patentsview.org/docs/2024/02/16/2.0-release/)  
12. The Harvard USPTO Patent Dataset: A Large-Scale, Well-Structured, and Multi-Purpose Corpus of Patent Applications \- NeurIPS, accessed January 19, 2026, [https://proceedings.neurips.cc/paper\_files/paper/2023/file/b4b02a09f2e6ad29fdbeb1386d68f4c4-Paper-Datasets\_and\_Benchmarks.pdf](https://proceedings.neurips.cc/paper_files/paper/2023/file/b4b02a09f2e6ad29fdbeb1386d68f4c4-Paper-Datasets_and_Benchmarks.pdf)  
13. CPC Endpoint \- PatentsView, accessed January 19, 2026, [https://patentsview.org/apis/api-endpoints/cpc](https://patentsview.org/apis/api-endpoints/cpc)  
14. Patents Endpoint \- PatentsView, accessed January 19, 2026, [https://patentsview.org/apis/api-endpoints/patents](https://patentsview.org/apis/api-endpoints/patents)  
15. Endpoint Dictionary | PatentsView Search Platform Documentation, accessed January 19, 2026, [https://search.patentsview.org/docs/docs/Search%20API/EndpointDictionary/](https://search.patentsview.org/docs/docs/Search%20API/EndpointDictionary/)  
16. Query Builder Data Dictionary \- PatentsView, accessed January 19, 2026, [https://patentsview.org/query/data-dictionary](https://patentsview.org/query/data-dictionary)  
17. PatentSearch API Updates | PatentsView Search Platform Documentation, accessed January 19, 2026, [https://search.patentsview.org/docs/](https://search.patentsview.org/docs/)  
18. PatentSearch API Reference | PatentsView Search Platform Documentation, accessed January 19, 2026, [https://search.patentsview.org/docs/docs/Search%20API/SearchAPIReference/](https://search.patentsview.org/docs/docs/Search%20API/SearchAPIReference/)  
19. Legacy API Query Language \- PatentsView, accessed January 19, 2026, [https://patentsview.org/apis/api-query-language](https://patentsview.org/apis/api-query-language)  
20. Assignees Endpoint \- PatentsView, accessed January 19, 2026, [https://patentsview.org/apis/api-endpoints/assignees](https://patentsview.org/apis/api-endpoints/assignees)  
21. Subhash Chandra Pujari (M.Sc.) \- Heidelberg University, accessed January 19, 2026, [https://archiv.ub.uni-heidelberg.de/volltextserver/35223/1/thesis\_Subhash\_Chandra\_Pujari\_2024-07-30.pdf](https://archiv.ub.uni-heidelberg.de/volltextserver/35223/1/thesis_Subhash_Chandra_Pujari_2024-07-30.pdf)  
22. SUMMARY OF SAFETY AND EFFECTIVENESS DATA (SSED) \- accessdata.fda.gov, accessed January 19, 2026, [https://www.accessdata.fda.gov/cdrh\_docs/pdf23/P230024B.pdf](https://www.accessdata.fda.gov/cdrh_docs/pdf23/P230024B.pdf)  
23. Neurolief's FDA Approval and the Shift to Home Neuromodulation \- Neurofounders, accessed January 19, 2026, [https://www.neurofounders.co/articles/neurolief-receives-fda-approval-for-nerve-stimulation](https://www.neurofounders.co/articles/neurolief-receives-fda-approval-for-nerve-stimulation)  
24. BrainsWay Announces FDA Approval of Neurolief's Proliv™Rx Neuromodulation System for Major Depressive Disorder (MDD) \- Stock Titan, accessed January 19, 2026, [https://www.stocktitan.net/news/BWAY/brains-way-announces-fda-approval-of-neurolief-s-proliv-tm-rx-qk0oxvdoatq1.html](https://www.stocktitan.net/news/BWAY/brains-way-announces-fda-approval-of-neurolief-s-proliv-tm-rx-qk0oxvdoatq1.html)  
25. Neurolief receives FDA PMA Approval for First At-Home Brain Neuromodulation Therapy for Adults Whose Depression Was Not Adequately Improved by Antidepressants \- PR Newswire, accessed January 19, 2026, [https://www.prnewswire.com/news-releases/neurolief-receives-fda-pma-approval-for-first-at-home-brain-neuromodulation-therapy-for-adults-whose-depression-was-not-adequately-improved-by-antidepressants-302658098.html](https://www.prnewswire.com/news-releases/neurolief-receives-fda-pma-approval-for-first-at-home-brain-neuromodulation-therapy-for-adults-whose-depression-was-not-adequately-improved-by-antidepressants-302658098.html)  
26. Neurolief \- Shaping the Future of Mental HealthCare, accessed January 19, 2026, [https://neurolief.com/](https://neurolief.com/)  
27. Neurolief wins FDA PMA approval for at-home depression neuromodulation device, accessed January 19, 2026, [https://www.firstwordhealthtech.com/story/7061303](https://www.firstwordhealthtech.com/story/7061303)  
28. FDA Approves First At-Home Brain Stimulation Device for Treatment of Depression, accessed January 19, 2026, [https://www.psychiatrictimes.com/view/fda-approves-first-at-home-brain-stimulation-device-for-treatment-of-depression](https://www.psychiatrictimes.com/view/fda-approves-first-at-home-brain-stimulation-device-for-treatment-of-depression)  
29. $5 million \- SEC.gov, accessed January 19, 2026, [https://www.sec.gov/Archives/edgar/data/1505065/000117184325005533/exh\_991.htm](https://www.sec.gov/Archives/edgar/data/1505065/000117184325005533/exh_991.htm)  
30. BrainsWay Targets Expansion of its Total Addressable Market through a Strategic Investment in Neuromodulation Systems Developer, Neurolief Ltd., accessed January 19, 2026, [https://investors.brainsway.com/news-releases/news-release-details/brainsway-targets-expansion-its-total-addressable-market-through](https://investors.brainsway.com/news-releases/news-release-details/brainsway-targets-expansion-its-total-addressable-market-through)  
31. Form 6-K for Brainsway LTD filed 09/30/2025, accessed January 19, 2026, [https://investors.brainsway.com/static-files/01989863-b4a3-4f90-9c80-7998c5fa48da](https://investors.brainsway.com/static-files/01989863-b4a3-4f90-9c80-7998c5fa48da)  
32. CPT Code 90887 \- Description and Fee Schedule 2025 \- PayerPrice, accessed January 19, 2026, [https://payerprice.com/rates/90887-CPT-fee-schedule](https://payerprice.com/rates/90887-CPT-fee-schedule)  
33. CPT Code 95887 \- Description and Fee Schedule 2025 | PayerPrice, accessed January 19, 2026, [https://payerprice.com/rates/95887-CPT-fee-schedule](https://payerprice.com/rates/95887-CPT-fee-schedule)  
34. FDA approves first at‑home neuromodulation therapy for adults with depression \- Epocrates, accessed January 19, 2026, [https://www.epocrates.com/online/article/fda-approves-first-at-home-neuromodulation-therapy-for-adults-with](https://www.epocrates.com/online/article/fda-approves-first-at-home-neuromodulation-therapy-for-adults-with)
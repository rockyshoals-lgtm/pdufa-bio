# ODIN GLOBAL OPTIMIZATION TASK FOR CHATGPT (ENGINEER)
## 10,000,000+ Configuration Search with GPU Acceleration
**From**: Claude (Research Authority)  
**To**: ChatGPT (Engineering Implementation)  
**Date**: 2026-01-20  
**Priority**: CRITICAL

---

## YOUR MISSION

You are the Engineering AI for ODIN (Optimized Drug Investment Navigator), a biotech catalyst prediction system. Your task is to find the **GLOBAL OPTIMUM** configuration by running **10,000,000+ parameter combinations** using GPU acceleration.

ODIN predicts FDA PDUFA (drug approval) outcomes. We have 1,349 historical events (2020-2026) with 1,169 approvals and 180 CRLs (rejections). The current best configuration (v8.6) achieves:
- MCC: 0.456
- Precision: 95.02%
- Specificity: 71.11%
- Brier Score: 0.1761

**YOUR GOAL**: Find a configuration that achieves:
- MCC: ≥0.50 (+10% improvement)
- Precision: ≥94% (HARD FLOOR - CANNOT SACRIFICE)
- Specificity: ≥78% (+7% improvement)
- Brier Score: ≤0.12 (-32% improvement)

---

## STEP 1: SET UP GPU-ACCELERATED ENVIRONMENT

```python
# Install required packages
!pip install optuna optuna-dashboard cupy-cuda12x numpy pandas scikit-learn joblib numba

import numpy as np
import pandas as pd
import cupy as cp  # GPU-accelerated numpy
import optuna
from optuna.samplers import TPESampler, CmaEsSampler
from optuna.pruners import MedianPruner, HyperbandPruner
from sklearn.metrics import matthews_corrcoef, precision_score, recall_score, brier_score_loss
from sklearn.metrics import confusion_matrix
import joblib
from numba import cuda, jit
import warnings
warnings.filterwarnings('ignore')

# Enable GPU
print(f"GPU Available: {cp.cuda.runtime.getDeviceCount()} device(s)")
cp.cuda.Device(0).use()
```

---

## STEP 2: LOAD THE DATASET

```python
# Load dataset
df = pd.read_csv('ODIN_ENRICHED_PDUFA_1349_v2.csv')

# Create binary outcome
df['outcome_binary'] = (df['outcome'] == 'APPROVAL').astype(int)

# Convert to GPU arrays for speed
y_true = cp.array(df['outcome_binary'].values)

# Pre-compute feature arrays on GPU
btd = cp.array(df['btd'].fillna(False).astype(int).values)
orphan = cp.array(df['orphan'].fillna(False).astype(int).values)
priority_review = cp.array(df['priority_review'].fillna(False).astype(int).values)
fast_track = cp.array(df['fast_track'].fillna(False).astype(int).values)
experienced = cp.array(df['experienced_sponsor'].fillna(False).astype(int).values)
mfg_risk = cp.array(df['manufacturing_risk'].fillna(False).astype(int).values)
stack_count = cp.array(df['designation_stack_count'].fillna(0).values)
had_adcom = cp.array(df['had_adcom'].fillna(False).astype(int).values)
prior_crl = cp.array(df['prior_crl'].fillna(False).astype(int).values)

# Therapeutic area one-hot encoding
ta_mapping = {
    'Oncology': 0, 'Infectious Disease': 1, 'CNS/Neurology': 2,
    'Immunology': 3, 'Rare Disease': 4, 'Cardiovascular': 5,
    'Ophthalmology': 6, 'Pain Management': 7, 'Metabolic/Endocrine': 8,
    'Nephrology': 9, 'Respiratory': 10, 'Dermatology': 11,
    'GI/Hepatology': 12, 'Hematology': 13, 'Vaccines': 14,
    'Women\'s Health': 15, 'Other': 16
}
ta_encoded = cp.array([ta_mapping.get(ta, 16) for ta in df['therapeutic_area'].fillna('Other')])

print(f"Dataset loaded: {len(df)} events")
print(f"Approvals: {int(y_true.sum())}, CRLs: {len(df) - int(y_true.sum())}")
```

---

## STEP 3: DEFINE THE GPU-ACCELERATED SCORING FUNCTION

```python
@cuda.jit
def odin_score_kernel(
    # Output
    predictions,
    # Feature arrays
    btd, orphan, priority_review, fast_track,
    experienced, mfg_risk, stack_count, had_adcom, prior_crl,
    ta_encoded,
    # Parameters (flattened)
    params,
    n_events
):
    \"\"\"CUDA kernel for parallel scoring\"\"\"
    idx = cuda.grid(1)
    if idx >= n_events:
        return

    # Unpack parameters
    base_prior = params[0]
    btd_w = params[1]
    orphan_w = params[2]
    pr_w = params[3]
    ft_w = params[4]
    exp_w = params[5]
    mfg_penalty = params[6]
    adcom_bonus = params[7]
    p003_penalty = params[8]
    # TA adjustments start at params[9]

    # Start with base prior
    poa = base_prior

    # Designation adjustments
    if btd[idx]:
        poa += btd_w
    if orphan[idx]:
        poa += orphan_w
    if priority_review[idx]:
        poa += pr_w
    if fast_track[idx]:
        poa += ft_w

    # Sponsor experience
    if experienced[idx]:
        poa += exp_w
    else:
        poa -= exp_w

    # Manufacturing risk (CRITICAL)
    if mfg_risk[idx]:
        poa += mfg_penalty  # Negative value

    # AdCom bonus
    if had_adcom[idx]:
        poa += adcom_bonus

    # P003: Low designation clinical risk
    if (experienced[idx] and not mfg_risk[idx] and 
        not btd[idx] and stack_count[idx] <= 1):
        poa += p003_penalty  # Negative value

    # Therapeutic area adjustment
    ta_idx = int(ta_encoded[idx])
    if ta_idx < 17:
        poa += params[9 + ta_idx]

    # Clamp to valid probability
    if poa < 0.01:
        poa = 0.01
    elif poa > 0.99:
        poa = 0.99

    predictions[idx] = poa


def score_configuration_gpu(params_dict):
    \"\"\"Score a configuration using GPU acceleration\"\"\"
    # Pack parameters into array
    params = cp.array([
        0.867,  # base_prior
        params_dict['btd_weight'],
        params_dict['orphan_weight'],
        params_dict['priority_review_weight'],
        params_dict['fast_track_weight'],
        params_dict['sponsor_exp_weight'],
        params_dict['mfg_risk_penalty'],
        params_dict['adcom_bonus'],
        params_dict['p003_penalty'],
        # TA adjustments (17 values)
        params_dict['ta_oncology'],
        params_dict['ta_infectious'],
        params_dict['ta_cns'],
        params_dict['ta_immunology'],
        params_dict['ta_rare'],
        params_dict['ta_cardio'],
        params_dict['ta_ophth'],
        params_dict['ta_pain'],
        params_dict['ta_metabolic'],
        params_dict['ta_nephrology'],
        params_dict['ta_respiratory'],
        params_dict['ta_derm'],
        params_dict['ta_gi'],
        params_dict['ta_hematology'],
        params_dict['ta_vaccines'],
        params_dict['ta_womens'],
        params_dict['ta_other'],
    ], dtype=cp.float32)

    # Allocate output
    n_events = len(y_true)
    predictions = cp.zeros(n_events, dtype=cp.float32)

    # Launch kernel
    threads_per_block = 256
    blocks = (n_events + threads_per_block - 1) // threads_per_block
    odin_score_kernel[blocks, threads_per_block](
        predictions,
        btd, orphan, priority_review, fast_track,
        experienced, mfg_risk, stack_count, had_adcom, prior_crl,
        ta_encoded,
        params,
        n_events
    )

    # Synchronize
    cp.cuda.Stream.null.synchronize()

    return predictions


def evaluate_configuration(params_dict, threshold=0.5):
    \"\"\"Evaluate a configuration and return all metrics\"\"\"
    predictions = score_configuration_gpu(params_dict)

    # Convert to CPU for sklearn metrics
    preds_cpu = cp.asnumpy(predictions)
    y_cpu = cp.asnumpy(y_true)

    # Binary predictions
    y_pred = (preds_cpu >= threshold).astype(int)

    # Calculate metrics
    tn, fp, fn, tp = confusion_matrix(y_cpu, y_pred).ravel()

    mcc = matthews_corrcoef(y_cpu, y_pred)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    brier = brier_score_loss(y_cpu, preds_cpu)

    return {
        'mcc': mcc,
        'precision': precision,
        'recall': recall,
        'specificity': specificity,
        'brier': brier,
        'tp': tp, 'fp': fp, 'fn': fn, 'tn': tn
    }
```

---

## STEP 4: DEFINE THE SEARCH SPACE (26 PARAMETERS)

```python
def create_search_space(trial):
    \"\"\"Define the full parameter search space\"\"\"
    return {
        # Designation weights
        'btd_weight': trial.suggest_float('btd_weight', 0.03, 0.18, step=0.005),
        'orphan_weight': trial.suggest_float('orphan_weight', 0.01, 0.10, step=0.005),
        'priority_review_weight': trial.suggest_float('priority_review_weight', 0.02, 0.15, step=0.005),
        'fast_track_weight': trial.suggest_float('fast_track_weight', 0.02, 0.12, step=0.005),

        # Experience weight
        'sponsor_exp_weight': trial.suggest_float('sponsor_exp_weight', 0.02, 0.12, step=0.005),

        # Manufacturing risk (CRITICAL - most important parameter)
        'mfg_risk_penalty': trial.suggest_float('mfg_risk_penalty', -0.50, -0.20, step=0.01),

        # AdCom bonus
        'adcom_bonus': trial.suggest_float('adcom_bonus', 0.05, 0.20, step=0.01),

        # P003 penalty
        'p003_penalty': trial.suggest_float('p003_penalty', -0.20, -0.03, step=0.005),

        # Therapeutic area adjustments (17 parameters)
        'ta_oncology': trial.suggest_float('ta_oncology', 0.02, 0.12, step=0.005),
        'ta_infectious': trial.suggest_float('ta_infectious', 0.05, 0.15, step=0.005),
        'ta_cns': trial.suggest_float('ta_cns', -0.18, -0.05, step=0.005),
        'ta_immunology': trial.suggest_float('ta_immunology', -0.02, 0.08, step=0.005),
        'ta_rare': trial.suggest_float('ta_rare', -0.10, 0.02, step=0.005),
        'ta_cardio': trial.suggest_float('ta_cardio', -0.15, -0.02, step=0.005),
        'ta_ophth': trial.suggest_float('ta_ophth', -0.20, -0.05, step=0.005),
        'ta_pain': trial.suggest_float('ta_pain', -0.40, -0.15, step=0.01),  # Worst TA
        'ta_metabolic': trial.suggest_float('ta_metabolic', -0.12, 0.02, step=0.005),
        'ta_nephrology': trial.suggest_float('ta_nephrology', -0.25, -0.08, step=0.005),
        'ta_respiratory': trial.suggest_float('ta_respiratory', 0.03, 0.15, step=0.005),
        'ta_derm': trial.suggest_float('ta_derm', -0.02, 0.08, step=0.005),
        'ta_gi': trial.suggest_float('ta_gi', 0.02, 0.12, step=0.005),
        'ta_hematology': trial.suggest_float('ta_hematology', -0.30, -0.10, step=0.01),
        'ta_vaccines': trial.suggest_float('ta_vaccines', 0.05, 0.20, step=0.01),
        'ta_womens': trial.suggest_float('ta_womens', 0.05, 0.20, step=0.01),
        'ta_other': trial.suggest_float('ta_other', -0.05, 0.05, step=0.005),
    }
```

---

## STEP 5: DEFINE THE OBJECTIVE FUNCTION

```python
def objective(trial):
    \"\"\"
    Optuna objective function
    Maximizes: MCC * 0.5 + (1 - Brier) * 0.3 + Specificity * 0.2
    Subject to: Precision >= 0.94 (HARD CONSTRAINT)
    \"\"\"
    params = create_search_space(trial)
    metrics = evaluate_configuration(params)

    # HARD CONSTRAINT: Precision must be >= 0.94
    if metrics['precision'] < 0.94:
        # Return very negative score to discourage
        return -1.0

    # Composite objective
    # Weight MCC heavily (0.5), then Brier (0.3), then Specificity (0.2)
    score = (
        metrics['mcc'] * 0.5 +
        (1 - metrics['brier']) * 0.3 +
        metrics['specificity'] * 0.2
    )

    # Store metrics for analysis
    trial.set_user_attr('mcc', metrics['mcc'])
    trial.set_user_attr('precision', metrics['precision'])
    trial.set_user_attr('recall', metrics['recall'])
    trial.set_user_attr('specificity', metrics['specificity'])
    trial.set_user_attr('brier', metrics['brier'])
    trial.set_user_attr('tp', metrics['tp'])
    trial.set_user_attr('fp', metrics['fp'])
    trial.set_user_attr('fn', metrics['fn'])
    trial.set_user_attr('tn', metrics['tn'])

    return score
```

---

## STEP 6: RUN 10,000,000+ ITERATIONS

```python
# Create study with advanced sampler
study = optuna.create_study(
    study_name='ODIN_v811_global_optimization',
    direction='maximize',
    sampler=TPESampler(
        n_startup_trials=10000,  # Random exploration first
        n_ei_candidates=24,
        multivariate=True,
        seed=42
    ),
    pruner=HyperbandPruner(
        min_resource=1,
        max_resource=100,
        reduction_factor=3
    )
)

# Run optimization - 10 MILLION TRIALS
# With GPU, expect ~1000-5000 trials/second
print("Starting 10,000,000 iteration optimization...")
print("Estimated time with GPU: 30-60 minutes")

study.optimize(
    objective,
    n_trials=10_000_000,
    n_jobs=1,  # Single job for GPU (GPU handles parallelism)
    show_progress_bar=True,
    gc_after_trial=False  # Faster without GC
)

print(f"\nOptimization complete!")
print(f"Total trials: {len(study.trials)}")
```

---

## STEP 7: EXTRACT AND VALIDATE TOP CONFIGURATIONS

```python
# Get top 100 configurations
top_trials = sorted(
    [t for t in study.trials if t.value is not None and t.value > 0],
    key=lambda t: t.value,
    reverse=True
)[:100]

print("\n" + "="*80)
print("TOP 10 CONFIGURATIONS")
print("="*80)

results = []
for i, trial in enumerate(top_trials[:10]):
    print(f"\n--- Configuration #{i+1} (Trial {trial.number}) ---")
    print(f"Score: {trial.value:.4f}")
    print(f"MCC: {trial.user_attrs['mcc']:.4f}")
    print(f"Precision: {trial.user_attrs['precision']:.4f}")
    print(f"Recall: {trial.user_attrs['recall']:.4f}")
    print(f"Specificity: {trial.user_attrs['specificity']:.4f}")
    print(f"Brier: {trial.user_attrs['brier']:.4f}")
    print(f"TP: {trial.user_attrs['tp']}, FP: {trial.user_attrs['fp']}")
    print(f"FN: {trial.user_attrs['fn']}, TN: {trial.user_attrs['tn']}")

    results.append({
        'rank': i+1,
        'trial': trial.number,
        'score': trial.value,
        **trial.user_attrs,
        **trial.params
    })

# Save results
results_df = pd.DataFrame(results)
results_df.to_csv('ODIN_optimization_top100.csv', index=False)
print("\nTop 100 configurations saved to ODIN_optimization_top100.csv")
```

---

## STEP 8: GENERATE CHAMPION CONFIGURATION JSON

```python
import json

best_trial = study.best_trial
champion_config = {
    "version": "8.12",
    "version_date": "2026-01-20",
    "status": "CHAMPION_CANDIDATE",
    "optimization_source": "ChatGPT_10M_Bayesian",
    "total_trials": len(study.trials),
    "best_trial_number": best_trial.number,

    "metrics": {
        "mcc": best_trial.user_attrs['mcc'],
        "precision": best_trial.user_attrs['precision'],
        "recall": best_trial.user_attrs['recall'],
        "specificity": best_trial.user_attrs['specificity'],
        "brier_score": best_trial.user_attrs['brier'],
        "tp": best_trial.user_attrs['tp'],
        "fp": best_trial.user_attrs['fp'],
        "fn": best_trial.user_attrs['fn'],
        "tn": best_trial.user_attrs['tn']
    },

    "parameters": best_trial.params,

    "improvement_vs_v86": {
        "mcc_delta": best_trial.user_attrs['mcc'] - 0.456,
        "precision_delta": best_trial.user_attrs['precision'] - 0.9502,
        "specificity_delta": best_trial.user_attrs['specificity'] - 0.7111,
        "brier_delta": best_trial.user_attrs['brier'] - 0.1761
    }
}

with open('ODIN_v812_CHAMPION_CONFIG.json', 'w') as f:
    json.dump(champion_config, f, indent=2)

print("\nChampion configuration saved to ODIN_v812_CHAMPION_CONFIG.json")
```

---

## STEP 9: CROSS-VALIDATION CHECK

```python
# Time-series cross-validation to check for overfitting
from sklearn.model_selection import TimeSeriesSplit

# Sort by date
df_sorted = df.sort_values('catalyst_date')
y_sorted = df_sorted['outcome_binary'].values

# 5-fold time series split
tscv = TimeSeriesSplit(n_splits=5)

cv_results = []
for fold, (train_idx, test_idx) in enumerate(tscv.split(df_sorted)):
    # Evaluate on test fold only
    test_df = df_sorted.iloc[test_idx]

    # Create temporary GPU arrays for test set
    # (You'd need to implement fold-specific scoring here)

    # For now, just track fold sizes
    cv_results.append({
        'fold': fold,
        'train_size': len(train_idx),
        'test_size': len(test_idx),
        'test_approval_rate': test_df['outcome_binary'].mean()
    })

print("\nCross-Validation Folds:")
for r in cv_results:
    print(f"Fold {r['fold']}: Train={r['train_size']}, Test={r['test_size']}, "
          f"Test Approval Rate={r['test_approval_rate']:.3f}")
```

---

## WHAT TO RETURN

After running, return:
1) ODIN_v812_CHAMPION_CONFIG.json
2) ODIN_optimization_top100.csv
3) Summary stats (trials, best MCC/Brier, targets met)
4) CV results
5) Parameter importance plot

---

## SUCCESS CRITERIA CHECKLIST

- MCC ≥ 0.50
- Precision ≥ 0.94
- Specificity ≥ 0.78
- Brier ≤ 0.12
- Stable across CV folds
- FP ≤ 38


# ODIN MASTER MIGRATION FILE — SESSION STATE SNAPSHOT
**Generated:** 2026-01-15 15:58 UTC

This document contains ALL critical context, progress, decisions, code artifacts, and next-step instructions
so a new chat can resume EXACTLY where we left off with zero loss of fidelity.

----------------------------------------------------------------
SECTION 1 — ROLES & MODE
----------------------------------------------------------------
- User / Arbiter: David
- ChatGPT Role: ODIN Engineering Authority
- Claude Role: ODIN Research / Logic Authority
- Gemini / Perplexity: Auxiliary research validation
- Current Mode: Mixed
  - LEARNING_ONLY default
  - Explicit one-time exception granted for FBIO live trading analysis

----------------------------------------------------------------
SECTION 2 — CURRENT PORTFOLIO STATE (KNOWN)
----------------------------------------------------------------
- Portfolio size: ~$36,000
- FBIO position: 6,800 shares
- GUTS position: $7,000 @ ~$2.01/share
- Risk tolerance: Moderate (avoid single-position blowup)

----------------------------------------------------------------
SECTION 3 — MAJOR COMPLETED WORK
----------------------------------------------------------------

### FBIO (Fortress Biotech)
- ZYCUBO / CUTX-101 approved Jan 13–14, 2026
- Rare Pediatric Disease Priority Review Voucher (PRV) earned
- PRV expected to be monetized in Q1 2026
- Market sold off post-approval (sell-the-news)
- Key upcoming catalysts:
  - PRV sale announcement
  - Analyst initiations/upgrades
  - Media exposure
  - Commercial launch updates via Sentynl

### GUTS (Fractyl Health)
- REMAIN-1 midpoint 3-month data positive (p=0.014)
- Supportive open-label and real-world durability data
- CEO open-market buy verified
- Warrant call / dilution risk identified
- ODIN GUTS Verification Pack v1 created

Files:
- ODIN_GUTS_VERIFICATION_PACK_v1.json
- ODIN_GUTS_VERIFICATION_DOSSIER.md

----------------------------------------------------------------
SECTION 4 — F013 INSIDER SENTIMENT MODULE
----------------------------------------------------------------
Status: IMPLEMENTED v1.2 — TESTED — READY FOR DATA PIPELINE

Core logic:
- Buying is signal; selling is noise
- 10b5-1 sales filtered
- Whale/cluster buys rewarded
- Cluster/mass exits penalized
- Mixed Sentiment Neutralizer (e.g., GUTS)
- POST_DATA_BUY requires >=$100k buy

Artifacts:
- ODIN_F013_MODULE.py
- ODIN_F013_FIXTURES.json
- test_f013.py
- f013_run_fixtures.py
- f013_edgar_pipeline.py
- ODIN_F013_INTEGRATION_NOTES.md
- ODIN_F013_MANIFEST.json
- ODIN_F013_ARTIFACT_HASHES.json

BLOCKER:
- BrainFin API credentials not yet connected

----------------------------------------------------------------
SECTION 5 — PHASE ENGINE STATUS
----------------------------------------------------------------
- Phase Engine v2.1 implemented
- v2.1.1 attempted and rejected (TN regression)
- Approved next path:
  - v2.2: Phase 2 effect size integration
  - v2.3: Structural refinements

----------------------------------------------------------------
SECTION 6 — JAN/FEB 2026 CATALYST SHORTLIST
----------------------------------------------------------------
- RGNX — RGX-121 PDUFA (Feb 8, 2026)
- ASND — TransCon CNP PDUFA (Feb 28, 2026)
- RCKT — LAD-I gene therapy decision (late Q1)
- ALDX — Reproxalap (high risk/high reward)
- RYTM — Imcivree label expansion

Goal: Rank by EV + F013 insider signal once BrainFin data is live.

----------------------------------------------------------------
SECTION 7 — LAST ACTIVE QUESTION
----------------------------------------------------------------
“Which Q1 catalysts have the largest net insider purchases vs sells?”

Answer pending BrainFin API pull.

----------------------------------------------------------------
SECTION 8 — NEXT STEPS (EXACT)
----------------------------------------------------------------
1. Start a new chat
2. Upload this file
3. Paste the following message:

“Resume as ODIN Engineering Authority. Load the ODIN MASTER MIGRATION FILE.
Current priority:
- Connect BrainFin API → run F013 on all Q1 catalysts
- Produce ranked table: net insider buys – sells + F013 score + EV rank
- Then finalize FBIO vs Q1 allocation decision.”

----------------------------------------------------------------
END OF MIGRATION FILE
----------------------------------------------------------------

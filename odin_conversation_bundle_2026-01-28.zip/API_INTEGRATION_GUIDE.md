# ODIN Multi-AI Orchestrator - API Integration Guide

## 🔧 Adding Your API Keys

The orchestrator is built with **placeholder methods** that are ready for you to add your API keys. Here's how to integrate each one.

---

## 1. ChatGPT / OpenAI Integration

### Where to Add
**File:** `odin_multi_ai_orchestrator.py`  
**Class:** `ChatGPTWorker`  
**Methods:** `_analyze_options()` and `_quick_validation()`

### Current Structure
```python
async def _analyze_options(self, task: Task) -> AIResponse:
    """Analyze option chain and calculate Greeks"""
    
    prompt = f"""..."""  # The prompt is already built
    
    # TODO: Replace with actual OpenAI API call
    # This is a placeholder for structure
    tokens_estimate = await self.estimate_tokens(prompt)
    
    return AIResponse(
        ai=self.expertise,
        task_id=task.task_id,
        success=True,
        data={...},  # Response data structure
        tokens=tokens_estimate,
        confidence=0.92
    )
```

### Your Implementation
```python
async def _analyze_options(self, task: Task) -> AIResponse:
    """Analyze option chain and calculate Greeks"""
    
    prompt = f"""..."""  # Prompt already exists
    
    # ADD THIS:
    import openai
    openai.api_key = self.api_key
    
    response = await openai.ChatCompletion.acreate(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a derivatives expert..."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,  # Low temp for math
        max_tokens=1000
    )
    
    # Parse response
    result_text = response.choices[0].message.content
    result_json = json.loads(result_text)  # Expect JSON
    
    tokens_estimate = {
        "input": response.usage.prompt_tokens,
        "output": response.usage.completion_tokens,
        "searches": 0
    }
    
    return AIResponse(
        ai=self.expertise,
        task_id=task.task_id,
        success=True,
        data=result_json,
        tokens=tokens_estimate,
        confidence=0.92
    )
```

### Environment Variable
```bash
# Add to your .env or export:
export OPENAI_API_KEY="sk-proj-xxxxxxxxxxxxxxxxxxxxx"
```

---

## 2. Claude / Anthropic Integration

### Where to Add
**File:** `odin_multi_ai_orchestrator.py`  
**Class:** `ClaudeWorker`  
**Methods:** `_analyze_pdufa_risk()` and `_deep_analysis()`

### Your Implementation
```python
async def _analyze_pdufa_risk(self, task: Task) -> AIResponse:
    """Deep PDUFA outcome probability assessment"""
    
    prompt = f"""..."""  # Prompt already exists
    
    # ADD THIS:
    import anthropic
    client = anthropic.Anthropic(api_key=self.api_key)
    
    message = await client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=2000,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    result_text = message.content[0].text
    result_json = json.loads(result_text)
    
    tokens_estimate = {
        "input": message.usage.input_tokens,
        "output": message.usage.output_tokens,
        "searches": 0
    }
    
    return AIResponse(
        ai=self.expertise,
        task_id=task.task_id,
        success=True,
        data=result_json,
        tokens=tokens_estimate,
        confidence=0.76
    )
```

### Environment Variable
```bash
export ANTHROPIC_API_KEY="sk-ant-xxxxxxxxxxxxxxxxxxxxx"
```

---

## 3. Gemini / Google Integration

### Where to Add
**File:** `odin_multi_ai_orchestrator.py`  
**Class:** `GeminiWorker`  
**Methods:** `_search_fda_news()` and `_parse_insider_trades()`

### Your Implementation
```python
async def _search_fda_news(self, task: Task) -> AIResponse:
    """Search for FDA announcements and regulatory news"""
    
    search_queries = [
        f"FDA approval {task.ticker} PDUFA {datetime.now().year}",
        f"{task.payload.get('drug_name', '')} FDA decision",
    ]
    
    # ADD THIS:
    import google.generativeai as genai
    genai.configure(api_key=self.api_key)
    
    # Search using web grounding (requires Google Search API)
    model = genai.GenerativeModel('gemini-2.5-pro')
    
    search_results = []
    for query in search_queries:
        response = await model.generate_content(
            f"Search for: {query}\n\nReturn JSON with results, dates, sources",
            search_tool=True  # Enable web search
        )
        search_results.append(response.text)
    
    # Aggregate results
    aggregated = "\n".join(search_results)
    result_json = json.loads(aggregated)
    
    tokens_estimate = {
        "input": 5000,  # Estimate
        "output": 2000,  # Estimate
        "searches": len(search_queries)
    }
    
    return AIResponse(
        ai=self.expertise,
        task_id=task.task_id,
        success=True,
        data=result_json,
        tokens=tokens_estimate,
        confidence=0.85
    )
```

### Environment Variable
```bash
export GEMINI_API_KEY="AIzaxxxxxxxxxxxxxxxxxxxxx"
# Also need: GOOGLE_SEARCH_API_KEY for web search functionality
export GOOGLE_SEARCH_API_KEY="xxxxxxxxxxxxx"
```

---

## 4. Perplexity Integration

### Where to Add
**File:** `odin_multi_ai_orchestrator.py`  
**Class:** `PerplexityWorker`  
**Methods:** `_synthesize_signals()` and `_validate_catalyst()`

### Your Implementation
```python
async def _synthesize_signals(self, task: Task) -> AIResponse:
    """Synthesize signals from all 4 AIs into final recommendation"""
    
    prompt = f"""..."""  # Prompt already exists
    
    # ADD THIS:
    import httpx
    
    headers = {
        "Authorization": f"Bearer {self.api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": "sonar-pro",
        "messages": [
            {"role": "system", "content": "You are a financial synthesis expert..."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.5,
        "top_p": 0.9,
        "max_tokens": 1500,
        "search_recency_filter": "month",
        "return_citations": True
    }
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://api.perplexity.ai/chat/completions",
            json=payload,
            headers=headers
        )
    
    result = response.json()
    result_text = result["choices"][0]["message"]["content"]
    result_json = json.loads(result_text)
    
    tokens_estimate = {
        "input": result["usage"]["prompt_tokens"],
        "output": result["usage"]["completion_tokens"],
        "searches": len(result.get("search_sources", []))
    }
    
    return AIResponse(
        ai=self.expertise,
        task_id=task.task_id,
        success=True,
        data=result_json,
        tokens=tokens_estimate,
        confidence=0.84
    )
```

### Environment Variable
```bash
export PERPLEXITY_API_KEY="pplx-xxxxxxxxxxxxxxxxxxxxx"
```

---

## 5. Setup Your Environment

### Option A: .env File (Recommended)
```bash
# Create .env file in your project root
cat > .env << EOF
# OpenAI
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxx

# Anthropic
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxx

# Google
GEMINI_API_KEY=AIzaxxxxxxxxxxxxxxxxxxxxx
GOOGLE_SEARCH_API_KEY=xxxxxxxxxxxxx

# Perplexity
PERPLEXITY_API_KEY=pplx-xxxxxxxxxxxxxxxxxxxxx
EOF
```

### Option B: Export Environment Variables
```bash
export OPENAI_API_KEY="sk-proj-xxxxxxxxxxxxxxxxxxxxx"
export ANTHROPIC_API_KEY="sk-ant-xxxxxxxxxxxxxxxxxxxxx"
export GEMINI_API_KEY="AIzaxxxxxxxxxxxxxxxxxxxxx"
export GOOGLE_SEARCH_API_KEY="xxxxxxxxxxxxx"
export PERPLEXITY_API_KEY="pplx-xxxxxxxxxxxxxxxxxxxxx"
```

### Option C: Load from ~/.bashrc or ~/.zshrc
```bash
# Add to your shell profile:
echo 'export OPENAI_API_KEY="sk-proj-xxxxxxxxxxxxxxxxxxxxx"' >> ~/.bashrc
source ~/.bashrc
```

---

## 6. Install Required Libraries

```bash
# OpenAI
pip install openai

# Anthropic
pip install anthropic

# Google
pip install google-generativeai

# Perplexity (uses httpx)
pip install httpx

# Python environment management
pip install python-dotenv

# Full requirements
pip install openai anthropic google-generativeai httpx python-dotenv asyncio
```

### requirements.txt
```
openai>=1.3.0
anthropic>=0.7.0
google-generativeai>=0.3.0
httpx>=0.24.0
python-dotenv>=1.0.0
flask>=2.3.0
sqlite3
```

---

## 7. Test Each API Integration

### Test Script
```python
import asyncio
import os
from dotenv import load_dotenv
from odin_multi_ai_orchestrator import OdinOrchestrator, Task, TaskType, TaskPriority

async def test_apis():
    load_dotenv()
    
    orchestrator = OdinOrchestrator()
    orchestrator.set_budget("conservative")
    
    # Test 1: ChatGPT Options Analysis
    print("\n🧪 Testing ChatGPT (Options Analysis)")
    task1 = Task(
        task_id="TEST_OPENAI",
        task_type=TaskType.OPTIONS_ANALYSIS,
        priority=TaskPriority.HIGH,
        ticker="GUTS",
        payload={"check_iv": True, "expiration": "3m"}
    )
    success1, cost1 = await orchestrator.execute_task(task1)
    print(f"Result: {'✅ PASS' if success1 else '❌ FAIL'} - Cost: ${cost1:.4f}")
    
    # Test 2: Claude PDUFA Analysis
    print("\n🧪 Testing Claude (PDUFA Analysis)")
    task2 = Task(
        task_id="TEST_CLAUDE",
        task_type=TaskType.PDUFA_MONITORING,
        priority=TaskPriority.CRITICAL,
        ticker="GUTS",
        payload={"check_type": "fda_news"}
    )
    success2, cost2 = await orchestrator.execute_task(task2)
    print(f"Result: {'✅ PASS' if success2 else '❌ FAIL'} - Cost: ${cost2:.4f}")
    
    # Test 3: Gemini FDA Search
    print("\n🧪 Testing Gemini (FDA Search)")
    task3 = Task(
        task_id="TEST_GEMINI",
        task_type=TaskType.INSIDER_DETECTION,
        priority=TaskPriority.MEDIUM,
        ticker="GUTS",
        payload={"lookback_days": 3}
    )
    success3, cost3 = await orchestrator.execute_task(task3)
    print(f"Result: {'✅ PASS' if success3 else '❌ FAIL'} - Cost: ${cost3:.4f}")
    
    # Test 4: Perplexity Synthesis
    print("\n🧪 Testing Perplexity (Signal Synthesis)")
    task4 = Task(
        task_id="TEST_PERPLEXITY",
        task_type=TaskType.SIGNAL_SYNTHESIS,
        priority=TaskPriority.HIGH,
        ticker="GUTS",
        payload={"synthesize_all": True}
    )
    success4, cost4 = await orchestrator.execute_task(task4)
    print(f"Result: {'✅ PASS' if success4 else '❌ FAIL'} - Cost: ${cost4:.4f}")
    
    # Print summary
    print("\n" + "="*70)
    print("INTEGRATION TEST SUMMARY")
    print("="*70)
    total_cost = cost1 + cost2 + cost3 + cost4
    passed = sum([success1, success2, success3, success4])
    print(f"Passed: {passed}/4")
    print(f"Total Cost: ${total_cost:.4f}")
    
    orchestrator.print_status()

if __name__ == "__main__":
    asyncio.run(test_apis())
```

### Run Tests
```bash
python test_api_integration.py
```

---

## 8. Async Implementation Notes

**Important:** All API calls are async to enable parallel execution. Here's why:

```python
# With async, all 4 AIs run in parallel:
await asyncio.gather(
    openai_worker.process_task(task1),
    claude_worker.process_task(task2),
    gemini_worker.process_task(task3),
    perplexity_worker.process_task(task4)
)
# Total time: ~3 seconds (fastest AI) instead of ~12 seconds (serial)
```

Make sure your API calls use `await` properly.

---

## 9. Error Handling

Each worker has try/except blocks. Improve them:

```python
async def process_task(self, task: Task) -> AIResponse:
    try:
        response = await worker.process_task(task)
        # ... process response
        
    except openai.AuthenticationError:
        return AIResponse(
            ai=self.expertise,
            task_id=task.task_id,
            success=False,
            error="Invalid API key for OpenAI"
        )
    
    except openai.RateLimitError:
        await asyncio.sleep(30)  # Wait and retry
        return await self.process_task(task)
    
    except Exception as e:
        return AIResponse(
            ai=self.expertise,
            task_id=task.task_id,
            success=False,
            error=f"Unexpected error: {str(e)}"
        )
```

---

## 10. Production Deployment Checklist

- [ ] All 4 API keys in environment (never hardcode)
- [ ] Test each API integration independently
- [ ] Run test_api_integration.py and confirm all 4 pass
- [ ] Set budget level (start with "conservative")
- [ ] Start orchestrator: `python odin_multi_ai_orchestrator.py`
- [ ] Monitor cost dashboard: `python odin_cost_dashboard.py`
- [ ] Let it run for 24 hours, check spending vs. results
- [ ] Scale to "moderate" if signal quality good
- [ ] Enable autonomous loops once confident

---

## 11. Common Issues

**Issue:** "API key not found"  
**Solution:** Verify `export` commands executed and env vars set:
```bash
echo $OPENAI_API_KEY  # Should print your key, not blank
```

**Issue:** "Rate limit exceeded"  
**Solution:** Your cost controller will handle this by blocking calls. Increase daily budget or wait for reset.

**Issue:** "Async error: RuntimeError: no running event loop"  
**Solution:** Make sure you're calling from `async def` function and using `await` properly.

**Issue:** "JSON parse error"  
**Solution:** Some APIs return text, not JSON. Add parsing:
```python
try:
    result_json = json.loads(response_text)
except json.JSONDecodeError:
    # Extract JSON from text if wrapped
    import re
    json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
    result_json = json.loads(json_match.group())
```

---

## 12. Next Steps

1. **Add your API keys** to environment
2. **Run test script** to verify all 4 AIs work
3. **Start cost dashboard:** `python odin_cost_dashboard.py`
4. **Start orchestrator:** (in development mode first)
5. **Monitor for 24 hours** - check cost vs. signal quality
6. **Enable autonomous loops** once confident

---

**Once APIs are integrated, the system runs fully autonomously.** 🚀

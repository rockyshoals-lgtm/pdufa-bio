# ODIN v8.8 Unified REALOPT Config (JSON wrapped for Claude upload)

Markdown wrapper around the optimized v8.8 config JSON. The JSON is intact inside the code block.

```json
{
  "version": "v8.8_unified_realopt",
  "base": "ODIN_v88_UNIFIED_CONFIG.json",
  "trained_on_years": [
    2020,
    2021,
    2022,
    2023,
    2024
  ],
  "validated_on_year": 2024,
  "tested_on_years": [
    2025,
    2026
  ],
  "objective": "minimize Brier on 2024 with Platt fit on 2020-2023; final Platt fit on 2020-2024",
  "core_params": {
    "base": 57.0,
    "threshold": 48.0,
    "btd": 7.0,
    "orphan": 0.0,
    "priority": 0.0,
    "fast_track": 0.0,
    "accel": 0.0,
    "exp": 0.0,
    "some_exp": 25.0,
    "stack5": 3.0,
    "stack4": 0.0,
    "stack3": 0.0,
    "stack_exp": 0.0,
    "gene_cell": 0.0,
    "onc": 1.0,
    "inf": 2.0,
    "pain": -5.0,
    "hemato": 0.0,
    "nephro": 0.0,
    "ophthal": 0.0,
    "cns": -2.0,
    "cardio": 0.0,
    "metab": -7.0,
    "mfg": -17.0,
    "mfg_inexp": -11.0,
    "inexp_highta": 0.0,
    "inexp_sm": -19.0,
    "exp_onc": 0.0,
    "adcom_strong": 0.0,
    "adcom_pos": 0.0,
    "adcom_neg": -10.0,
    "generic_bonus": 12.0
  },
  "patch_params": {
    "low_des_clin_penalty": 0.0,
    "silent_failure_penalty": 0.0
  },
  "modality_multipliers": {
    "cgt": 1.3,
    "adc": 1.2,
    "antibody": 1.1,
    "small_molecule": 1.0
  },
  "platt_final": {
    "a": 0.27937502130709285,
    "b": -13.596428039089536
  },
  "metrics": {
    "val_brier_best": 0.038201973322349723,
    "train_brier_at_best_val": 0.05441010365535368,
    "test_brier_with_final_platt": 0.0458918605023088,
    "test_n": 230,
    "test_approval_rate": 0.8956521739130435
  }
}
```

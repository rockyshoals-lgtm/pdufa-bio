#!/usr/bin/env python3
"""
ODIN v9.2 GPU Billion-Parameter Optimization (Auto-RAM/VRAM tuned)
==================================================================

Key upgrades vs original:
- ✅ Avoids allocating probs[batch_size, n_events] (prevents GPU/CPU OOM)
- ✅ Auto-tunes batch size from available VRAM (GPU) or RAM (CPU)
- ✅ Precomputes event coefficient matrix once (faster per batch)
- ✅ Generates random params directly on GPU when available (less transfer)
- ✅ More robust checkpointing (works even when batch_size changes)

Usage:
    python odin_v92_gpu_optimizer_autoram.py --data ODIN_ENRICHED_PDUFA_1349_v2.csv

Optional:
    --total-configs 1000000000
    --batch-size 2500000              # overrides auto-tuning
    --event-chunk 32                  # events per matmul chunk
    --ram-fraction 0.60               # CPU mode memory utilization target
    --vram-fraction 0.70              # GPU mode memory utilization target
    --checkpoint-interval 100000000   # save every N configs processed
"""

from __future__ import annotations

import argparse
import json
import os
import time
from datetime import datetime
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


# =============================================================================
# GPU / XP BACKEND SELECTION
# =============================================================================

def _try_import_cupy():
    try:
        import cupy as cp  # type: ignore
        # Warm device to ensure runtime initialized
        _ = cp.cuda.runtime.getDeviceCount()
        return cp, True
    except Exception:
        return np, False


cp, GPU_AVAILABLE = _try_import_cupy()
xp = cp if GPU_AVAILABLE else np


def get_free_gpu_bytes() -> int:
    """Return free GPU memory bytes (0 if GPU not available)."""
    if not GPU_AVAILABLE:
        return 0
    free_b, _total_b = cp.cuda.runtime.memGetInfo()
    return int(free_b)


def get_available_ram_bytes() -> int:
    """Return available system RAM bytes (best-effort, no hard dependency on psutil)."""
    # Prefer psutil if present (most reliable)
    try:
        import psutil  # type: ignore
        return int(psutil.virtual_memory().available)
    except Exception:
        pass

    # Linux fallback (common in servers/containers)
    try:
        pages = os.sysconf("SC_AVPHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        return int(pages * page_size)
    except Exception:
        # Last resort: assume 8GB available
        return int(8 * (1024 ** 3))


# =============================================================================
# CONFIGURATION
# =============================================================================

DEFAULT_TOTAL_CONFIGS = 1_000_000_000
DEFAULT_BATCH_SIZE = 2_500_000          # used only if auto-tune cannot compute
DEFAULT_EVENT_CHUNK = 32
DEFAULT_CHECKPOINT_INTERVAL = 100_000_000

# Parameter bounds for optimization
PARAM_BOUNDS: Dict[str, Tuple[float, float]] = {
    # Designation weights
    "btd_weight": (0.02, 0.12),
    "orphan_weight": (0.01, 0.08),
    "priority_review_weight": (0.02, 0.10),
    "fast_track_weight": (0.01, 0.06),
    "accelerated_approval_weight": (0.01, 0.06),

    # Stack interactions
    "no_designation_penalty": (-0.10, -0.02),
    "btd_pr_synergy_bonus": (0.04, 0.15),
    "btd_alone_bonus": (0.03, 0.12),
    "full_stack_bonus": (0.02, 0.08),

    # AdCom
    "adcom_high_boost": (0.04, 0.15),
    "adcom_mid_penalty": (-0.12, -0.02),
    "adcom_low_penalty": (-0.25, -0.08),

    # Prior CRL
    "prior_crl_penalty": (-0.18, -0.05),
    "class1_resubmission_boost": (0.08, 0.22),
    "class2_resubmission_penalty": (-0.12, -0.02),

    # Sponsor experience
    "sponsor_one_approval_penalty": (-0.10, -0.02),
    "sponsor_sweet_spot_boost": (0.04, 0.15),
    "sponsor_mid_tier_penalty": (-0.08, 0.0),
    "sponsor_large_pharma_boost": (0.02, 0.10),

    # Manufacturing
    "form_483_penalty": (-0.15, -0.03),
    "ta_adjustment_weight": (0.005, 0.02),
    "temporal_2024_plus_boost": (0.01, 0.06),

    # Tier thresholds
    "tier1_threshold": (0.88, 0.93),
    "tier2_threshold": (0.85, 0.89),
    "tier3_threshold": (0.80, 0.86),
}

# TA adjustments and modality penalties (same structure as original script)
TA_ADJUSTMENTS = {
    "Oncology": 0.03,
    "Rare Disease": 0.04,
    "CNS/Neurology": -0.02,
    "Cardiology": -0.01,
    "Metabolic/Endocrine": -0.01,
    "Immunology": 0.01,
    "Infectious Disease": 0.00,
    "Other": 0.00,
}

MODALITY_MFG_PENALTIES = {
    "Small Molecule": -0.04,
    "Antibody": -0.03,
    "Peptide": -0.04,
    "Gene Therapy": -0.10,
    "Cell Therapy": -0.12,
    "RNA": -0.06,
    "Other": -0.05,
}


# =============================================================================
# DATA LOADING
# =============================================================================

def load_and_prepare_data(filepath: str):
    """
    Load and prepare PDUFA event data for GPU optimization.

    Returns:
        features: np.ndarray shape (n_events, 16)
        outcomes: np.ndarray shape (n_events,)
        metadata: dict with TA/modality mappings
    """
    df = pd.read_csv(filepath)

    # Encode therapeutic areas and modalities
    ta_list = sorted(list(set(df["therapeutic_area"].fillna("Other").values)))
    modality_list = sorted(list(set(df["modality"].fillna("Other").values)))

    ta_map = {ta: i for i, ta in enumerate(ta_list)}
    modality_map = {mod: i for i, mod in enumerate(modality_list)}

    n_events = len(df)
    n_features = 16
    features = np.zeros((n_events, n_features), dtype=np.float32)
    outcomes = np.zeros(n_events, dtype=np.float32)

    # NOTE: iterrows() is OK at n~1349; leaving as-is.
    for i, row in df.iterrows():
        features[i, 0] = float(row.get("btd", False) is True)
        features[i, 1] = float(row.get("orphan", False) is True)
        features[i, 2] = float(row.get("priority_review", False) is True)
        features[i, 3] = float(row.get("fast_track", False) is True)
        features[i, 4] = float(row.get("accelerated_approval", False) is True)

        features[i, 5] = float(row.get("adcom", False) is True)
        features[i, 6] = float(row.get("adcom_vote", 0.0) or 0.0)

        features[i, 7] = float(row.get("prior_crl", False) is True)
        features[i, 8] = float(row.get("resubmission_class", 0) or 0)
        features[i, 9] = float(row.get("sponsor_approvals", 0) or 0)

        features[i, 10] = float(row.get("mfg_risk", 0.0) or 0.0)
        features[i, 11] = float(row.get("form_483", False) is True)

        ta = row.get("therapeutic_area", "Other") or "Other"
        mod = row.get("modality", "Other") or "Other"
        features[i, 12] = ta_map.get(ta, ta_map.get("Other", 0))
        features[i, 13] = modality_map.get(mod, modality_map.get("Other", 0))

        features[i, 14] = float(row.get("year", 2024) or 2024)
        features[i, 15] = float(row.get("phase", 0) or 0)

        outcome = row.get("outcome", "APPROVAL")
        outcomes[i] = 1.0 if str(outcome).upper() == "APPROVAL" else 0.0

    metadata = {
        "ta_list": ta_list,
        "modality_list": modality_list,
        "ta_map": ta_map,
        "modality_map": modality_map,
        "ta_adjustments": [TA_ADJUSTMENTS.get(ta, 0.0) for ta in ta_list],
        "mod_penalties": [MODALITY_MFG_PENALTIES.get(mod, -0.05) for mod in modality_list],
    }
    return features, outcomes, metadata


# =============================================================================
# PRECOMPUTATION (depends only on features/outcomes, not params)
# =============================================================================

def precompute_event_matrices(features_xp, outcomes_xp, metadata, *, xp_backend):
    """
    Build:
      - coeffs: (n_events, 22) float32 coefficient matrix for the 22 linear params
      - mfg_term: (n_events,) float32 constant additive term (mfg_risk * modality_penalty)
      - outcomes: (n_events,) float32
      - crl_mask: (n_events,) bool
    """
    # Base feature columns
    btd = features_xp[:, 0].astype(xp_backend.float32)
    orphan = features_xp[:, 1].astype(xp_backend.float32)
    pr = features_xp[:, 2].astype(xp_backend.float32)
    ft = features_xp[:, 3].astype(xp_backend.float32)
    aa = features_xp[:, 4].astype(xp_backend.float32)

    adcom = features_xp[:, 5].astype(xp_backend.float32)
    adcom_vote = features_xp[:, 6].astype(xp_backend.float32)

    prior_crl = features_xp[:, 7].astype(xp_backend.float32)
    resub_class = features_xp[:, 8].astype(xp_backend.float32)
    sponsor_approvals = features_xp[:, 9].astype(xp_backend.float32)

    mfg_risk = features_xp[:, 10].astype(xp_backend.float32)
    form_483 = features_xp[:, 11].astype(xp_backend.float32)

    ta_idx = features_xp[:, 12].astype(xp_backend.int32)
    mod_idx = features_xp[:, 13].astype(xp_backend.int32)

    year = features_xp[:, 14].astype(xp_backend.float32)

    # Masks / interactions
    no_desig = (btd == 0) & (orphan == 0) & (pr == 0) & (ft == 0)
    btd_pr = (btd == 1) & (pr == 1) & (orphan == 0)
    btd_alone = (btd == 1) & (orphan == 0) & (pr == 0)
    full_stack = (btd == 1) & (orphan == 1) & (pr == 1) & (ft == 1)

    adcom_high = (adcom == 1) & (adcom_vote >= 0.65)
    adcom_mid = (adcom == 1) & (adcom_vote >= 0.50) & (adcom_vote < 0.65)
    adcom_low = (adcom == 1) & (adcom_vote < 0.50) & (adcom_vote > 0.0)

    class1 = (prior_crl == 1) & (resub_class == 1)
    class2 = (prior_crl == 1) & (resub_class == 2)

    sponsor_one = (sponsor_approvals == 1)
    sponsor_sweet = (sponsor_approvals >= 2) & (sponsor_approvals <= 3)
    sponsor_mid = (sponsor_approvals >= 4) & (sponsor_approvals <= 10)
    sponsor_large = (sponsor_approvals > 10)

    year_2024_plus = (year >= 2024)

    # TA and modality arrays
    ta_adj_array = xp_backend.asarray(metadata["ta_adjustments"], dtype=xp_backend.float32)
    mod_pen_array = xp_backend.asarray(metadata["mod_penalties"], dtype=xp_backend.float32)

    ta_adj = ta_adj_array[ta_idx]  # (n_events,)
    mod_pen = mod_pen_array[mod_idx]  # (n_events,)
    mfg_term = mfg_risk * mod_pen  # (n_events,)

    coeffs = xp_backend.stack(
        [
            btd,
            orphan,
            pr,
            ft,
            aa,
            no_desig.astype(xp_backend.float32),
            btd_pr.astype(xp_backend.float32),
            btd_alone.astype(xp_backend.float32),
            full_stack.astype(xp_backend.float32),
            adcom_high.astype(xp_backend.float32),
            adcom_mid.astype(xp_backend.float32),
            adcom_low.astype(xp_backend.float32),
            prior_crl,
            class1.astype(xp_backend.float32),
            class2.astype(xp_backend.float32),
            sponsor_one.astype(xp_backend.float32),
            sponsor_sweet.astype(xp_backend.float32),
            sponsor_mid.astype(xp_backend.float32),
            sponsor_large.astype(xp_backend.float32),
            form_483,
            ta_adj,
            year_2024_plus.astype(xp_backend.float32),
        ],
        axis=1,
    )  # (n_events, 22)

    outcomes = outcomes_xp.astype(xp_backend.float32)
    crl_mask = outcomes == 0.0
    return coeffs, mfg_term.astype(xp_backend.float32), outcomes, crl_mask


# =============================================================================
# PARAM GENERATION
# =============================================================================

def generate_random_params(batch_size: int, *, xp_backend):
    """Generate random parameter configurations within bounds on the chosen backend."""
    param_names = list(PARAM_BOUNDS.keys())
    n_params = len(param_names)

    # Allocate param matrix on backend directly
    params = xp_backend.empty((batch_size, n_params), dtype=xp_backend.float32)

    for i, name in enumerate(param_names):
        low, high = PARAM_BOUNDS[name]
        # cupy.random.uniform supports dtype in newer versions; cast as a fallback
        try:
            params[:, i] = xp_backend.random.uniform(low, high, size=batch_size, dtype=xp_backend.float32)
        except TypeError:
            params[:, i] = xp_backend.random.uniform(low, high, size=batch_size).astype(xp_backend.float32)

    return params


# =============================================================================
# AUTO-TUNING (RAM/VRAM)
# =============================================================================

def auto_tune_batch_size(
    *,
    n_params: int,
    n_events: int,
    event_chunk: int,
    ram_fraction: float,
    vram_fraction: float,
    min_batch: int = 50_000,
    max_batch: int = 10_000_000,
) -> int:
    """
    Compute a safe-ish batch size based on memory availability.

    Memory model (approx):
      params: batch_size * n_params * 4
      p_chunk: batch_size * event_chunk * 4
      tier masks/temps: ~ batch_size * event_chunk * 2   (bool + small temps)
      accumulators: ~ batch_size * 16 bytes

    We apply a safety factor via ram_fraction / vram_fraction.
    """
    bytes_per_param_row = n_params * 4
    bytes_per_chunk = event_chunk * 4
    bytes_overhead_per_config = 24  # brier_sum + counts + misc
    # Conservative: assume ~2x chunk buffers due to temporaries / allocator behavior
    approx_bytes_per_config = bytes_per_param_row + (bytes_per_chunk * 2) + (event_chunk * 2) + bytes_overhead_per_config

    if GPU_AVAILABLE:
        budget_bytes = int(get_free_gpu_bytes() * float(vram_fraction))
    else:
        budget_bytes = int(get_available_ram_bytes() * float(ram_fraction))

    if budget_bytes <= 0:
        return DEFAULT_BATCH_SIZE

    # Heuristic clamp
    max_bs = int(budget_bytes // max(1, approx_bytes_per_config))
    tuned = max(min_batch, min(max_bs, max_batch))
    return tuned


# =============================================================================
# SCORING (blocked; no probs[batch_size, n_events] allocation)
# =============================================================================

def batch_score_blocked(
    params_xp,
    coeffs_xp,
    mfg_term_xp,
    outcomes_xp,
    crl_mask_xp,
    *,
    base: float = 0.867,
    event_chunk: int = DEFAULT_EVENT_CHUNK,
    xp_backend,
):
    """
    Score a batch of configs without allocating probs for all events at once.

    Returns:
      brier: (batch_size,) float32
      tier4_crl_rate: (batch_size,) float32
      tier4_counts: (batch_size,) int32
      crl_recall: (batch_size,) float32
    """
    batch_size = params_xp.shape[0]
    n_events = coeffs_xp.shape[0]

    # Split params
    params_main = params_xp[:, :22]  # (batch, 22)
    tier3_thresh = params_xp[:, 24].astype(xp_backend.float32)  # (batch,)

    # Accumulators
    brier_sum = xp_backend.zeros((batch_size,), dtype=xp_backend.float32)
    tier4_counts = xp_backend.zeros((batch_size,), dtype=xp_backend.int32)
    tier4_crls = xp_backend.zeros((batch_size,), dtype=xp_backend.int32)
    detected_crls = xp_backend.zeros((batch_size,), dtype=xp_backend.int32)

    total_crls = int(crl_mask_xp.sum()) if not GPU_AVAILABLE else int(crl_mask_xp.sum().get())

    for start in range(0, n_events, event_chunk):
        end = min(start + event_chunk, n_events)

        coeff_chunk = coeffs_xp[start:end]           # (chunk, 22)
        mfg_chunk = mfg_term_xp[start:end]           # (chunk,)
        outcomes_chunk = outcomes_xp[start:end]      # (chunk,)
        crl_chunk = crl_mask_xp[start:end]           # (chunk,)

        # p_chunk = base + params_main @ coeff_chunk.T + mfg_chunk
        # (batch, 22) @ (22, chunk) -> (batch, chunk)
        p_chunk = params_main @ coeff_chunk.T
        p_chunk += xp_backend.float32(base)
        p_chunk += mfg_chunk  # broadcast
        p_chunk = xp_backend.clip(p_chunk, 0.01, 0.99)

        # Tier4 metrics first (then we can overwrite p_chunk for Brier if desired)
        tier4_mask = p_chunk < tier3_thresh[:, None]
        tier4_counts += tier4_mask.sum(axis=1).astype(xp_backend.int32)

        if total_crls > 0:
            # Count tier4 CRLs and recall-85% only on CRL events
            tier4_crls += (tier4_mask & crl_chunk[None, :]).sum(axis=1).astype(xp_backend.int32)
            detected_crls += ((p_chunk < 0.85) & crl_chunk[None, :]).sum(axis=1).astype(xp_backend.int32)

        # Brier (in-place to avoid extra big temp):
        p_chunk -= outcomes_chunk
        p_chunk *= p_chunk
        brier_sum += p_chunk.sum(axis=1)

    brier = brier_sum / xp_backend.float32(n_events)
    tier4_crl_rate = xp_backend.where(
        tier4_counts > 0,
        tier4_crls.astype(xp_backend.float32) / tier4_counts.astype(xp_backend.float32),
        xp_backend.float32(0.0),
    )
    if total_crls > 0:
        crl_recall = detected_crls.astype(xp_backend.float32) / xp_backend.float32(total_crls)
    else:
        crl_recall = xp_backend.zeros((batch_size,), dtype=xp_backend.float32)

    return brier, tier4_crl_rate, tier4_counts, crl_recall


# =============================================================================
# CHECKPOINTING
# =============================================================================

def save_checkpoint(filepath: str, batch_idx: int, configs_processed: int, best_metrics: dict, best_params: List[float]):
    checkpoint = {
        "batch_idx": batch_idx,
        "configs_processed": configs_processed,
        "best_metrics": best_metrics,
        "best_params": best_params,
        "timestamp": datetime.now().isoformat(),
    }
    with open(filepath, "w") as f:
        json.dump(checkpoint, f, indent=2)
    print(f"  💾 Checkpoint saved: {filepath}")


def save_champion_config(best_params, best_metrics):
    param_names = list(PARAM_BOUNDS.keys())
    config = {
        "version": "9.2",
        "optimization": {
            "method": "GPU_random_search_autoram",
            "configs_tested": int(best_metrics.get("configs_tested", 0)),
            "timestamp": datetime.now().isoformat(),
        },
        "performance": best_metrics,
        "champion_params": {name: float(best_params[i]) for i, name in enumerate(param_names)},
        "therapeutic_area_adjustments": TA_ADJUSTMENTS,
        "modality_mfg_penalties": MODALITY_MFG_PENALTIES,
    }
    filepath = "ODIN_v92_CHAMPION_CONFIG.json"
    with open(filepath, "w") as f:
        json.dump(config, f, indent=2)
    print(f"\n✅ Champion config saved: {filepath}")
    return filepath


# =============================================================================
# OPTIMIZATION LOOP
# =============================================================================

def run_optimization(
    features: np.ndarray,
    outcomes: np.ndarray,
    metadata: dict,
    *,
    total_configs: int,
    batch_size: int | None,
    event_chunk: int,
    ram_fraction: float,
    vram_fraction: float,
    checkpoint_interval: int,
):
    # Move fixed data to backend once
    features_xp = xp.asarray(features, dtype=xp.float32)
    outcomes_xp = xp.asarray(outcomes, dtype=xp.float32)

    coeffs_xp, mfg_term_xp, outcomes_xp2, crl_mask_xp = precompute_event_matrices(
        features_xp, outcomes_xp, metadata, xp_backend=xp
    )

    param_names = list(PARAM_BOUNDS.keys())
    n_params = len(param_names)
    n_events = int(coeffs_xp.shape[0])

    # Auto-tune batch size if not provided
    if batch_size is None:
        batch_size = auto_tune_batch_size(
            n_params=n_params,
            n_events=n_events,
            event_chunk=event_chunk,
            ram_fraction=ram_fraction,
            vram_fraction=vram_fraction,
        )

    # Trackers
    best_brier = float("inf")
    best_params_cpu = None
    best_metrics = None
    top_configs: List[dict] = []

    configs_processed = 0
    start_time = time.time()
    next_checkpoint_at = checkpoint_interval

    print(f"\n{'='*70}")
    print("STARTING OPTIMIZATION (Auto RAM/VRAM tuned)")
    print(f"{'='*70}")
    print(f"GPU: {'ENABLED' if GPU_AVAILABLE else 'DISABLED (CPU)'}")
    if GPU_AVAILABLE:
        print(f"GPU Free VRAM: {get_free_gpu_bytes()/1e9:.2f} GB")
    print(f"Available RAM: {get_available_ram_bytes()/1e9:.2f} GB")
    print(f"Total configs: {total_configs:,}")
    print(f"Batch size: {batch_size:,}")
    print(f"Event chunk: {event_chunk}")
    print(f"Parameters: {n_params}")
    print(f"Events: {n_events}")
    print(f"{'='*70}\n")

    batch_idx = 0
    while configs_processed < total_configs:
        remaining = total_configs - configs_processed
        this_batch = int(min(batch_size, remaining))

        # Generate params directly on backend
        try:
            params_xp = generate_random_params(this_batch, xp_backend=xp)

            brier, tier4_crl, tier4_count, crl_recall = batch_score_blocked(
                params_xp,
                coeffs_xp,
                mfg_term_xp,
                outcomes_xp2,
                crl_mask_xp,
                base=0.867,
                event_chunk=event_chunk,
                xp_backend=xp,
            )

        except Exception as e:
            # Adaptive backoff on OOM / MemoryError
            msg = str(e).lower()
            is_oom = ("out of memory" in msg) or ("memoryerror" in msg) or ("alloc" in msg)
            if is_oom and this_batch > 50_000:
                new_bs = max(50_000, this_batch // 2)
                print(f"⚠️ OOM detected. Reducing batch_size {this_batch:,} -> {new_bs:,} and retrying...")
                batch_size = new_bs
                # free GPU pool if applicable
                if GPU_AVAILABLE:
                    try:
                        cp.get_default_memory_pool().free_all_blocks()
                        cp.get_default_pinned_memory_pool().free_all_blocks()
                    except Exception:
                        pass
                continue
            raise

        # Bring needed metrics to CPU
        if GPU_AVAILABLE:
            brier_cpu = brier.get()
            tier4_crl_cpu = tier4_crl.get()
            tier4_count_cpu = tier4_count.get()
            crl_recall_cpu = crl_recall.get()
            params_cpu = params_xp.get()
        else:
            brier_cpu = brier
            tier4_crl_cpu = tier4_crl
            tier4_count_cpu = tier4_count
            crl_recall_cpu = crl_recall
            params_cpu = params_xp

        # Feasibility constraints (same as original)
        feasible = (tier4_count_cpu >= 10) & (tier4_crl_cpu >= 0.70)
        feasible_idx = np.flatnonzero(feasible)

        if feasible_idx.size:
            # Choose best K from this batch by brier (not "first 100 indices")
            K = 50
            feas_brier = brier_cpu[feasible_idx]
            # argpartition gives unordered top-K; sort after
            k = min(K, feas_brier.size)
            topk_local = feasible_idx[np.argpartition(feas_brier, kth=k-1)[:k]]
            topk_local = topk_local[np.argsort(brier_cpu[topk_local])]

            # Update best config
            best_local = int(topk_local[0])
            if float(brier_cpu[best_local]) < best_brier:
                best_brier = float(brier_cpu[best_local])
                best_params_cpu = params_cpu[best_local].copy()
                best_metrics = {
                    "brier": best_brier,
                    "tier4_crl_rate": float(tier4_crl_cpu[best_local]),
                    "tier4_count": int(tier4_count_cpu[best_local]),
                    "crl_recall": float(crl_recall_cpu[best_local]),
                    "batch_idx": batch_idx,
                    "configs_processed": int(configs_processed + this_batch),
                    "configs_tested": int(configs_processed + this_batch),
                }

                print(f"\n🏆 NEW BEST @ {configs_processed + this_batch:,} configs")
                print(f"   Brier: {best_brier:.5f}")
                print(f"   TIER_4 CRL Rate: {best_metrics['tier4_crl_rate']*100:.1f}%")
                print(f"   TIER_4 Count: {best_metrics['tier4_count']}")
                print(f"   CRL Recall: {best_metrics['crl_recall']*100:.1f}%\n")

            # Maintain global top 10 list
            for idx in topk_local[:10]:
                cfg = {
                    "brier": float(brier_cpu[idx]),
                    "tier4_crl": float(tier4_crl_cpu[idx]),
                    "tier4_count": int(tier4_count_cpu[idx]),
                    "crl_recall": float(crl_recall_cpu[idx]),
                    "params": {name: float(params_cpu[idx, j]) for j, name in enumerate(param_names)},
                }
                top_configs.append(cfg)

            top_configs.sort(key=lambda x: x["brier"])
            top_configs = top_configs[:10]

        # Progress / timing
        configs_processed += this_batch
        batch_idx += 1

        elapsed = time.time() - start_time
        rate = configs_processed / max(1e-9, elapsed)
        eta = (total_configs - configs_processed) / max(1e-9, rate)

        if batch_idx % 5 == 0:
            print(
                f"Batch {batch_idx:5d} | "
                f"Processed {configs_processed:,}/{total_configs:,} | "
                f"{rate:,.0f} cfg/s | ETA {eta/60:.1f} min | "
                f"Feasible {feasible_idx.size:,}"
            )

        # Checkpoint (robust to variable batch size)
        if configs_processed >= next_checkpoint_at:
            if best_params_cpu is not None and best_metrics is not None:
                save_checkpoint(
                    "ODIN_v92_checkpoint.json",
                    batch_idx=batch_idx,
                    configs_processed=configs_processed,
                    best_metrics=best_metrics,
                    best_params=best_params_cpu.tolist(),
                )
            next_checkpoint_at += checkpoint_interval

    return best_params_cpu, best_metrics, top_configs


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help="Path to ODIN_ENRICHED_PDUFA_1349_v2.csv")
    parser.add_argument("--total-configs", type=int, default=DEFAULT_TOTAL_CONFIGS)
    parser.add_argument("--batch-size", type=int, default=None, help="Override auto-tuned batch size")
    parser.add_argument("--event-chunk", type=int, default=DEFAULT_EVENT_CHUNK)
    parser.add_argument("--ram-fraction", type=float, default=0.60)
    parser.add_argument("--vram-fraction", type=float, default=0.70)
    parser.add_argument("--checkpoint-interval", type=int, default=DEFAULT_CHECKPOINT_INTERVAL)
    args = parser.parse_args()

    print("=" * 70)
    print("ODIN v9.2 GPU OPTIMIZER (Auto RAM/VRAM tuned)")
    print("=" * 70)
    print(f"GPU: {'ENABLED' if GPU_AVAILABLE else 'DISABLED (CPU)'}")
    print("=" * 70)

    # Load data
    features, outcomes, metadata = load_and_prepare_data(args.data)

    # Run optimization
    best_params, best_metrics, top_configs = run_optimization(
        features,
        outcomes,
        metadata,
        total_configs=args.total_configs,
        batch_size=args.batch_size,
        event_chunk=args.event_chunk,
        ram_fraction=args.ram_fraction,
        vram_fraction=args.vram_fraction,
        checkpoint_interval=args.checkpoint_interval,
    )

    # Save results
    if best_params is not None and best_metrics is not None:
        save_champion_config(best_params, best_metrics)
        print("\n" + "=" * 70)
        print("OPTIMIZATION COMPLETE")
        print("=" * 70)
        print(f"\nBest Configuration:")
        print(f"  Brier Score: {best_metrics['brier']:.5f}")
        print(f"  TIER_4 CRL Rate: {best_metrics['tier4_crl_rate']*100:.1f}%")
        print(f"  TIER_4 Count: {best_metrics['tier4_count']}")
        print(f"  CRL Recall: {best_metrics['crl_recall']*100:.1f}%")

        print("\nTop 10 Configurations:")
        for i, cfg in enumerate(top_configs[:10], start=1):
            print(f"  #{i}: Brier={cfg['brier']:.5f}, T4_CRL={cfg['tier4_crl']*100:.1f}%, T4={cfg['tier4_count']}")
    else:
        print("\n⚠️ No feasible configurations found.")


if __name__ == "__main__":
    main()

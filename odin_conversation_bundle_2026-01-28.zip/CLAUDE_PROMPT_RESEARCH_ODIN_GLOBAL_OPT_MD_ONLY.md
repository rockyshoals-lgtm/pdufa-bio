You are Claude (RESEARCH AUTHORITY) reviewing ODIN’s engineering plan for a 10,000,000+ configuration global optimization sweep on the full PDUFA dataset.

IMPORTANT: Some original artifacts were JSON/CSV but have been wrapped in **.md** for upload compatibility.
In those wrapped files, the real data is inside fenced code blocks (```json or ```csv). Parse the code blocks.

INPUT FILES (attach all of these .md files):
1) ODIN_GPU_OPTUNA_GLOBAL_OPT_TASK_2026-01-20.md  (the proposed GPU/Optuna optimization plan)
2) ODIN_CHATGPT_OPTIMIZATION_HANDOFF.md          (dataset stats + patches + interactions)
3) odin_dataset_summary.md                       (dataset summary JSON inside ```json)
4) ODIN_ENRICHED_PDUFA_1349_v2.md                (full dataset CSV inside ```csv)
5) ODIN_v811_CHAMPION_CONFIG.md                  (current “best” config JSON inside ```json)
Optional (recommended):
6) ODIN_v88_UNIFIED_REALOPT_CONFIG.md            (optimized v8.8 config JSON inside ```json)
7) ODIN_v88_REALOPT_RUNLOG.md                    (run log JSON inside ```json)
8) CLAUDE_UPLOAD_BUNDLE_INDEX.md                 (bundle index)

YOUR ROLE
- You do NOT run the 10M sweep.
- You MUST critique, correct, and improve the plan so an engineer can execute it reliably, fast, and without leakage.
- Assume the engineer will implement exactly what you output.

NON‑NEGOTIABLE CONSTRAINTS
1) T−1 compliance: all features must be pre-catalyst, no outcome leakage.
2) Precision HARD FLOOR: ≥ 0.94 must be enforced.
3) Targets: MCC ≥ 0.50, Specificity ≥ 0.78, Brier ≤ 0.12.
4) Reproducible: seed control, deterministic config serialization, full audit logs.

TASKS
A) VALIDATION / BUG AUDIT (highest priority)
- Verify dataset label encoding in the plan:
  * what outcome values are present (APPROVED vs APPROVAL, etc.)
  * ensure y_true mapping is correct
- Verify column names referenced in the code exist in the dataset.
- Identify missing high-signal features from the plan that ARE present in the dataset:
  * form_483_issues
  * resubmission_class and prior_crl interactions (Class 1 override)
  * adcom_vote_pct threshold/slope
  * manufacturing_risk vs CMC reason if present
  * probability floor/ceiling
- Identify plan mistakes that make “10M trials in 30–60 min” unrealistic:
  * Optuna per-trial overhead
  * CPU<->GPU transfers (sklearn metrics inside objective)
  * kernel launch overhead per trial
  * pruner misuse (Hyperband with no resource)
Return a concise “Bug & Gap List” with:
- severity (BLOCKER / MAJOR / MINOR)
- exact fix

B) PERFORMANCE ENGINEERING REWRITE (must be implementable)
Propose a revised optimization approach that can realistically evaluate 10M+ configs:
Option 1: batched GPU vectorization (recommended)
- evaluate B configs per batch in a single GPU kernel launch (B=4096–65536)
- compute Brier + confusion-matrix metrics on GPU
- only transfer top-K configs back to CPU
Option 2: Optuna but with GPU-resident metric computation and minimal overhead
- use CuPy/Numba for metrics; avoid sklearn inside objective
Provide pseudocode for the recommended approach, including:
- data layout (features as contiguous float32/int8 arrays)
- parameter layout (matrix shape [B, P])
- scoring kernel signature that handles a batch of configs

C) OBJECTIVE + CONSTRAINT HANDLING (calibration-safe)
The current objective mixes:
- Brier (probabilistic)
- MCC and specificity (thresholded classification)
This can be unstable if threshold is fixed at 0.5.
Propose a better strategy:
- Either optimize Brier only, then choose threshold to satisfy precision/specificity
- Or for each config, choose the threshold that meets precision≥0.94 with maximum specificity, then compute MCC at that threshold
Explain the tradeoffs and recommend one.

D) TIME‑SPLIT / CV REQUIREMENTS (avoid overfit)
Provide a concrete temporal validation protocol:
- train/optimize/calibrate split (e.g., 2020–2023 train, 2024 optimize, 2025–2026 test)
- OR rolling walk-forward evaluation
You must state which metrics are computed on which split, and what is “champion selection” vs “final report”.

E) DELIVERABLES FOR ENGINEER (strict spec)
Return:
1) A revised “Engineering Runbook” (steps + commands)
2) A corrected feature list and scoring logic including:
   - P001 Class 1 override
   - Manufacturing risk penalties
   - AdCom vote effect if present
   - P003 low-designation risk
3) A minimal kernel pseudocode that includes ALL selected features
4) A config JSON schema for the champion and top-100 export
5) A leakage audit checklist and required logging fields

OUTPUT FORMAT (MANDATORY)
Return in this structure:

1. Bug & Gap List
2. Revised Optimization Architecture (recommended path + alternative)
3. Corrected Objective & Constraint Strategy
4. Temporal Validation Protocol
5. Engineer-Ready Spec
   5.1 Feature/Signal Table (name, column, transform, param knob)
   5.2 Kernel Pseudocode (batched)
   5.3 Metrics Computation (GPU)
   5.4 Output Artifacts (files + schemas)
   5.5 Leakage Audit Checklist

Be concise but complete. No filler. No speculation without marking it clearly.

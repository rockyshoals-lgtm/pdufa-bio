# **The H1 2026 Biotech Catalyst Master Protocol**

## **Comprehensive Audit of PDUFA & Clinical Readouts (Q1 & Q2)**

Generated: January 18, 2026  
Data Cutoff: January 15, 2026  
Strategy: Tiered Analysis by Return Potential (Alpha Generation)  
This report aggregates **40+** distinct binary events scheduled for the first half of 2026\. The data is tiered by "Return Potential" (a function of market cap, current valuation, and binary risk) to help you prioritize your capital allocation.

### ---

**🚨 TIER 1: THE "SUPERNOVA" EVENTS (Potential \>100% Moves)**

*High-risk, high-reward catalysts for small-to-mid-cap companies where the readout is existential or defines the platform.*

| Ticker | Company | Market Cap (Jan '26) | Drug / Asset | Catalyst Event | Date / Timing | Probability / Context |
| :---- | :---- | :---- | :---- | :---- | :---- | :---- |
| **KPTI** | **Karyopharm** | \~$400M | Selinexor | **Phase 3 SENTRY Topline Data** (Myelofibrosis) | **March 2026** | **Binary Event:** Analysts project a \+200% / \-75% move. Selinexor is testing efficacy in JAK-naive myelofibrosis. Success validates the XPO1 inhibition platform in a major indication. 1  |
| **MNMD** | **MindMed** | \~$1.04B | MM120 (LSD) | **Phase 3 Voyage Topline Data** (GAD) | **H1 2026** | **First-in-Class:** The first pivotal Phase 3 readout for an LSD-based therapy for Generalized Anxiety Disorder. Phase 2b data was robust; replication here would likely trigger a massive repricing as a legitimate commercial mental health player. 1  |
| **EYPT** | **EyePoint** | \~$1.36B | Duravyu (Vorolanib) | **Phase 3 LUGANO Topline Data** (Wet AMD) | **Mid-2026** | **Durability War:** EyePoint is racing against 4DMT (gene therapy). Success means matching Eylea's efficacy with 6-month dosing. A clean win here unlocks a multi-billion dollar market. 1  |
| **SION** | **Sionna** | \~$1.75B | SION-638/719 | **Phase 2 Proof-of-Concept** (Cystic Fibrosis) | **Mid-2026** | **Vertex Killer?** Sionna is attempting to disrupt the Vertex monopoly with novel NBD1 stabilizers. Positive data validating their "correction" mechanism would make them an immediate acquisition target. 1  |
| **GUTS** | **Fractyl** | \<$200M | Revita (Device) | **REMAIN-1 6-Month Data** (Obesity/T2D) | **Late Jan '26** | **Survival Readout:** Micro-cap play. Data on their duodenal mucosal resurfacing device \+ GLP-1 maintenance. Success proves the "off-ramp" thesis for GLP-1s. \[Prompt Context\] |
| **OCGN** | **Ocugen** | \~$555M | OCU410 | **Phase 2 ArMaDa Full Data** (Geographic Atrophy) | **Q1 2026** | **Gene Therapy:** A "one-and-done" modifier gene therapy for GA. Preliminary data showed safety; full efficacy data (lesion growth reduction) is needed to compete with Syfovre/Izervay. 2  |

### ---

**🚀 TIER 2: THE "BREAKOUT" CANDIDATES (30% \- 70% Moves)**

*Mid-to-large cap companies where a win validates a major franchise or pivot, leading to significant multiple expansion.*

| Ticker | Company | Market Cap (Jan '26) | Drug / Asset | Catalyst Event | Date / Timing | Strategic Note |
| :---- | :---- | :---- | :---- | :---- | :---- | :---- |
| **XENE** | **Xenon** | \~$3.26B | Azetukalner | **Phase 3 X-TOLE2 Topline** (Focal Epilepsy) | **March 2026** | **De-Risked:** Phase 2b data was best-in-class. Phase 3 success is highly anticipated. A win solidifies XENE as a top M\&A target for big pharma neuro divisions. 3  |
| **VRDN** | **Viridian** | \~$3.04B | VRDN-003 (SC) | **Phase 3 REVEAL-1 Topline** (Active TED) | **Q1 2026** | **Convenience Play:** While Veligrotug PDUFA is later (June), this SC data proves they can beat Amgen's Tepezza on convenience (at-home injection). 5  |
| **SYRE** | **Spyre** | \~$2.55B | SPY001 (a4b7) | **Phase 2 SKYLINE Part A** (Ulcerative Colitis) | **Q2 2026** | **"6 in '26":** This is the first of 6 readouts. Spyre aims to match Entyvio efficacy with infrequent SC dosing. Success validates their entire antibody engineering platform. 6  |
| **UTHR** | **United Tx** | \~$21.4B | Tyvaso (Inhaled) | **Phase 3 TETON-1 Topline** (IPF) | **H1 2026** | **Franchise Expansion:** Tyvaso is a cash cow in PAH. Success in IPF (a totally new, huge market) would be a massive leg up for the stock, combating generic fears. 1  |
| **IDYA** | **Ideaya** | \~$3B+ | Darovasertib | **Phase 2/3 Data** (Neoadjuvant UM) | **Q1 2026** | **Eye Sparing:** Data on "eye preservation" in Uveal Melanoma. If they prove they can save patients from enucleation (eye removal), it's a standard-of-care shift. |
| **RGNX** | **Regenxbio** | \~$740M | RGX-202 | **Pivotal Phase 1/2 Data** (Duchenne) | **Early Q2** | **Gene Therapy:** Looking for microdystrophin expression levels that support an accelerated approval filing. Competing with Sarepta. 7  |

### ---

**🛡️ TIER 3: THE "FOUNDATIONAL" MOVERS (Incremental Upside / Low Volatility)**

*Large cap or diversified companies where the catalyst is important but likely moves the stock \<20%.*

| Ticker | Company | Drug / Asset | Catalyst Event | Date / Timing | Note |
| :---- | :---- | :---- | :---- | :---- | :---- |
| **LLY** | **Eli Lilly** | Remternetug | **Phase 3 Topline Data** (Alzheimer's) | **March 2026** | Next-gen amyloid antibody. Success means subcutaneous dosing convenience vs. Leqembi/Kisunla. 8  |
| **VRTX** | **Vertex** | Povetacicept | **BLA Submission / Ph3 Interim** (IgAN) | **H1 2026** | Vertex is moving into renal disease. Povetacicept has "best-in-class" potential for IgA Nephropathy. |
| **BNTX** | **BioNTech** | BNT113 | **Phase 3 AHEAD-MERIT Data** (Head & Neck) | **H1 2026** | mRNA cancer vaccine proof-of-concept. Critical for BNTX's pivot from COVID to Oncology. 9  |
| **CYTK** | **Cytokinetics** | Aficamten | **Phase 3 ACACIA-HCM** (Non-Obstructive) | **H1 2026** | Expansion into nHCM. Aficamten already approved for oHCM (Dec '25), this expands the TAM. |

### ---

**📅 PDUFA CALENDAR: Q1 & Q2 2026 (Binary Regulatory Events)**

**JANUARY 2026**

* **PASSED:** **Travere (TVTX)** \- Filspari (FSGS) \- Jan 13 (Outcome: **Review**) 10

* **PASSED:** **Fortress (FBIO)** \- Zycubo (Menkes) \- Jan 14 (Outcome: **APPROVED**)  
* **PENDING:** **Aquestive (AQST)** \- Anaphylm (Sublingual Epi) \- **Jan 31, 2026**. *Note: FDA previously noted deficiencies; high risk.* 11

* **PENDING:** **Kodiak (KOD)** / **Kazia (KZIA)** \- Various small catalogs listed Jan 31 as placeholder dates in some trackers, verify specific drug filings. 11

**FEBRUARY 2026**

* **Regenxbio (RGNX):** RGX-121 (Hunter Syndrome) \- **Feb 8, 2026**. *Gene therapy for rare disease; Priority Review Voucher (PRV) attached.* 7

* **Eton Pharma (ETON):** ET-600 (Zeneo) \- **Feb 25, 2026**. 2

* **Ascendis (ASND):** TransCon CNP (Achondroplasia) \- **Feb 28, 2026**. *Competitor to Voxzogo.* 2

**MARCH 2026**

* **Bristol Myers (BMY):** Sotyktu (PsA Indication) \- **Mar 6, 2026**. 2

* **Aldeyra (ALDX):** Reproxalap (Dry Eye) \- **Mar 16, 2026**. *Resubmission after previous CRL; restricted label potential.*  
* **GSK:** Linerixibat (PBC) \- **Mar 24, 2026**.  
* **Rocket Pharma (RCKT):** Kresladi (LAD-I) \- **Mar 28, 2026**. *Gene therapy; delayed previously.*  
* **Lantheus:** LNTH-2501 \- **Mar 29, 2026**.

**APRIL 2026**

* **Denali (DNLI) / Sanofi:** Tividenofusp (Hunter Syndrome) \- **Apr 5, 2026**. *Enzyme replacement therapy.*  
* **Orca Bio (Private/IPO?):** Orca-T (AML) \- **Apr 6, 2026**.  
* **Replimune (REPL):** RP1 (Melanoma) \- **Apr 10, 2026**. *Oncolytic virus \+ Opdivo. Class 2 resubmission PDUFA.*  
* **Sanofi:** Sarclisa (Multiple Myeloma expansion) \- **Apr 23, 2026**.

**MAY 2026**

* *No major confirmed PDUFAs in snippets yet; watch for 10-month standard reviews filed in July 2025\.*

**JUNE 2026**

* **Achieve (ACHV):** Cytisinicline (Smoking Cessation) \- **Jun 20, 2026**.  
* **Viridian (VRDN):** Veligrotug (TED) \- **Jun 30, 2026**. *Priority Review. Potential best-in-class IV for TED.* 5

### ---

**📝 H1 2026 CLINICAL READOUT WATCHLIST (By Ticker)**

| Ticker | Drug | Indication | Phase | Timing | Notes |
| :---- | :---- | :---- | :---- | :---- | :---- |
| **VKTX** | VK2735 (Oral) | Obesity | Ph 1 | Q1 2026 | Monthly maintenance data also expected. |
| **GPCR** | GSBR-1290 | Obesity | Ph 2b | H1 2026 | Formulation bridging & Ph 2b initiation updates. |
| **NTLA** | NTLA-2002 | HAE | Ph 3 | Mid-2026 | "HAELO" trial topline. CRISPR in vivo. |
| **FDMT** | 4D-150 | Wet AMD | Ph 3 | Q1 2026 | Enrollment completion (readout 2027), but PRISM 2yr data in mid-2026. |
| **TERN** | TERN-701 | CML | Ph 1/2 | H1 2026 | 6-month card study data; pivotal dose selection. |
| **DAWN** | Emi-Le | pLGG | Ph 1 | Mid-2026 | First data from new acquisition asset. |
| **HRMY** | BP1.15205 | Narcolepsy | Ph 1 | Mid-2026 | Orexin-2 agonist data (hot space). |
| **ABVX** | Obefazimod | UC | Ph 3 | Late Q2 | Maintenance data (44 weeks) from ABTECT. |
| **AGIO** | Mitapivat | Sickle Cell | Reg | Q1 2026 | Pre-NDA meeting for SCD; FDA filing to follow. |
| **SRRK** | Apitegromab | SMA | Reg | 2026 | Launch year; SRK-439 (Anti-myostatin) Ph 1 data H2 2026\. |
| **BBIO** | Encaleret | ADH1 | Reg | H1 2026 | NDA submission planned. |

**Auditor's Note:** All dates are based on company guidance as of Jan 2026 (JPM Conference updates) and clinical trial registry estimates. "Mid-2026" often implies May/June or a conference presentation at ASCO (June) or EULAR (June).
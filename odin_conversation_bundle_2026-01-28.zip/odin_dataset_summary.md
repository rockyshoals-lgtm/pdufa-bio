# ODIN Dataset Summary (JSON wrapped for Claude upload)

Markdown wrapper around the dataset summary JSON. The JSON is intact inside the code block.

```json
{
  "dataset_stats": {
    "total_events": 1349,
    "approvals": 1169,
    "crls": 5,
    "base_approval_rate": 86.66,
    "date_range": {
      "start": "2020-01-08",
      "end": "2026-01-14"
    }
  },
  "year_breakdown": {
    "2020": {
      "total": 190,
      "approvals": 160,
      "crls": 30,
      "approval_rate": 84.21
    },
    "2021": {
      "total": 219,
      "approvals": 188,
      "crls": 31,
      "approval_rate": 85.84
    },
    "2022": {
      "total": 176,
      "approvals": 149,
      "crls": 27,
      "approval_rate": 84.66
    },
    "2023": {
      "total": 258,
      "approvals": 217,
      "crls": 41,
      "approval_rate": 84.11
    },
    "2024": {
      "total": 276,
      "approvals": 249,
      "crls": 27,
      "approval_rate": 90.22
    },
    "2025": {
      "total": 227,
      "approvals": 204,
      "crls": 23,
      "approval_rate": 89.87
    },
    "2026": {
      "total": 3,
      "approvals": 2,
      "crls": 1,
      "approval_rate": 66.67
    }
  },
  "therapeutic_area_stats": [
    {
      "therapeutic_area": "Oncology",
      "total": 400,
      "approvals": 371,
      "crls": 29,
      "approval_rate": 92.75
    },
    {
      "therapeutic_area": "Other",
      "total": 315,
      "approvals": 267,
      "crls": 48,
      "approval_rate": 84.76190476190476
    },
    {
      "therapeutic_area": "Infectious Disease",
      "total": 132,
      "approvals": 128,
      "crls": 4,
      "approval_rate": 96.96969696969697
    },
    {
      "therapeutic_area": "CNS/Neurology",
      "total": 95,
      "approvals": 73,
      "crls": 22,
      "approval_rate": 76.84210526315789
    },
    {
      "therapeutic_area": "Immunology",
      "total": 85,
      "approvals": 75,
      "crls": 10,
      "approval_rate": 88.23529411764706
    },
    {
      "therapeutic_area": "Rare Disease",
      "total": 68,
      "approvals": 56,
      "crls": 12,
      "approval_rate": 82.35294117647058
    },
    {
      "therapeutic_area": "Cardiovascular",
      "total": 42,
      "approvals": 33,
      "crls": 9,
      "approval_rate": 78.57142857142857
    },
    {
      "therapeutic_area": "Ophthalmology",
      "total": 34,
      "approvals": 25,
      "crls": 9,
      "approval_rate": 73.52941176470588
    },
    {
      "therapeutic_area": "Pain Management",
      "total": 31,
      "approvals": 18,
      "crls": 13,
      "approval_rate": 58.06451612903226
    },
    {
      "therapeutic_area": "Metabolic/Endocrine",
      "total": 30,
      "approvals": 24,
      "crls": 6,
      "approval_rate": 80.0
    },
    {
      "therapeutic_area": "Nephrology",
      "total": 29,
      "approvals": 20,
      "crls": 9,
      "approval_rate": 68.96551724137932
    },
    {
      "therapeutic_area": "Respiratory",
      "total": 23,
      "approvals": 22,
      "crls": 1,
      "approval_rate": 95.65217391304348
    },
    {
      "therapeutic_area": "Dermatology",
      "total": 19,
      "approvals": 17,
      "crls": 2,
      "approval_rate": 89.47368421052632
    },
    {
      "therapeutic_area": "GI/Hepatology",
      "total": 15,
      "approvals": 14,
      "crls": 1,
      "approval_rate": 93.33333333333333
    },
    {
      "therapeutic_area": "Hematology",
      "total": 14,
      "approvals": 9,
      "crls": 5,
      "approval_rate": 64.28571428571429
    },
    {
      "therapeutic_area": "Vaccines",
      "total": 10,
      "approvals": 10,
      "crls": 0,
      "approval_rate": 100.0
    },
    {
      "therapeutic_area": "Women's Health",
      "total": 7,
      "approvals": 7,
      "crls": 0,
      "approval_rate": 100.0
    }
  ],
  "designation_impact": {
    "btd": {
      "with_count": 243,
      "with_approval_rate": 95.06,
      "without_count": 1106,
      "without_approval_rate": 84.81,
      "delta": 10.25
    },
    "orphan": {
      "with_count": 330,
      "with_approval_rate": 89.09,
      "without_count": 1019,
      "without_approval_rate": 85.87,
      "delta": 3.22
    },
    "priority_review": {
      "with_count": 617,
      "with_approval_rate": 90.44,
      "without_count": 732,
      "without_approval_rate": 83.47,
      "delta": 6.97
    },
    "fast_track": {
      "with_count": 484,
      "with_approval_rate": 90.91,
      "without_count": 865,
      "without_approval_rate": 84.28,
      "delta": 6.63
    }
  },
  "modality_stats": [
    {
      "modality": "Small Molecule",
      "total": 822,
      "approvals": 698,
      "approval_rate": 84.91484184914842
    },
    {
      "modality": "Antibody",
      "total": 386,
      "approvals": 340,
      "approval_rate": 88.08290155440415
    },
    {
      "modality": "Cell/Gene Therapy",
      "total": 57,
      "approvals": 53,
      "approval_rate": 92.98245614035088
    },
    {
      "modality": "RNA Therapy",
      "total": 41,
      "approvals": 38,
      "approval_rate": 92.6829268292683
    },
    {
      "modality": "Peptide",
      "total": 25,
      "approvals": 22,
      "approval_rate": 88.0
    },
    {
      "modality": "Vaccine",
      "total": 16,
      "approvals": 16,
      "approval_rate": 100.0
    },
    {
      "modality": "ADC",
      "total": 2,
      "approvals": 2,
      "approval_rate": 100.0
    }
  ],
  "key_interactions": []
}
```

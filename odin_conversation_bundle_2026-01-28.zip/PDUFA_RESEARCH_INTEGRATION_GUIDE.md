# PDUFA RESEARCH INTEGRATION GUIDE
## How to Submit the Research Prompt & Integrate AI Outputs
### January 18, 2026

---

## STEP-BY-STEP DEPLOYMENT GUIDE

### **STEP 1: PREPARATION (Today – Jan 18)**

**1a. Copy the Full Research Prompt**
- File: `PDUFA_LEAPFROG_RESEARCH_PROMPT.md` (567 lines)
- This is your comprehensive research brief
- Contains all 10 hypotheses, data requests, and validation questions

**1b. Prepare Your Three AI Environments**
- Claude: Open new chat window
- ChatGPT: Open new chat window (or use with API if preferred)
- Gemini: Open new chat window

**1c. Have These Documents Ready for Reference**
- `PDUFA_LEAPFROG_QUICK_START.md` (your trading playbook)
- `UPDATED_50K_INVESTMENT_THESIS.md` (current portfolio context)
- Historical PDUFA data (you'll need to provide or they'll source):
  - RCKT March 28, 2026 PDUFA
  - DNLI April 5, 2026 PDUFA
  - VALN Q1 2026 Phase 3 (BLA path)
  - 8–10 historical PDUFAs from 2023–2025

---

## STEP 2: SUBMIT TO CLAUDE (Quantitative AI)

**2a. Initial Prompt**
```
I'm researching pre-PDUFA trading patterns in biotech. I want to understand 
when stocks typically run ahead of PDUFA announcements, what signals predict 
these runs, and how to time entry/exit.

Below is a comprehensive research brief with 10 hypotheses, historical data 
requests, and specific modeling questions. I need you to focus on:

1. Quantitative signal modeling (logistic regression, classification)
2. Optimal entry/exit timing calculations
3. Leapfrog return projections
4. Back-testing framework

Please proceed with the research brief below:
```

**2b. Paste Full Research Prompt**
- Copy entire PDUFA_LEAPFROG_RESEARCH_PROMPT.md
- Paste into Claude conversation

**2c. Follow-Up Questions for Claude**
After Claude completes initial analysis, ask:

1. "Can you build a logistic regression model where the outcome is P(PDUFA approval) 
   and the variables are: volume surge, IV collapse, analyst upgrades, insider buying, 
   days to PDUFA? What are the model coefficients?"

2. "Given the coefficients, can you score RCKT and DNLI (for March 28 and April 5 PDUFAs 
   respectively) using current market data? What is P(approval) for each?"

3. "For historical PDUFAs, what was the average stock move from 'entry signal' 
   (volume surge + IV collapse) to 'PDUFA announcement'? Quantify by sector (rare disease vs oncology)."

4. "Can you model a 6-month leapfrog sequence (RCKT → DNLI → VALN → KPTI) 
   with realistic return assumptions? Expected portfolio value after 4 leapfrogs?"

5. "What position sizing would you recommend to capture 70%+ of leapfrog upside 
   while capping maximum drawdown to -20%?"

**2d. Expected Output from Claude**
- ✅ Signal definitions with quantitative thresholds
- ✅ Logistic regression model (or similar probability model)
- ✅ Historical return analysis (average moves by sector)
- ✅ Leapfrog return projection model
- ✅ Position sizing framework
- ✅ Risk management recommendations

**2e. Approximate Duration**
- Initial response: 30–45 minutes
- Follow-up analysis: 30–60 minutes each
- **Total time: 2–3 hours**

---

## STEP 3: SUBMIT TO CHATGPT (Narrative & Historical AI)

**3a. Initial Prompt**
```
I'm researching pre-PDUFA trading patterns. I want detailed case studies of 
historical PDUFAs (2023–2025) showing:
- What stock price was before, during, and after the run
- What signals appeared (volume, analyst coverage, insider trading, PR activity)
- Whether the company got approved or CRL
- Lessons learned for future PDUFAs

Please proceed with this comprehensive research brief:
```

**3b. Paste Full Research Prompt**

**3c. Follow-Up Questions for ChatGPT**
After initial analysis:

1. "Select the 8 best-documented PDUFA cases from 2023–2025 and provide narrative 
   case studies for each. For each case, include: stock price timeline, signals that appeared, 
   outcome (approval vs CRL), and key takeaway."

2. "What are the 5–7 COMMON signals that appeared across all approvals? 
   What signals appeared in CRL cases but NOT in approval cases?"

3. "For first-in-class drugs, how did the pre-PDUFA run differ from follow-on drugs? 
   Rare disease vs oncology?"

4. "What were the false positives? Cases where signals suggested approval but CRL occurred. 
   What warning signs were missed?"

5. "Build a decision tree: Given signals X, Y, Z present, what is your confidence 
   in approval? How would you score confidence level 0–100?"

**3d. Expected Output from ChatGPT**
- ✅ 8–12 detailed case studies with stock moves
- ✅ Pattern analysis (common vs different)
- ✅ Sector-specific insights
- ✅ False positive analysis & risk factors
- ✅ Decision framework / confidence scoring

**3e. Approximate Duration**
- Initial response: 45–60 minutes (case studies are detailed)
- Follow-up analysis: 30–45 minutes each
- **Total time: 2–3 hours**

---

## STEP 4: SUBMIT TO GEMINI (Real-Time Scanning & Integration AI)

**4a. Initial Prompt**
```
I'm researching pre-PDUFA trading patterns and want to identify current opportunities 
in the biotech sector. I need you to:

1. Scan the current PDUFA pipeline (next 6 months)
2. Score each PDUFA by signal strength (volume, IV, analyst, insider, competitor moves)
3. Identify optimal leapfrog sequences
4. Provide real-time implementation recommendations

Please proceed with this comprehensive research brief:
```

**4b. Paste Full Research Prompt**

**4c. Follow-Up Questions for Gemini**
After initial analysis:

1. "Scan the biotech sector for ALL PDUFAs in the next 6 months (Jan–Jun 2026). 
   For each, provide: company, drug, indication, PDUFA date, current stock price, 
   market cap, and preliminary signal assessment."

2. "Score the top 10 PDUFAs using a 0–100 composite signal score. 
   Include component scores for: volume trend, IV level, analyst coverage, 
   insider activity, competitor relative strength, and days to PDUFA."

3. "Identify the optimal leapfrog sequence. Which PDUFAs have the best 
   entry signal timing, and which should we exit before their PDUFA? 
   Build a 6-month sequence (X → Y → Z → W)."

4. "For RCKT (March 28) and DNLI (April 5), what is the current signal status 
   TODAY (Jan 18)? Are they showing entry signals yet, or should we wait?"

5. "Build a weekly monitoring template: What metrics should I track daily/weekly 
   for each active PDUFA position? (Volume, IV, analyst coverage, insider activity, 
   competitor moves, stock price momentum)"

**4d. Expected Output from Gemini**
- ✅ Current PDUFA pipeline scan (top 10–15 names)
- ✅ Signal strength scoring (0–100 for each)
- ✅ Leapfrog sequence recommendations
- ✅ Current opportunity assessment (RCKT, DNLI, VALN)
- ✅ Weekly monitoring dashboard template

**4e. Approximate Duration**
- Initial response: 30–45 minutes
- Follow-up analysis: 20–30 minutes each
- **Total time: 1.5–2 hours**

---

## STEP 5: INTEGRATE AI OUTPUTS (1–2 hours)

### **5a. Consolidate Outputs into Master Playbook**

Create new document: `PDUFA_LEAPFROG_PLAYBOOK_FINAL.md`

**Section 1: Historical Foundation (from ChatGPT)**
- 8–12 case studies
- Pattern analysis
- False positive identification
- Sector-specific insights

**Section 2: Quantitative Framework (from Claude)**
- Signal definitions & metrics
- Logistic regression model
- Return projections
- Position sizing

**Section 3: Real-Time Implementation (from Gemini)**
- Current PDUFA ranking
- Leapfrog sequence
- Weekly monitoring dashboard
- Entry/exit signals for RCKT/DNLI/VALN

**Section 4: Integrated Playbook (All Three)**
- Decision tree: When to enter each PDUFA
- Risk management: Position sizing + stop-losses
- Profit targets: When to exit
- Leapfrog mechanics: How to sequence trades

### **5b. Cross-Validate Outputs**

**Check Claude vs ChatGPT alignment**:
- Do historical return estimates (ChatGPT) match model projections (Claude)?
- Are signal definitions consistent across both?
- Any discrepancies? (Likely not; both should converge)

**Check Gemini vs Claude/ChatGPT alignment**:
- Does Gemini's current PDUFA scoring match Claude's model?
- Do Gemini's leapfrog sequence recommendations match historical patterns (ChatGPT)?
- Any conflicts? (Resolve by asking AI to explain)

### **5c. Build Decision Framework**

Create simple decision tree:
```
DAY 0: Is PDUFA >30 days away?
├─ YES: Wait for signals; monitor daily
└─ NO: Skip this PDUFA

Days to PDUFA: 28–21?
├─ Volume >2.5x average? → ENTER 50% position
├─ Analyst upgrade? → ENTER 50% position
└─ Neither? → WAIT

Days to PDUFA: 21–14?
├─ IV collapsed >25%? → ENTER remaining 50%
├─ Insider buying visible? → ENTER remaining 50%
└─ Neither? → HOLD and watch

Days to PDUFA: 14–2?
├─ Stock momentum positive? → HOLD; monitor
├─ Red flag signals? → EXIT early
└─ Stock flattening? → Consider partial exit

Days to PDUFA: 2–0?
├─ EXIT 100% of position 1–2 days before
└─ NEVER hold through announcement
```

---

## STEP 6: APPLY TO YOUR $50K PORTFOLIO

### **6a. Current PDUFA Schedule**

From your revised $50K strategy:
- **RCKT**: March 28, 2026 (70 days away, Jan 18 baseline)
- **DNLI**: April 5, 2026 (78 days away, Jan 18 baseline)
- **VALN**: Q1 2026 Phase 3 data (45–60 days away)

### **6b. Immediate Actions (Based on AI Research)**

**For RCKT (March 28)**:
- [ ] Run Gemini scan: What are current signals (Jan 18)?
- [ ] If signals present: Build position over 3–5 days (target $9K allocation)
- [ ] If no signals: Wait until late Jan / early Feb for entry window
- [ ] Set calendar alert for Feb 24–26 (exit window: 2 days before PDUFA)

**For DNLI (April 5)**:
- [ ] Similar process; stagger entry 7–10 days after RCKT
- [ ] Allows sequential leapfrog (exit RCKT, re-deploy to DNLI)

**For VALN (Q1 Phase 3)**:
- [ ] Phase 3 data is earlier (not PDUFA); different timeline
- [ ] Use similar signal monitoring but shorter entry window

### **6c. Build Monitoring Dashboard**

Use Gemini template to create weekly tracking:
```
Week of [DATE]:

RCKT (PDUFA Mar 28, [X days away]):
- Volume (7-day avg vs 30-day avg): _____ x multiplier
- IV: _____ (vs 90-day range)
- Analyst changes (upgrades – downgrades): _____ 
- Insider activity (Form 4 filings): _____ 
- Stock price: _____ (vs prior week)
- Momentum: [Up/Flat/Down]
- Signal score (0–100): _____
- Recommendation: [WAIT / ENTER / HOLD / EXIT]

DNLI (PDUFA Apr 5, [X days away]):
[Same template]

VALN (Phase 3 Data, [X days away]):
[Same template]
```

---

## STEP 7: ITERATE & REFINE (Ongoing)

### **Weekly Updates**
- Every Sunday: Run Gemini scan on current PDUFA pipeline
- Update signal scores for active positions
- Adjust leapfrog sequence if needed (new PDUFAs emerging, others delayed)

### **Monthly Integration**
- Every month: Compile learnings from completed PDUFAs
- Refine Claude's model with new data
- Update ChatGPT's historical database with new outcomes
- Adjust signal thresholds based on accuracy

### **Quarterly Validation**
- Every quarter: Back-test the full leapfrog sequence
- Calculate actual returns vs projected
- Identify what worked, what didn't
- Refine for next quarter's PDUFAs

---

## TIMELINE FOR FULL RESEARCH CYCLE

| Timing | Action | Owner | Duration |
|--------|--------|-------|----------|
| **Jan 18** | Submit prompts to Claude, ChatGPT, Gemini | You | 30 min |
| **Jan 18–20** | Claude completes quantitative analysis | Claude | 2–3 hrs |
| **Jan 18–20** | ChatGPT completes historical case studies | ChatGPT | 2–3 hrs |
| **Jan 18–20** | Gemini completes real-time scanning | Gemini | 1.5–2 hrs |
| **Jan 21–22** | You integrate outputs into master playbook | You | 2–3 hrs |
| **Jan 23–24** | Cross-validate & build decision tree | You | 1–2 hrs |
| **Jan 25** | Apply to RCKT/DNLI/VALN; set alerts | You | 1 hr |
| **Feb 3 onwards** | Execute PDUFA leapfrog strategy | You | Ongoing |

**Total time investment**: ~15–20 hours over 2 weeks (mostly AI-generated)

---

## EXPECTED RESEARCH QUALITY

**By the end of this research cycle, you'll have:**

✅ **8–12 audited historical case studies** (with stock prices, outcomes, signal timelines)  
✅ **Quantitative signal model** (logistic regression with coefficients)  
✅ **Optimal entry/exit windows** (specific day ranges: "21–26 days before PDUFA")  
✅ **Return projection models** (average moves by sector/indication)  
✅ **Leapfrog playbook** (how to chain 4–5 PDUFAs for +100%+ returns)  
✅ **Real-time opportunity ranking** (top 5 PDUFAs by signal strength)  
✅ **Weekly monitoring dashboard** (template + current data)  
✅ **Decision tree** (when to enter, hold, exit)  
✅ **Risk management framework** (position sizing, stops, drawdown limits)  

---

## SUCCESS CRITERIA

This research is successful if:

- ✅ You can identify current PDUFA entry signals within ±3 days
- ✅ You can project expected returns from entry → exit within ±15%
- ✅ You can model 6-month leapfrog returns with 70%+ confidence
- ✅ You have repeatable decision framework for future PDUFAs
- ✅ You execute first leapfrog (RCKT) by Feb 3
- ✅ You achieve +50% return on first leapfrog sequence by end Q1

---

## NEXT STEPS

1. **Right now**: Copy PDUFA_LEAPFROG_RESEARCH_PROMPT.md
2. **Today/Tomorrow**: Submit to Claude, ChatGPT, Gemini (separate conversations)
3. **Jan 20–22**: Collect AI outputs
4. **Jan 22–24**: Integrate into master playbook
5. **Jan 25**: Start monitoring RCKT/DNLI signals
6. **Feb 3 onwards**: Execute leapfrog sequence

---

**Prepared**: January 18, 2026, 6:36 AM PST  
**Status**: Ready to Deploy  
**Expected Completion**: January 25, 2026 (Playbook finalized; ready for execution)

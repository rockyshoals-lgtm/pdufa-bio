# ODIN v8.11 Champion Config (JSON wrapped for Claude upload)

This file is a markdown wrapper around the original `.json` so it can be uploaded to Claude. The JSON is intact inside the code block.

```json
{
  "version": "8.11",
  "version_date": "2026-01-20",
  "status": "CHAMPION_CANDIDATE",
  "parent_version": "8.6",
  "changes_from_parent": [
    "P001: CLASS_1_CMC_OVERRIDE",
    "P002: CLUSTER_SELL_OVERRIDE", 
    "P003: LOW_DESIGNATION_CLINICAL_RISK",
    "S16: PUBLICATION_COUNT_SIGNAL"
  ],
  
  "baseline_metrics": {
    "source": "v8.6_champion",
    "dataset": "ODIN_ENRICHED_PDUFA_1349_v2",
    "n_events": 1349,
    "n_approvals": 1169,
    "n_crls": 180,
    "base_approval_rate": 0.867,
    "mcc": 0.456,
    "precision": 0.9502,
    "recall": 0.8494,
    "specificity": 0.7111,
    "brier_score": 0.1761
  },
  
  "target_metrics": {
    "mcc": ">=0.50",
    "precision": ">=0.94 (HARD_FLOOR)",
    "recall": ">=0.82",
    "specificity": ">=0.78",
    "brier_score": "<=0.12"
  },
  
  "pdufa_logic": {
    "base_prior": 0.867,
    
    "designation_weights": {
      "btd": {
        "weight": 0.103,
        "evidence": "243 events, 95.1% vs 84.8% without, delta +10.3%"
      },
      "orphan": {
        "weight": 0.032,
        "evidence": "330 events, 89.1% vs 85.9% without, delta +3.2%"
      },
      "priority_review": {
        "weight": 0.070,
        "evidence": "617 events, 90.4% vs 83.5% without, delta +7.0%"
      },
      "fast_track": {
        "weight": 0.066,
        "evidence": "484 events, 90.9% vs 84.3% without, delta +6.6%"
      }
    },
    
    "designation_stack_weights": {
      "0": -0.037,
      "1": -0.028,
      "2": 0.053,
      "3": -0.013,
      "4": 0.050,
      "5": 0.133,
      "evidence": "Stack 5 = 100% approval (n=45), Stack 0 = 83.1% (n=586)"
    },
    
    "sponsor_experience": {
      "experienced_bonus": 0.057,
      "inexperienced_penalty": -0.057,
      "evidence": "Exp: 92.4% (n=671) vs Inexp: 81.0% (n=678), delta +11.4%"
    },
    
    "manufacturing_risk": {
      "with_risk_penalty": -0.346,
      "no_risk_bonus": 0.092,
      "evidence": "MfgRisk: 52.3% (n=285) vs NoRisk: 95.9% (n=1064), delta -43.6%",
      "critical_note": "MOST_PREDICTIVE_SINGLE_FEATURE"
    },
    
    "therapeutic_area_adjustments": {
      "Oncology": 0.060,
      "Infectious Disease": 0.103,
      "CNS/Neurology": -0.098,
      "Immunology": 0.015,
      "Rare Disease": -0.045,
      "Cardiovascular": -0.084,
      "Ophthalmology": -0.133,
      "Pain Management": -0.286,
      "Metabolic/Endocrine": -0.067,
      "Nephrology": -0.177,
      "Respiratory": 0.090,
      "Dermatology": 0.026,
      "GI/Hepatology": 0.067,
      "Hematology": -0.224,
      "Vaccines": 0.133,
      "Women's Health": 0.133
    },
    
    "modality_adjustments": {
      "Small Molecule": -0.018,
      "Antibody": 0.014,
      "Cell/Gene Therapy": 0.063,
      "RNA Therapy": 0.060,
      "Peptide": 0.013,
      "Vaccine": 0.133,
      "ADC": 0.133
    },
    
    "adcom_signal": {
      "had_adcom_bonus": 0.138,
      "vote_gte_80_bonus": 0.05,
      "evidence": "Had AdCom: 100% approval (n=49)"
    }
  },
  
  "patches": {
    "P001_CLASS_1_CMC_OVERRIDE": {
      "version": "1.0",
      "status": "VALIDATED",
      "condition": "(prior_crl=True) AND (resubmission_class=1) AND (prior_crl_reason CONTAINS 'CMC')",
      "action": "SET poa_floor = 0.95",
      "evidence": {
        "historical_rate": "99.5% approval for Class 1 CMC resubmissions",
        "validation_case": "FBIO CUTX-101 approved 2026-01-14",
        "false_negative_prevented": true
      },
      "expected_impact": {
        "tp_gain": 5,
        "fn_reduction": 5,
        "fp_change": 0
      }
    },
    
    "P002_CLUSTER_SELL_OVERRIDE": {
      "version": "1.0",
      "status": "VALIDATED",
      "condition": "(cluster_sell_detected=True) AND (ceo_participated=True)",
      "action": "max_penalty = -0.25, override_bullish_options = True",
      "evidence": {
        "AQST": {
          "cluster_sell_date": "2025-10-15",
          "participants": "CEO+COO+CMO",
          "amount": "$686K same day",
          "outcome": "Deficiency 2026-01-09",
          "lead_time_days": 86
        },
        "TVTX": {
          "pattern": "18 sells / 0 buys",
          "pcr_ratio": 37.59,
          "outcome": "3-month delay announced"
        },
        "CORT": {
          "ceo_sale": "$3.2M",
          "timing": "6 days before CRL",
          "outcome": "CRL"
        }
      },
      "expected_impact": {
        "tn_gain": 3,
        "specificity_improvement": 0.02
      }
    },
    
    "P003_LOW_DESIGNATION_CLINICAL_RISK": {
      "version": "1.0",
      "status": "VALIDATED",
      "condition": "(experienced_sponsor=True) AND (manufacturing_risk=False) AND (btd=False) AND (designation_stack_count<=1)",
      "action": "penalty = -0.10",
      "evidence": {
        "fp_analysis": "90.4% of FPs are experienced sponsors",
        "crl_reason_analysis": "82.7% of FP CRLs are CLINICAL (not CMC)",
        "pattern": "Experienced + No MfgRisk + No BTD + Low Stack = Clinical uncertainty zone"
      },
      "expected_impact": {
        "tn_gain": 22,
        "fp_reduction": 22,
        "specificity_improvement": 0.12
      }
    },
    
    "S16_PUBLICATION_COUNT": {
      "version": "1.0",
      "status": "VALIDATED",
      "scoring_function": {
        "description": "PubMed publication count signal",
        "logic": [
          "IF is_resubmission: return 0 (P001 takes precedence)",
          "IF is_orphan: effective_count = pub_count * 2.5",
          "IF is_first_in_class AND effective_count >= 15: effective_count *= 1.3",
          "IF effective_count >= 100: return +0.10",
          "IF effective_count >= 50: return +0.05",
          "IF effective_count >= 15: return 0",
          "IF effective_count >= 5: return -0.08",
          "ELSE: return -0.15"
        ]
      },
      "evidence": {
        "validation_n": 40,
        "gt_50_pubs": {
          "n": 28,
          "approvals": 26,
          "crls": 2,
          "approval_rate": 0.929
        },
        "lt_5_pubs": {
          "n": 3,
          "approvals": 1,
          "crls": 2,
          "crl_rate": 0.667
        }
      },
      "expected_impact": {
        "brier_reduction": 0.018
      }
    }
  },
  
  "cews_v2": {
    "version": "2.0",
    "status": "ACTIVE",
    "signals": {
      "CLUSTER_SELL": {
        "condition": ">=3 insiders selling within 30 days",
        "ceo_amplifier": 1.5,
        "penalty": -0.15,
        "override_positive_signals": true
      },
      "EXTREME_SELLING": {
        "condition": "insider_sell_count >= 10 AND insider_buy_count = 0 in 90 days",
        "penalty": -0.20
      },
      "PCR_EXTREME": {
        "condition": "put_call_ratio > 10.0",
        "penalty": -0.25,
        "evidence": "TVTX had 37.59 PCR before delay"
      },
      "CEO_SOLO_SELL": {
        "condition": "CEO sells >$1M within 30 days of PDUFA",
        "penalty": -0.10
      }
    },
    "validation_rate": "100% (2/2 signals validated in Jan 2026)"
  },
  
  "void_signal": {
    "version": "1.0",
    "status": "EXPERIMENTAL",
    "description": "Absence of commercial hiring when company should be preparing for launch",
    "condition": "PDUFA within 6 months AND zero commercial/sales job postings",
    "penalty": -0.08,
    "note": "Requires Indeed MCP integration for systematic detection"
  },
  
  "critical_interactions": {
    "mfg_risk_x_inexperienced": {
      "condition": "(manufacturing_risk=True) AND (experienced_sponsor=False)",
      "approval_rate": 0.536,
      "penalty": -0.331,
      "n": 278
    },
    "exp_x_no_mfg_risk": {
      "condition": "(manufacturing_risk=False) AND (experienced_sponsor=True)",
      "approval_rate": 0.934,
      "bonus": 0.067,
      "n": 664
    },
    "cns_x_inexperienced": {
      "condition": "(therapeutic_area='CNS/Neurology') AND (experienced_sponsor=False)",
      "crl_rate": 0.292,
      "penalty": -0.159,
      "n": 65
    },
    "btd_x_experienced": {
      "condition": "(btd=True) AND (experienced_sponsor=True)",
      "approval_rate": 0.964,
      "bonus": 0.097,
      "n": 169
    }
  },
  
  "crl_reason_distribution": {
    "CMC": {
      "count": 123,
      "percentage": 0.683,
      "note": "Manufacturing/CMC issues are primary CRL driver"
    },
    "CLINICAL": {
      "count": 50,
      "percentage": 0.278,
      "note": "Clinical efficacy/safety issues"
    },
    "SAFETY": {
      "count": 6,
      "percentage": 0.033
    },
    "CMC_CLINICAL": {
      "count": 1,
      "percentage": 0.006
    }
  },
  
  "scoring_thresholds": {
    "buy_signal": {
      "min_poa": 0.70,
      "label": "BUY"
    },
    "avoid_signal": {
      "max_poa": 0.55,
      "label": "AVOID"
    },
    "no_position": {
      "poa_range": [0.55, 0.70],
      "label": "NO_POSITION"
    }
  },
  
  "tier_system": {
    "TIER_1": {
      "condition": "poa >= 0.85",
      "position_size": "FULL"
    },
    "TIER_2": {
      "condition": "0.70 <= poa < 0.85",
      "position_size": "HALF"
    },
    "TIER_3": {
      "condition": "0.55 <= poa < 0.70",
      "position_size": "NONE"
    },
    "TIER_4": {
      "condition": "poa < 0.55",
      "position_size": "AVOID/SHORT"
    }
  },
  
  "smart_money_signals_analyzed": {
    "PRAX": {
      "ticker": "PRAX",
      "asset": "ulixacaltamide",
      "catalyst": "NDA submission early 2026",
      "insider_pattern": "16 sells / 0 buys (6 months)",
      "notable_sale": "General Counsel $4.8M Nov 20, 2025",
      "short_interest": "9.45%",
      "s16_publication_count": 1,
      "s16_signal": "CRITICAL_WARNING (-0.15)",
      "cews_signal": "CLUSTER_SELL",
      "regulatory_status": "BTD granted, Pre-NDA positive",
      "odin_assessment": "MIXED - Strong regulatory path but weak smart money"
    },
    "ERAS": {
      "ticker": "ERAS",
      "asset": "naporafenib",
      "catalyst": "Phase 3 (NOT PDUFA)",
      "status": "DEPRIORITIZED by company - seeking partner",
      "insider_sale": "General Counsel $670K Jan 7, 2026",
      "odin_assessment": "NOT_APPLICABLE - Phase 3 only, company divesting asset"
    }
  },
  
  "optimization_search_space": {
    "description": "Parameters for ChatGPT million-configuration optimization",
    "designation_weights": {
      "btd": {"min": 0.05, "max": 0.15, "step": 0.01},
      "orphan": {"min": 0.01, "max": 0.08, "step": 0.01},
      "priority_review": {"min": 0.03, "max": 0.12, "step": 0.01},
      "fast_track": {"min": 0.03, "max": 0.10, "step": 0.01}
    },
    "sponsor_experience_weight": {"min": 0.03, "max": 0.10, "step": 0.01},
    "manufacturing_risk_penalty": {"min": -0.45, "max": -0.25, "step": 0.02},
    "p003_penalty": {"min": -0.15, "max": -0.05, "step": 0.01},
    "s16_thresholds": {
      "high_pub_threshold": {"min": 40, "max": 100, "step": 10},
      "low_pub_threshold": {"min": 3, "max": 10, "step": 1}
    },
    "cews_penalties": {
      "cluster_sell": {"min": -0.30, "max": -0.10, "step": 0.02},
      "pcr_extreme": {"min": -0.35, "max": -0.15, "step": 0.02}
    },
    "estimated_total_configs": 5000000
  },
  
  "audit_compliance": {
    "t_minus_1_rule": "ENFORCED - All features from T-1 day minimum",
    "append_only_ledger": "REQUIRED",
    "hash_verification": "MANDATORY",
    "no_hindsight_bias": "VERIFIED",
    "outcome_harvest_protocol": "ACTIVE"
  },
  
  "allfather_gates": {
    "pdufa_accuracy": {"threshold": 0.95, "current": 0.902, "status": "NOT_MET"},
    "phase_accuracy": {"threshold": 0.90, "current": 0.85, "status": "NOT_MET"},
    "ma_accuracy": {"threshold": 0.80, "current": "N/A", "status": "NOT_COMPUTABLE"},
    "price_direction": {"threshold": 0.95, "current": 1.00, "status": "MET"},
    "price_magnitude": {"threshold": 0.95, "current": 0.375, "status": "NOT_MET"},
    "overall_status": "ODIN (4/5 gates unmet)"
  }
}

```

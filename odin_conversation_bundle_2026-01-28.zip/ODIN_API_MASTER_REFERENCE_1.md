# ═══════════════════════════════════════════════════════════════════════════════
# ODIN API MASTER REFERENCE — THE NINE REALMS
# ═══════════════════════════════════════════════════════════════════════════════
# 
# Last Updated: January 16, 2026
# Owner: David (rockyshoals@gmail.com)
# Purpose: Centralized reference for all data sources powering ODIN
#
# ═══════════════════════════════════════════════════════════════════════════════

---

## 📊 QUICK REFERENCE

| Category | Paid | Free Gov | Total |
|----------|------|----------|-------|
| Paid Subscriptions | 3 | - | 3 |
| Free Government APIs | - | 25+ | 25+ |
| **Monthly Cost** | **~$115-165** | **$0** | **~$115-165** |

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 1: PAID SUBSCRIPTIONS (YOUR ACTIVE SERVICES)
# ═══════════════════════════════════════════════════════════════════════════════

## 1.1 FinBrain Elite 💰

| Field | Value |
|-------|-------|
| **API Key** | `5813fe19-a03c-4873-a7be-354315c39b80` |
| **Cost** | ~$50-100/month (Elite tier) |
| **Status** | ✅ ACTIVE |
| **Base URL** | `https://api.finbrain.tech/v1/` |

### Endpoints Available:

```python
# AI Price Predictions (10-day forecasts)
GET https://api.finbrain.tech/v1/predictions/{market}/{ticker}
Headers: {"Authorization": "Bearer 5813fe19-a03c-4873-a7be-354315c39b80"}

# News Sentiment (-1 to +1 scores)
GET https://api.finbrain.tech/v1/sentiments/{market}/{ticker}

# Insider Trading (SEC Form 4)
GET https://api.finbrain.tech/v1/insider-transactions/{ticker}

# Congressional Trading
GET https://api.finbrain.tech/v1/house-trades/{ticker}
GET https://api.finbrain.tech/v1/senate-trades/{ticker}

# Analyst Ratings
GET https://api.finbrain.tech/v1/analyst-ratings/{market}/{ticker}

# Put/Call Ratios (Options Flow)
GET https://api.finbrain.tech/v1/putcalldata/{market}/{ticker}

# LinkedIn Hiring Data
GET https://api.finbrain.tech/v1/linkedindata/{market}/{ticker}

# App Ratings (Commercial Stage)
GET https://api.finbrain.tech/v1/appratings/{ticker}
```

### ODIN Integration Uses:
- **F013-b Module**: Insider alpha detection (CEO buys/sells)
- **PCR Module**: Put/call ratio signals (PCR > 5 = bearish)
- **FinBERT**: News sentiment scoring
- **Commercial Realm**: LinkedIn hiring signals, app ratings

---

## 1.2 Financial Modeling Prep (FMP) Elite 💰

| Field | Value |
|-------|-------|
| **API Key** | `kyI0t6mDZD1YBTfxtKZSgkp6eILZR3v6` |
| **Cost** | ~$30/month (Elite tier) |
| **Status** | ✅ ACTIVE |
| **Base URL** | `https://financialmodelingprep.com/api/v3/` |

### Endpoints Available:

```python
# Historical Stock Prices
GET https://financialmodelingprep.com/api/v3/historical-price-full/{ticker}?apikey=kyI0t6mDZD1YBTfxtKZSgkp6eILZR3v6

# Company Profile
GET https://financialmodelingprep.com/api/v3/profile/{ticker}?apikey={API_KEY}

# Financial Statements
GET https://financialmodelingprep.com/api/v3/income-statement/{ticker}?apikey={API_KEY}
GET https://financialmodelingprep.com/api/v3/balance-sheet-statement/{ticker}?apikey={API_KEY}
GET https://financialmodelingprep.com/api/v3/cash-flow-statement/{ticker}?apikey={API_KEY}

# SEC Filings
GET https://financialmodelingprep.com/api/v3/sec_filings/{ticker}?apikey={API_KEY}

# Insider Trading
GET https://financialmodelingprep.com/api/v4/insider-trading?symbol={ticker}&apikey={API_KEY}

# Institutional Holdings
GET https://financialmodelingprep.com/api/v3/institutional-holder/{ticker}?apikey={API_KEY}

# Earnings Calendar
GET https://financialmodelingprep.com/api/v3/earning_calendar?apikey={API_KEY}

# Stock Screener
GET https://financialmodelingprep.com/api/v3/stock-screener?marketCapMoreThan=1000000&apikey={API_KEY}
```

### ODIN Integration Uses:
- **Price Oracle**: Historical price data for backtesting
- **Fundamentals**: Cash runway, market cap for M&A scoring
- **SEC Filings**: 8-K material events, 10-K/Q financials

---

## 1.3 BioPharmCatalyst Elite 💰

| Field | Value |
|-------|-------|
| **API Key** | ⏳ PENDING (contacted support) |
| **Cost** | $35/month (Elite, purchased on sale) |
| **Status** | ✅ ACTIVE (manual CSV export available) |
| **Website** | `https://biopharmcatalyst.com` |

### Data Available (via CSV export until API access):

```
EXPORT LOCATIONS:
- PDUFA Calendar: /calendars/fda-calendar → Export CSV
- Historical Data: /historical → Export CSV (17 years, 13,874 events)
- Phase Readouts: /calendars/clinical-results → Export CSV
- AdCom Dates: /calendars/advisory-committee → Export CSV
```

### Historical Dataset Stats:
| Category | Count | Date Range |
|----------|-------|------------|
| PDUFA Outcomes | 1,943 | 2009-2026 |
| ↳ Approvals | 1,590 | |
| ↳ CRLs | 282 | |
| Phase 3 | 3,350 | 2009-2026 |
| Phase 2 | 3,963 | 2009-2026 |
| Phase 1 | 3,638 | 2009-2026 |
| **TOTAL** | **13,874** | **17 years** |

### ODIN Integration Uses:
- **PDUFA Logic**: Complete approval/CRL training data
- **Phase Logic**: Phase 2/3 success rates by therapeutic area
- **AdCom Module**: Historical vote outcomes

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 2: FREE GOVERNMENT APIs — FDA
# ═══════════════════════════════════════════════════════════════════════════════

## 2.1 OpenFDA API 🏛️ ⭐ CRITICAL

| Field | Value |
|-------|-------|
| **API Key** | `j3eLDwnktH7CPacXZe0HrBaUdMbCBcudUt3iDXoc` |
| **Cost** | FREE |
| **Rate Limit** | 240/minute (with key), 40/minute (without) |
| **Status** | ✅ ACTIVE |
| **Base URL** | `https://api.fda.gov/` |

### Drug Endpoints:

```python
# Drug Approvals (NDA/BLA)
GET https://api.fda.gov/drug/drugsfda.json?api_key={API_KEY}&search=submissions.submission_status_date:[20200101+TO+20261231]&limit=100

# Adverse Events (FAERS)
GET https://api.fda.gov/drug/event.json?api_key={API_KEY}&search=patient.drug.openfda.brand_name:"KEYTRUDA"&limit=100

# Drug Labels
GET https://api.fda.gov/drug/label.json?api_key={API_KEY}&search=openfda.brand_name:"HUMIRA"

# NDC Directory
GET https://api.fda.gov/drug/ndc.json?api_key={API_KEY}&search=brand_name:"OPDIVO"
```

### Device Endpoints:

```python
# 510(k) Clearances
GET https://api.fda.gov/device/510k.json?api_key={API_KEY}&search=decision_date:[20200101+TO+20261231]

# PMA Approvals (Class III)
GET https://api.fda.gov/device/pma.json?api_key={API_KEY}&search=decision_date:[20200101+TO+20261231]

# Device Recalls
GET https://api.fda.gov/device/recall.json?api_key={API_KEY}&search=event_date_terminated:[20200101+TO+20261231]

# Device Registrations
GET https://api.fda.gov/device/registrationlisting.json?api_key={API_KEY}

# Unique Device Identification (UDI)
GET https://api.fda.gov/device/udi.json?api_key={API_KEY}&search=brand_name:"MEDTRONIC"
```

### ODIN Integration Uses:
- **PDUFA Logic**: Drug approval/CRL history mining
- **Device Logic**: 510(k) and PMA catalyst tracking
- **Safety Signals**: Adverse event monitoring (FAERS)
- **CMC Oracle**: Recall data for manufacturing risk

---

## 2.2 Drugs@FDA Data Files 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Update Frequency** | Daily (Mon-Fri) |
| **Download URL** | `https://www.fda.gov/drugs/drug-approvals-and-databases/drugsfda-data-files` |

### Available Tables (drugsatfda.zip):
```
1. Products.txt - Drug products (brand/generic names)
2. Applications.txt - NDA/ANDA/BLA application info
3. Submissions.txt - Submission status (AP/CRL/TA/etc.)
4. SubmissionPropertyType.txt - Property type codes
5. MarketingStatus.txt - Current marketing status
6. TE.txt - Therapeutic equivalence codes
7. ApplicationDocs.txt - Labels, reviews, letters
8. ApplicationsDocsType_Lookup.txt - Document type codes
9. RegActionDate.txt - Regulatory action dates
10. Products (ApplicationDocs+).txt - Linked tables
```

### ODIN Integration Uses:
- **Historical Mining**: Complete NDA/BLA submission history
- **CRL Analysis**: Historical CRL reasons and patterns
- **Label Changes**: Post-approval labeling modifications

---

## 2.3 FDA Inspection Database 🏛️ ⭐ CMC CRITICAL

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | Various FDA databases |

### Form 483 / Warning Letters:
```
# Warning Letters Database
https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/compliance-actions-and-activities/warning-letters

# FDA Inspection Observations (via FOIA)
https://www.fda.gov/about-fda/office-regulatory-affairs/ora-foia-electronic-reading-room

# Import Alerts
https://www.accessdata.fda.gov/cms_ia/ialist.html
```

### ODIN Integration Uses:
- **CMC Oracle**: Form 483 OAI findings = manufacturing risk
- **CRL Prediction**: Active warning letters = elevated CRL risk
- **Geographic Risk**: Import alerts by country/facility

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 3: FREE GOVERNMENT APIs — SEC EDGAR
# ═══════════════════════════════════════════════════════════════════════════════

## 3.1 SEC EDGAR APIs 🏛️ ⭐ CRITICAL

| Field | Value |
|-------|-------|
| **User-Agent** | `ODIN-Research rockyshoals@gmail.com` |
| **Cost** | FREE |
| **Rate Limit** | 10 requests/second |
| **Status** | ✅ ACTIVE |
| **Base URL** | `https://data.sec.gov/` |

### Company Submissions API:
```python
# Get all filings for a company by CIK
GET https://data.sec.gov/submissions/CIK{10-digit-CIK}.json
Headers: {"User-Agent": "ODIN-Research rockyshoals@gmail.com"}

# Example: Apple (CIK: 0000320193)
GET https://data.sec.gov/submissions/CIK0000320193.json
```

### XBRL Financial Data API:
```python
# Company Facts (all XBRL data)
GET https://data.sec.gov/api/xbrl/companyfacts/CIK{10-digit-CIK}.json

# Company Concept (specific metric)
GET https://data.sec.gov/api/xbrl/companyconcept/CIK{CIK}/us-gaap/Assets.json

# XBRL Frames (aggregated across companies)
GET https://data.sec.gov/api/xbrl/frames/us-gaap/Assets/USD/CY2023Q1I.json
```

### Bulk Downloads:
```
# All company facts (nightly)
https://www.sec.gov/Archives/edgar/daily-index/xbrl/companyfacts.zip

# All submissions (nightly)
https://www.sec.gov/Archives/edgar/daily-index/bulkdata/submissions.zip

# Full-text search
https://efts.sec.gov/LATEST/search-index?q=PDUFA&dateRange=custom&startdt=2024-01-01&enddt=2026-01-16
```

### Form-Specific Endpoints:
```python
# Form 4 (Insider Trading) - Parse from submissions
# Look for formType: "4" in submissions response

# Form 8-K (Material Events)
# Look for formType: "8-K" in submissions response

# Form 13F (Institutional Holdings)
# Look for formType: "13F-HR" in submissions response

# Form 13D/G (Activist Investors)
# Look for formType: "SC 13D" or "SC 13G" in submissions response

# Form S-1 (IPO Registration)
# Look for formType: "S-1" in submissions response
```

### ODIN Integration Uses:
- **F013-b Module**: Form 4 insider trading parsing
- **M&A Logic**: 8-K material events (merger announcements)
- **Institutional**: 13F holdings for smart money tracking
- **Fundamentals**: XBRL financial data extraction

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 4: FREE GOVERNMENT APIs — CLINICAL TRIALS
# ═══════════════════════════════════════════════════════════════════════════════

## 4.1 ClinicalTrials.gov API v2.0 🏛️ ⭐ CRITICAL

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Rate Limit** | None specified (be respectful) |
| **Status** | ✅ ACTIVE |
| **Base URL** | `https://clinicaltrials.gov/api/v2/` |
| **Docs** | `https://clinicaltrials.gov/data-api/api` |

### Study Search:
```python
# Search studies by sponsor
GET https://clinicaltrials.gov/api/v2/studies?query.spons=Pfizer&pageSize=100

# Search by condition
GET https://clinicaltrials.gov/api/v2/studies?query.cond=breast+cancer&filter.phase=PHASE3

# Search by NCT ID
GET https://clinicaltrials.gov/api/v2/studies/NCT05678901

# Search with multiple filters
GET https://clinicaltrials.gov/api/v2/studies?query.spons=Moderna&filter.phase=PHASE3&filter.status=COMPLETED&pageSize=50
```

### Study Fields Available:
```
- protocolSection.identificationModule (NCT ID, titles)
- protocolSection.statusModule (status, dates, completion)
- protocolSection.sponsorCollaboratorsModule (sponsor info)
- protocolSection.descriptionModule (brief/detailed description)
- protocolSection.conditionsModule (conditions studied)
- protocolSection.designModule (study design, phases)
- protocolSection.armsInterventionsModule (treatment arms)
- protocolSection.outcomesModule (primary/secondary endpoints)
- protocolSection.eligibilityModule (inclusion/exclusion)
- protocolSection.contactsLocationsModule (sites, contacts)
- resultsSection (if study has posted results)
```

### Results Data (for completed studies):
```python
# Get study with results
GET https://clinicaltrials.gov/api/v2/studies/NCT05678901?fields=resultsSection

# Results include:
# - Participant flow
# - Baseline characteristics
# - Outcome measures (primary/secondary)
# - Adverse events
```

### ODIN Integration Uses:
- **Phase Logic**: Trial enrollment, design, endpoints
- **Readout Dating**: Primary completion dates
- **Safety Signals**: Adverse event reporting
- **Competitor Intel**: Parallel trials in same indication

---

## 4.2 NCI Cancer Clinical Trials API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://clinicaltrialsapi.cancer.gov/api/v2/` |
| **Docs** | `https://clinicaltrialsapi.cancer.gov` |

### Endpoints:
```python
# Search cancer trials
GET https://clinicaltrialsapi.cancer.gov/api/v2/trials?size=50&current_trial_status=Active

# Get specific trial
GET https://clinicaltrialsapi.cancer.gov/api/v2/trials/{nci_id}

# Search by drug
GET https://clinicaltrialsapi.cancer.gov/api/v2/trials?arms.interventions.intervention_name=pembrolizumab
```

### ODIN Integration Uses:
- **Oncology Module**: Cancer-specific trial intelligence
- **NCI Designations**: NCI-designated cancer centers

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 5: FREE GOVERNMENT APIs — NIH/NCBI
# ═══════════════════════════════════════════════════════════════════════════════

## 5.1 PubMed E-utilities API 🏛️ ⭐ NOW ACTIVE

| Field | Value |
|-------|-------|
| **API Key** | `7886c1d64bf5878a0db21e67c94684c89208` |
| **Email** | `rockyshoals@gmail.com` |
| **Cost** | FREE |
| **Rate Limit** | **10 requests/second** (with API key) |
| **Status** | ✅ ACTIVE |
| **Base URL** | `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/` |

### Search Publications:
```python
# Search PubMed (with API key for higher rate limit)
GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=KEYTRUDA+phase+3&retmax=100&retmode=json&api_key=7886c1d64bf5878a0db21e67c94684c89208

# Fetch article details
GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=12345678&retmode=xml&api_key=7886c1d64bf5878a0db21e67c94684c89208

# Search by author (KOL tracking)
GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=Smith+J[Author]&retmax=50&api_key=7886c1d64bf5878a0db21e67c94684c89208

# Search recent publications (last 30 days)
GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=pembrolizumab&datetype=pdat&reldate=30&retmode=json&api_key=7886c1d64bf5878a0db21e67c94684c89208

# Search by journal (NEJM, Lancet, JAMA for high-impact)
GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term="N Engl J Med"[Journal]+AND+oncology&retmax=50&api_key=7886c1d64bf5878a0db21e67c94684c89208

# Get linked data (citations, related articles)
GET https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?dbfrom=pubmed&db=pubmed&id=12345678&linkname=pubmed_pubmed_citedin&api_key=7886c1d64bf5878a0db21e67c94684c89208
```

### Available Databases (via E-utilities):
| Database | db= | ODIN Use |
|----------|-----|----------|
| PubMed | `pubmed` | Publication tracking, KOL activity |
| PMC | `pmc` | Full-text articles |
| Gene | `gene` | Target gene information |
| Protein | `protein` | Target protein data |
| ClinVar | `clinvar` | Genetic variant associations |
| OMIM | `omim` | Disease genetics |
| MeSH | `mesh` | Medical subject headings |

### ODIN Integration Uses:

#### 1. **Pre-Readout Publication Signal** ⭐ HIGH VALUE
- Companies often publish supportive data 2-4 weeks before major readouts
- Search for recent publications by sponsor + drug name
- High-impact journal (NEJM, Lancet, JAMA) = confidence signal
```python
# Example: Monitor for GUTS/Fractyl publications
term = "Fractyl+Health+OR+Revita+DMR+OR+duodenal+mucosal+resurfacing"
```

#### 2. **Key Opinion Leader (KOL) Tracking**
- Track publications by principal investigators on trials
- Increased publication activity = trial progressing well
- Conference abstracts often precede formal readouts

#### 3. **Mechanism of Action Research**
- Validate biological plausibility of drug targets
- Search for preclinical/early clinical publications
- Strong mechanistic data = higher Phase 3 success probability

#### 4. **Competitive Intelligence**
- Monitor competitor publications in same indication
- Track emerging therapies that could impact market

#### 5. **Safety Signal Detection**
- Search for case reports of adverse events
- Post-marketing safety publications

#### 6. **Citation Analysis**
- Highly-cited papers = validated mechanism
- Use elink to find citing articles

---

## 5.2 NIH RePORTER API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://api.reporter.nih.gov/v2/` |
| **Docs** | `https://api.reporter.nih.gov/` |

### Search Grants:
```python
# POST request to search projects
POST https://api.reporter.nih.gov/v2/projects/search
Content-Type: application/json

{
  "criteria": {
    "fiscal_years": [2024, 2025, 2026],
    "org_names": ["PFIZER", "MODERNA"],
    "include_active_projects": true
  },
  "limit": 100,
  "offset": 0
}

# Search by disease
{
  "criteria": {
    "advanced_text_search": {
      "operator": "and",
      "search_field": "terms",
      "search_text": "Alzheimer"
    }
  }
}
```

### ODIN Integration Uses:
- **R&D Pipeline**: NIH-funded research in therapeutic areas
- **Academic Signals**: University research before commercialization
- **Grant Funding**: Funding trends by disease area

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 6: FREE GOVERNMENT APIs — PATENTS (USPTO)
# ═══════════════════════════════════════════════════════════════════════════════

## 6.1 PatentsView API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://search.patentsview.org/api/v1/` |
| **Docs** | `https://patentsview.org/apis/purpose` |

### Search Patents:
```python
# Search by assignee (company)
GET https://search.patentsview.org/api/v1/patent/?q={"_and":[{"assignee_organization":"Pfizer"}]}&f=["patent_number","patent_title","patent_date"]&o={"page":1,"per_page":100}

# Search by CPC class (biotechnology = C12N)
GET https://search.patentsview.org/api/v1/patent/?q={"cpc_subgroup_id":"C12N15/00"}&f=["patent_number","patent_title"]

# Search by inventor
GET https://search.patentsview.org/api/v1/patent/?q={"inventor_last_name":"Smith"}&f=["patent_number","inventor_first_name"]
```

### ODIN Integration Uses:
- **IP Monitoring**: Patent filings before product launches
- **Competitor Intel**: Patent landscape analysis
- **M&A Signals**: Patent portfolio valuations

---

## 6.2 USPTO Patent Examination Data System (PEDS) 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://ped.uspto.gov/api/` |
| **Records** | 9.4+ million |

### Search Applications:
```python
# Search by application number
GET https://ped.uspto.gov/api/queries/searchText?q=applId:(16123456)

# Search by assignee
GET https://ped.uspto.gov/api/queries/searchText?q=appGrpArtNumber:1600+AND+appEntityStatus:UNDISCOUNTED

# Get application details
GET https://ped.uspto.gov/api/queries/applId/16123456
```

### ODIN Integration Uses:
- **Patent Timeline**: Application to grant timelines
- **Exclusivity**: Patent expiry dates for generics

---

## 6.3 USPTO Patent Assignment Search 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://assignment-api.uspto.gov/` |

### Search Assignments:
```python
# Search patent assignments
GET https://assignment-api.uspto.gov/patent/lookup?filter=patentNumber eq '11234567'

# Search by assignee
GET https://assignment-api.uspto.gov/patent/lookup?filter=assigneeName eq 'Pfizer Inc'
```

### ODIN Integration Uses:
- **M&A Signals**: Patent transfers between companies
- **Licensing**: IP licensing deals

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 7: FREE GOVERNMENT APIs — FEDERAL REGISTER
# ═══════════════════════════════════════════════════════════════════════════════

## 7.1 Federal Register API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://www.federalregister.gov/api/v1/` |

### Search Documents:
```python
# Search FDA documents
GET https://www.federalregister.gov/api/v1/documents.json?conditions[agencies][]=food-and-drug-administration&per_page=100

# Search by keyword
GET https://www.federalregister.gov/api/v1/documents.json?conditions[term]=PDUFA&per_page=50

# Search proposed rules
GET https://www.federalregister.gov/api/v1/documents.json?conditions[type][]=PRORULE&conditions[agencies][]=food-and-drug-administration
```

### ODIN Integration Uses:
- **Regulatory Changes**: FDA guidance documents
- **PDUFA Dates**: Official PDUFA goal date publications
- **Policy Signals**: Regulatory environment changes

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 8: FREE GOVERNMENT APIs — ECONOMIC/TRADE
# ═══════════════════════════════════════════════════════════════════════════════

## 8.1 Census Bureau API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE (API key required) |
| **Base URL** | `https://api.census.gov/` |

### ODIN Use: Healthcare spending, demographics for market sizing

---

## 8.2 Bureau of Economic Analysis (BEA) API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE (API key required) |
| **Base URL** | `https://apps.bea.gov/api/` |

### ODIN Use: Healthcare GDP, industry data

---

## 8.3 International Trade Administration API 🏛️

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://developer.trade.gov/` |

### ODIN Use: Export data for pharma manufacturing locations

---

# ═══════════════════════════════════════════════════════════════════════════════
# REALM 9: FREE APIs — OTHER VALUABLE SOURCES
# ═══════════════════════════════════════════════════════════════════════════════

## 9.1 DrugBank (Limited Free) 💊

| Field | Value |
|-------|-------|
| **Cost** | FREE (limited), $1000+/yr (full) |
| **URL** | `https://go.drugbank.com/` |

### ODIN Use: Drug-drug interactions, mechanism of action

---

## 9.2 ChEMBL API (EMBL-EBI) 💊

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://www.ebi.ac.uk/chembl/api/` |

### ODIN Use: Bioactivity data, compound info

---

## 9.3 Open Targets API 💊

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://api.platform.opentargets.org/api/v4/` |

### ODIN Use: Target-disease associations, genetic validation

---

## 9.4 UniProt API 💊

| Field | Value |
|-------|-------|
| **Cost** | FREE |
| **Base URL** | `https://rest.uniprot.org/` |

### ODIN Use: Protein target information

---

# ═══════════════════════════════════════════════════════════════════════════════
# PYTHON CONFIG BLOCK (COPY-PASTE READY)
# ═══════════════════════════════════════════════════════════════════════════════

```python
"""
ODIN API CONFIGURATION
Copy this block into any ODIN script for centralized credential management
"""

ODIN_CONFIG = {
    # ═══════════════════════════════════════════════════════════════════════
    # PAID SUBSCRIPTIONS
    # ═══════════════════════════════════════════════════════════════════════
    "FINBRAIN": {
        "api_key": "5813fe19-a03c-4873-a7be-354315c39b80",
        "base_url": "https://api.finbrain.tech/v1/",
        "tier": "Elite",
        "cost_monthly": 100,
    },
    "FMP": {
        "api_key": "kyI0t6mDZD1YBTfxtKZSgkp6eILZR3v6",
        "base_url": "https://financialmodelingprep.com/api/v3/",
        "tier": "Elite",
        "cost_monthly": 30,
    },
    "BIOPHARMCATALYST": {
        "api_key": None,  # Pending API access
        "base_url": "https://biopharmcatalyst.com/",
        "tier": "Elite",
        "cost_monthly": 35,
        "export_method": "CSV",
    },
    
    # ═══════════════════════════════════════════════════════════════════════
    # FREE GOVERNMENT APIs
    # ═══════════════════════════════════════════════════════════════════════
    "OPENFDA": {
        "api_key": "j3eLDwnktH7CPacXZe0HrBaUdMbCBcudUt3iDXoc",
        "base_url": "https://api.fda.gov/",
        "rate_limit": "240/minute",
        "cost_monthly": 0,
    },
    "SEC_EDGAR": {
        "user_agent": "ODIN-Research rockyshoals@gmail.com",
        "base_url": "https://data.sec.gov/",
        "rate_limit": "10/second",
        "cost_monthly": 0,
    },
    "CLINICALTRIALS": {
        "api_key": None,  # Not required
        "base_url": "https://clinicaltrials.gov/api/v2/",
        "cost_monthly": 0,
    },
    "PUBMED": {
        "api_key": "7886c1d64bf5878a0db21e67c94684c89208",
        "email": "rockyshoals@gmail.com",
        "base_url": "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/",
        "rate_limit": "10/second (with API key)",
        "cost_monthly": 0,
    },
    "NIH_REPORTER": {
        "api_key": None,  # Not required
        "base_url": "https://api.reporter.nih.gov/v2/",
        "cost_monthly": 0,
    },
    "PATENTSVIEW": {
        "api_key": None,  # Not required
        "base_url": "https://search.patentsview.org/api/v1/",
        "cost_monthly": 0,
    },
    "USPTO_PEDS": {
        "api_key": None,  # Not required
        "base_url": "https://ped.uspto.gov/api/",
        "cost_monthly": 0,
    },
    "FEDERAL_REGISTER": {
        "api_key": None,  # Not required
        "base_url": "https://www.federalregister.gov/api/v1/",
        "cost_monthly": 0,
    },
    
    # ═══════════════════════════════════════════════════════════════════════
    # USER IDENTIFICATION
    # ═══════════════════════════════════════════════════════════════════════
    "user_email": "rockyshoals@gmail.com",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36",
}

# Calculate total monthly cost
TOTAL_MONTHLY_COST = sum(
    v.get("cost_monthly", 0) 
    for v in ODIN_CONFIG.values() 
    if isinstance(v, dict)
)
print(f"Total Monthly API Cost: ${TOTAL_MONTHLY_COST}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# RECOMMENDED ADDITIONS (WITHIN YOUR $300 BUDGET)
# ═══════════════════════════════════════════════════════════════════════════════

## Currently Spending: ~$165/month
## Budget Remaining: ~$135/month

### High-Priority Additions:

| Service | Cost | Gap Filled | Priority |
|---------|------|------------|----------|
| **Unusual Whales** | $55/mo | Dark pool, options flow alerts | ⭐⭐⭐ HIGH |
| **ORTEX** | $49/mo | Short interest, cost to borrow | ⭐⭐ MEDIUM |
| **Polygon.io** | $30/mo | Tick-level price data | ⭐ LOW |

### Why Unusual Whales:
- Real-time options flow (currently only have FinBrain PCR)
- Dark pool transactions (institutional positioning)
- Congress trading alerts (they trade biotech!)
- Would complete the "smart money" detection stack

### Why ORTEX:
- Short interest % of float
- Cost to borrow (squeeze potential)
- Days to cover
- Would improve bearish signal detection

---

# ═══════════════════════════════════════════════════════════════════════════════
# API USAGE NOTES
# ═══════════════════════════════════════════════════════════════════════════════

## Rate Limiting Best Practices:
1. Always respect rate limits
2. Cache responses where possible
3. Use exponential backoff on 429 errors
4. Log all API calls for debugging

## T-1 Compliance:
- All data must be timestamped
- Only use data available BEFORE catalyst date
- Mark any estimated/interpolated data clearly

## Error Handling:
```python
def safe_api_call(url, headers=None, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=30)
            if response.status_code == 429:
                wait = 2 ** attempt
                time.sleep(wait)
                continue
            response.raise_for_status()
            return response.json()
        except Exception as e:
            if attempt == max_retries - 1:
                logging.error(f"API call failed after {max_retries} attempts: {e}")
                return None
            time.sleep(2 ** attempt)
    return None
```

---

*"Knowledge is power. APIs are the conduits of knowledge. ODIN sees all."*

**Document Hash:** {sha256 of this file}
**Last Updated:** 2026-01-16

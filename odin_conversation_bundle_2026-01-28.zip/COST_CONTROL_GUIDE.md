# ODIN Cost Control System - Quick Reference Guide

## 🎯 Three Ways to Control Your Spending

### Method 1: Edit Config File Directly (Simplest)
```bash
# Open this file in any text editor:
odin_budget_config.json

# Change these lines:
"daily_limit": 145.00,        # $145/day default
"weekly_limit": 1015.00,      # $1,015/week default
"monthly_limit": 4350.00,     # $4,350/month default

# Save and restart orchestrator - new limits apply immediately
```

### Method 2: Use Preset Budget Levels (Fast)
```python
from odin_cost_control import OdinCostController

controller = OdinCostController()

# One-line commands to switch budgets:
controller.set_spending_level("minimal")      # $15/day - testing
controller.set_spending_level("conservative") # $50/day - light use
controller.set_spending_level("moderate")     # $145/day - default
controller.set_spending_level("aggressive")   # $465/day - full production
```

### Method 3: Set Custom Limits (Full Control)
```python
controller.set_custom_budget(
    daily=200,                          # Your custom daily limit
    weekly=1400,                        # Your custom weekly limit
    monthly=6000,                       # Your custom monthly limit
    ai_limits={
        "openai": 75,                   # ChatGPT limit
        "claude": 60,                   # Claude limit
        "gemini": 40,                   # Gemini limit
        "perplexity": 25                # Perplexity limit
    }
)
```

---

## 📊 Real-Time Budget Tracking

### Display Live Dashboard
```python
controller.print_dashboard()
```

**Output shows:**
- Today's spending breakdown by AI
- % of budget used
- Remaining budget for today/week/month
- Alert thresholds (80% warning)

### Get Summary Data
```python
# Get today's spending
daily = controller.get_daily_summary()
print(f"Today: ${daily['total_cost']:.2f} / ${daily['daily_budget']:.2f}")

# Get this week's spending
weekly = controller.get_weekly_summary()
print(f"Week: ${weekly['total_cost']:.2f} / ${weekly['weekly_budget']:.2f}")

# Get this month's spending
monthly = controller.get_monthly_summary()
print(f"Month: ${monthly['total_cost']:.2f} / ${monthly['monthly_budget']:.2f}")
```

---

## 🚦 Cost Control Behaviors

### What Happens When Budget is Exceeded?

**Auto-Throttle ENABLED (default):**
```python
auto_throttle: true
```
- API calls are **BLOCKED** when budget exceeded
- Call returns: `(cost, allowed=False)`
- Call is logged as "blocked" in database
- You get alert: "Budget limit exceeded"
- Lower-priority tasks are cancelled first (see priority list)

**Auto-Throttle DISABLED:**
```python
auto_throttle: false
```
- API calls go through **even if over budget**
- You get warnings, but spending isn't blocked
- Useful if you want to temporarily override limits

### Enable/Disable Auto-Throttle
```python
# Edit config file:
"auto_throttle": true,    # Enforce limits (default)
"auto_throttle": false,   # Allow overspending with warnings

# Or change in code:
controller.config["auto_throttle"] = False
controller._save_config(controller.config)
```

---

## 🎯 Task Priority System

When budget is tight, lower-priority tasks are cut first:

```python
"task_priority": {
    "pdufa_monitoring": 1,        # 🔴 NEVER cut - must run
    "options_analysis": 2,        # 🟠 Keep this running
    "insider_detection": 3,       # 🟡 Can defer if needed
    "catalyst_confirmation": 4,   # 🟢 Cut this first if needed
    "thesis_updates": 5           # 🟢 Cut this second
}
```

Example: If daily budget exhausted:
1. PDUFA monitoring continues (highest priority)
2. Options analysis continues
3. Insider detection might pause
4. Catalyst confirmation pauses first
5. Long-term thesis updates pause last

---

## 📈 Per-AI Budget Limits

Control how much each AI can spend per day:

```python
"ai_daily_limits": {
    "openai": 50.00,        # ChatGPT max $50/day
    "claude": 40.00,        # Claude max $40/day
    "gemini": 20.00,        # Gemini max $20/day
    "perplexity": 35.00     # Perplexity max $35/day
}
```

If ChatGPT hits $50/day limit:
- ChatGPT calls are blocked
- Other AIs can still run (if they have budget)
- Good for preventing single AI from dominating spend

---

## 🔍 Cost Logging & Audit Trail

All API calls logged to immutable SQLite database:

```bash
odin_spend_tracking.db
```

**What's tracked:**
- Timestamp of every call
- Which AI was called
- Task type (PDUFA monitoring, etc.)
- Input/output tokens
- Actual cost calculated
- Whether call was allowed or blocked

**Query your spend history:**
```python
import sqlite3

conn = sqlite3.connect("odin_spend_tracking.db")
c = conn.cursor()

# See all calls from today
c.execute("""
    SELECT timestamp, ai_platform, cost, status 
    FROM spend_log 
    WHERE DATE(timestamp) = date('now')
""")

for row in c.fetchall():
    print(row)
```

---

## 🚨 Budget Alerts

Two types of alerts triggered:

### Warning Alert (80% of budget)
- Threshold: 80% of daily limit
- Action: Print warning to console
- Behavior: Calls still allowed (but warned)
- Example: If limit is $145, alert at $116

### Hard Block Alert (100% of budget)
- Threshold: 100% of daily limit
- Action: Block call, print alert
- Behavior: Calls rejected until next day
- Example: If limit is $145, block at $145+

Change warning threshold:
```python
"alert_threshold": 0.80,    # Alert at 80% (default)
"alert_threshold": 0.90,    # Alert at 90% (later warning)
"alert_threshold": 0.50,    # Alert at 50% (early warning)
```

---

## 💡 Cost Optimization Tips

### 1. Use Cheaper Models Where Possible
```python
# Use Gemini Flash for simple tasks (60% cheaper)
# Flash: $0.075 input / $0.30 output
# Pro:   $1.25 input / $10.00 output

controller.log_api_call(
    ai_platform="gemini",
    model="flash",  # Cheap for simple parsing
    task_type="sec_filing_parsing",
    input_tokens=5000,
    output_tokens=1000
)
```

### 2. Enable Claude Prompt Caching
```python
# Configure in budget file:
"use_claude_cache_for_repeated_prompts": true

# Same prompt used multiple times?
# Claude caches first 1024 tokens = 75% discount
# Saves 75% on cached input tokens
```

### 3. Batch API Calls
```python
# Bad: 10 individual API calls = 10x overhead
for ticker in tickers:
    await controller.log_api_call(...)

# Good: Batch into 1 call
await controller.log_api_call(
    input_text="Analyze these 10 tickers: " + ", ".join(tickers)
)
```

### 4. Reduce Perplexity Search Depth
```python
# High depth = more searches = higher cost
"perplexity_search_depth": "high"    # Deep research

# Low depth = fewer searches = lower cost
"perplexity_search_depth": "low"     # Quick checks only
```

---

## 📋 Preset Budget Levels

### MINIMAL ($15/day) - Development/Testing
```
Daily: $15 / Weekly: $105 / Monthly: $450
- Testing API integrations
- Small-scale signal validation
- Learning the system
```

### CONSERVATIVE ($50/day) - Light Monitoring
```
Daily: $50 / Weekly: $350 / Monthly: $1,500
- Monitor 2-3 key tickers
- PDUFA tracking only
- No real trading yet
```

### MODERATE ($145/day) - Daily Operations ⭐ RECOMMENDED
```
Daily: $145 / Weekly: $1,015 / Monthly: $4,350
- Monitor 5 tickers actively
- Full Odin suite running
- Multiple signals per day
- Ideal for learning phase
```

### AGGRESSIVE ($465/day) - Full Production
```
Daily: $465 / Weekly: $3,255 / Monthly: $14,000
- Monitor 15-20 tickers
- Real-time signals
- Minute-level monitoring
- Institutional-grade operation
```

---

## 🔄 Daily Budget Reset

Budgets reset automatically at midnight UTC:
- Daily budget resets every 24 hours
- Weekly budget resets every 7 days
- Monthly budget resets every 30 days

Example:
```
Monday: Spend $100 on daily budget
Tuesday: Budget resets to $145, spend counter starts at $0
```

View when budgets reset:
```python
import json
with open("odin_budget_config.json") as f:
    config = json.load(f)
    print(config["last_reset"])
```

---

## 📞 Common Scenarios

### Scenario 1: It's Friday, I've Spent $300 This Week (Limit: $1,015)
```
✅ You have $715 remaining
✅ Calls will be allowed all day Friday
✅ Saturday calls will start fresh weekly count
```

### Scenario 2: It's 3 PM, I've Hit My Daily $145 Limit
```
⚠️  Daily budget exhausted
❌ PDUFA monitoring will continue (priority 1)
❌ Options analysis will continue (priority 2)
❌ Insider detection will pause (priority 3)
❌ Catalyst confirmation paused (priority 4)
✅ Midnight tonight: Budget resets, all services resume
```

### Scenario 3: I Want to Temporarily Increase Budget
```python
# Temporarily boost for this week:
controller.set_custom_budget(daily=300, weekly=2000)

# Monday next week, change back:
controller.set_spending_level("moderate")  # Back to $145/day
```

### Scenario 4: Market Event, I Need Full Production Mode
```python
# One command to activate aggressive spending:
controller.set_spending_level("aggressive")

# Now running at $465/day for maximum signal generation
# Change back after event:
controller.set_spending_level("moderate")
```

---

## ⚙️ Configuration File Location

```
odin_budget_config.json     (Main config - edit here for simple changes)
odin_spend_tracking.db      (Database - read-only, tracks all costs)
odin_cost_control.py        (Code - don't edit unless you know Python)
```

**Simple edits:** Modify JSON config file
**Complex edits:** Use Python methods (set_spending_level, set_custom_budget)

---

## 🎓 Full Code Example

```python
from odin_cost_control import OdinCostController
import asyncio

async def main():
    # Initialize
    controller = OdinCostController()
    
    # Set budget level
    controller.set_spending_level("moderate")
    
    # Make an API call
    cost, allowed = await controller.log_api_call(
        ai_platform="openai",
        model="gpt4o",
        task_type="pdufa_monitoring",
        input_tokens=5000,
        output_tokens=2000
    )
    
    print(f"Cost: ${cost:.4f}")
    print(f"Allowed: {allowed}")
    
    # Check dashboard
    controller.print_dashboard()
    
    # View summaries
    daily = controller.get_daily_summary()
    print(f"\nToday: ${daily['total_cost']:.2f} / ${daily['daily_budget']:.2f}")

asyncio.run(main())
```

---

## 🆘 Troubleshooting

**Q: I'm hitting budget limits too fast**
A: Switch to cheaper models (Gemini Flash), reduce search depth, or increase budget level

**Q: I want to overspend temporarily**
A: Set `"auto_throttle": false` in config, or increase daily_limit temporarily

**Q: Which API costs the most?**
A: Run `controller.print_dashboard()` to see per-AI breakdown

**Q: How do I audit what I spent?**
A: Query `odin_spend_tracking.db` with any SQLite browser

**Q: Can I reset the cost counter mid-day?**
A: Technically yes, but not recommended - corrupts audit trail. Better to change budget level instead.

---

**Ready to deploy?** You're all set. Start with MODERATE budget, monitor for 2-3 days, then adjust based on actual signal quality vs. cost.

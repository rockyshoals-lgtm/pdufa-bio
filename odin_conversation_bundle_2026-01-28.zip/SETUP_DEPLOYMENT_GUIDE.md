# ODIN Cost Control System - Setup & Deployment Guide

## 📦 What You've Got

Three files + one config:

### 1. **odin_cost_control.py** (Core Engine)
- Master cost controller class
- Tracks all API spending
- Enforces budget limits
- Logs to immutable SQLite database
- 500+ lines of production-ready code

### 2. **odin_cost_dashboard.py** (Web Dashboard)
- Real-time web UI
- Budget monitoring
- Quick preset buttons
- Custom limit controls
- Runs on localhost:5000

### 3. **odin_budget_config.json** (Configuration)
- Spending levels (minimal/conservative/moderate/aggressive)
- Daily/weekly/monthly limits
- Per-AI budget limits
- Task priorities
- Auto-throttle settings

### 4. **COST_CONTROL_GUIDE.md** (Reference)
- Complete documentation
- All commands and examples
- Troubleshooting

---

## 🚀 Quick Start (5 minutes)

### Step 1: Install Dependencies
```bash
pip install flask sqlite3
```

### Step 2: Start the Dashboard
```bash
python odin_cost_dashboard.py
```

### Step 3: Open in Browser
```
http://localhost:5000
```

### Step 4: Change Budget Level
Click one of the buttons:
- "Minimal ($15/day)" for testing
- "Conservative ($50/day)" for light use
- "Moderate ($145/day)" for daily operations (recommended)
- "Aggressive ($465/day)" for full production

**That's it!** Dashboard will update in real-time.

---

## 📊 What You Can Do

### In the Dashboard (Web UI)

1. **View Real-Time Spending**
   - Today's breakdown by AI platform
   - Weekly and monthly totals
   - Progress bars showing % of budget used

2. **Change Budget Levels**
   - Click preset buttons for instant changes
   - Custom input fields for exact limits
   - Changes apply immediately

3. **Monitor Per-AI Spending**
   - See how much each AI platform spent
   - Visual bars showing usage vs limits
   - Alerts when approaching limits

### In Your Python Code

```python
from odin_cost_control import OdinCostController
import asyncio

async def main():
    controller = OdinCostController()
    
    # Set budget level
    controller.set_spending_level("moderate")
    
    # Log an API call
    cost, allowed = await controller.log_api_call(
        ai_platform="openai",
        model="gpt4o",
        task_type="pdufa_monitoring",
        input_tokens=5000,
        output_tokens=2000
    )
    
    if not allowed:
        print("Budget exceeded! Call blocked.")
    else:
        print(f"Cost: ${cost:.4f}")
    
    # View dashboard data
    daily = controller.get_daily_summary()
    print(f"Today: ${daily['total_cost']:.2f} / ${daily['daily_budget']:.2f}")
    
    # Print text dashboard
    controller.print_dashboard()

asyncio.run(main())
```

---

## 🎯 Integration with Multi-AI Orchestrator

When building your multi-AI orchestration system, use cost controller like this:

```python
# odin_multi_ai_orchestrator.py

from odin_cost_control import OdinCostController
import asyncio

class OdinOrchestrator:
    def __init__(self):
        self.cost_controller = OdinCostController()
        
    async def dispatch_to_ai(self, task, ai_target):
        """Route task to specific AI"""
        
        # Example: PDUFA monitoring with ChatGPT
        if task['type'] == 'pdufa_monitoring' and ai_target == 'chatgpt':
            
            # Make the API call (your code here)
            input_tokens = 5000
            output_tokens = 2000
            
            # LOG THE COST BEFORE CALLING API
            cost, allowed = await self.cost_controller.log_api_call(
                ai_platform="openai",
                model="gpt4o",
                task_type="pdufa_monitoring",
                input_tokens=input_tokens,
                output_tokens=output_tokens
            )
            
            if not allowed:
                print("❌ Budget exceeded - call blocked")
                return None
            
            # Only call API if allowed
            response = await self._call_openai(task)
            return response
    
    async def autonomous_pdufa_monitor(self):
        """24/7 PDUFA monitoring with cost control"""
        while True:
            # Every 15 minutes
            await self.dispatch_to_ai(
                task={'type': 'pdufa_monitoring'},
                ai_target='chatgpt'
            )
            
            # Check budget status
            daily = self.cost_controller.get_daily_summary()
            if daily['percent_used'] > 80:
                print(f"⚠️  Budget 80% used: ${daily['total_cost']:.2f} / ${daily['daily_budget']:.2f}")
            
            await asyncio.sleep(900)  # 15 min

# Use it:
orchestrator = OdinOrchestrator()
orchestrator.cost_controller.set_spending_level("moderate")
```

---

## 💾 Database Structure

All spending logged to **odin_spend_tracking.db** (SQLite):

### Table: spend_log
```
- timestamp: When the call was made
- ai_platform: Which AI (openai, claude, gemini, perplexity)
- model: Which model (gpt4o, sonnet, pro_25, sonar_pro)
- task_type: What task (pdufa_monitoring, options_analysis, etc.)
- input_tokens: Tokens sent to API
- output_tokens: Tokens received from API
- search_requests: Perplexity searches (if any)
- cost: Calculated cost in USD
- status: 'allowed' or 'blocked'
```

### Table: budget_alerts
```
- timestamp: When alert triggered
- alert_type: 'daily_limit_exceeded', 'budget_warning', etc.
- message: Full alert message
- current_spend: How much was spent
- limit_exceeded: What the limit was
- action_taken: 'blocked_call', 'warning_issued', etc.
```

### Query Examples
```python
import sqlite3

conn = sqlite3.connect("odin_spend_tracking.db")
c = conn.cursor()

# Total spending today
c.execute("SELECT SUM(cost) FROM spend_log WHERE DATE(timestamp) = date('now')")
print(c.fetchone()[0])

# Spending by AI today
c.execute("""
    SELECT ai_platform, SUM(cost) 
    FROM spend_log 
    WHERE DATE(timestamp) = date('now') AND status = 'allowed'
    GROUP BY ai_platform
""")
for row in c.fetchall():
    print(f"{row[0]}: ${row[1]:.2f}")

# Blocked calls
c.execute("SELECT COUNT(*) FROM spend_log WHERE status = 'blocked'")
print(f"Blocked calls: {c.fetchone()[0]}")

conn.close()
```

---

## ⚙️ Configuration Reference

Edit **odin_budget_config.json** to customize:

```json
{
  "spending_level": "moderate",
  
  // Budget limits
  "daily_limit": 145.00,
  "weekly_limit": 1015.00,
  "monthly_limit": 4350.00,
  
  // Warning at 80% of budget
  "alert_threshold": 0.80,
  
  // Block calls when over budget (true = enforce limits)
  "auto_throttle": true,
  
  // Individual AI limits per day
  "ai_daily_limits": {
    "openai": 50.00,
    "claude": 40.00,
    "gemini": 20.00,
    "perplexity": 35.00
  },
  
  // Which AIs to enable/disable
  "enabled_ais": {
    "openai": true,
    "claude": true,
    "gemini": true,
    "perplexity": true
  },
  
  // Task priority (lower number = higher priority)
  // High-priority tasks run even when budget tight
  "task_priority": {
    "pdufa_monitoring": 1,        // MUST RUN
    "options_analysis": 2,         // Keep running
    "insider_detection": 3,        // Can defer
    "catalyst_confirmation": 4,    // Cut first
    "thesis_updates": 5            // Cut last
  }
}
```

---

## 🔄 Workflow: From Data to Decision

```
Multi-AI Orchestrator
    ↓
Call: log_api_call(ai="openai", tokens=5000)
    ↓
Cost Controller: Calculate cost ($0.0175)
    ↓
Check Budget:
  ├─ Daily: $100 spent, $145 limit → ALLOW
  ├─ Per-AI: $45 spent, $50 limit → ALLOW
  └─ Overall: < 80% → NO WARNING
    ↓
Log to Database: INSERT INTO spend_log (allowed)
    ↓
Return: (cost=$0.0175, allowed=True)
    ↓
Orchestrator: Makes the OpenAI API call
    ↓
Result: Stored in Odin database
    ↓
Next Review: 15 minutes later
```

---

## 📈 Example Daily Cycle

**9:00 AM** - Start of trading day
- Budget resets to $145
- PDUFA monitoring starts
- All AIs enabled

**11:00 AM** - Check dashboard
- Spent: $45 (31% of budget)
- All AIs running normally

**2:00 PM** - Major FDA announcement
- Surge in demand for analysis
- Options analysis gets heavier usage
- Still at $120 spent (83% of budget)
- Dashboard shows warning

**3:30 PM** - Approaching limit
- Spent: $140 (97% of budget)
- Auto-throttle activates
- PDUFA monitoring continues (priority 1)
- Options analysis continues (priority 2)
- Insider detection paused (priority 3)
- Catalyst confirmation paused (priority 4)

**4:00 PM** - Market close
- Final spend: $142 (98% of budget)
- Markets close, no more signals needed

**Midnight** - Budget resets
- Daily counter goes to $0
- Next day starts fresh

---

## 🚨 Budget Override (Emergency Mode)

If you MUST spend over budget:

### Option 1: Temporarily Disable Auto-Throttle
```python
controller.config["auto_throttle"] = False
controller._save_config(controller.config)
# Now calls go through even if over budget
# (But alerts will still log)
```

### Option 2: Temporarily Increase Limits
```python
controller.set_custom_budget(daily=500, weekly=3500, monthly=15000)
# Spend more today, revert tomorrow
```

### Option 3: Emergency Mode
```python
# Later, reset back to normal
controller.set_spending_level("moderate")
```

**Note:** All overrides are logged with timestamp, so you have audit trail.

---

## 📞 Troubleshooting

**Q: Dashboard won't start**
A: Install Flask: `pip install flask`

**Q: API calls keep getting blocked**
A: Check dashboard - you've hit your limit. Either:
1. Increase budget level
2. Wait for daily reset (midnight UTC)
3. Set auto_throttle=false temporarily

**Q: Which API costs the most?**
A: Run dashboard, sort by "Per-AI Spending" - Perplexity and Claude are usually highest

**Q: Can I reset spending mid-day?**
A: Not recommended (breaks audit trail), but you CAN increase your budget level instead

**Q: How do I know if I'm getting good ROI?**
A: Compare cost vs. trade profit:
```
Cost: $145/day
Trades: 5 trades/day at $2K profit each = $10K revenue
ROI: 6,800% (before commissions)
```

---

## 🎓 Next Steps

1. **Start Dashboard** - `python odin_cost_dashboard.py`
2. **Set Budget Level** - Click "Moderate" button
3. **Monitor for 2-3 days** - See real spending patterns
4. **Integrate with Orchestrator** - Use log_api_call() in your code
5. **Adjust as needed** - Switch levels based on what you see

---

## 📁 File Checklist

```
Your project folder:
├── odin_cost_control.py          ✅ Core engine
├── odin_cost_dashboard.py        ✅ Web UI
├── odin_budget_config.json       ✅ Configuration
├── COST_CONTROL_GUIDE.md         ✅ Documentation
├── odin_spend_tracking.db        📊 (Auto-created)
└── odin_budget_config.json       ⚙️  (Auto-created)
```

Ready to deploy! 🚀

# ODIN IMPROVEMENT RECOMMENDATIONS: DATA-DRIVEN EVALUATION
## Research Authority Analysis of Perplexity's Action Items

**Date:** 2026-01-26  
**Dataset:** ODIN_ENRICHED_PDUFA_1349_v2.csv (1,349 events, 2020-2026)  
**Author:** ODIN Research Authority

---

# EXECUTIVE SUMMARY

After rigorous empirical analysis of the ODIN dataset against Perplexity's 8 action items, I found:

| Action Item | Perplexity Claim | Data Reality | Verdict |
|-------------|------------------|--------------|---------|
| #1 Manufacturing Risk | May be contaminated with post-PDUFA data | **PARTIALLY VALID** - Not pure leakage but source unclear | ⚠️ INVESTIGATE |
| #2 Specificity Improvement | 41.2% → 55%+ achievable | **VALID** - Current catches 74/180 CRLs, room to improve | ✅ PROCEED |
| #3 Social Signal Deprioritization | Signals have reverse causality | **CANNOT VALIDATE** - Only 4.8% coverage | ⏸️ DEFER |
| #4 AdCom Weight Validation | 28.9pp weight too high | **LIKELY VALID** - Only 49 events, 100% approval rate | ✅ PROCEED |
| #5 Modality-Specific Models | Gene therapy = 74% approval | **CONTRADICTED** - Data shows 93% approval | ❌ REJECT |
| #6 Insider Transaction Signals | +4-7pp specificity improvement | **PLAUSIBLE** - No data to validate | ⏸️ OPTIONAL |
| #7 Time-Series Validation | Check for temporal drift | **VALID** - Minor drift detected (84.2%→89.9%) | ✅ PROCEED |
| #8 Trial Design Features | +3-4pp specificity | **PLAUSIBLE** - Would require new data | ⏸️ OPTIONAL |

**RECOMMENDED PRIORITY:**
1. **CRITICAL:** Action Item #1 (Manufacturing Risk Source Verification)
2. **HIGH:** Action Item #2 (Specificity Optimization) 
3. **HIGH:** Action Item #4 (AdCom Weight Validation)
4. **MEDIUM:** Action Item #7 (Time-Series Validation)
5. **DEFER:** Action Items #3, #5, #6, #8

---

# DETAILED ANALYSIS BY ACTION ITEM

---

## ACTION ITEM #1: Manufacturing Risk Source Verification

### Perplexity's Claim
> "manufacturing_risk feature may be contaminated with post-PDUFA CRL information"
> "20-30pp performance overstatement if data leakage exists"

### Empirical Findings

**Distribution:**
```
manufacturing_risk=TRUE:  285 rows (21.1%)
manufacturing_risk=FALSE: 1,064 rows (78.9%)
```

**Cross-Tabulation with Outcome:**
```
                 APPROVAL    CRL    CRL_Rate
manufacturing_risk
TRUE                 149    136      47.7%
FALSE              1,020     44       4.1%
```

**Key Observation:** Manufacturing risk shows an 11.6x CRL rate lift (47.7% vs 4.1%). This is extremely predictive.

**Leakage Check:** Manufacturing_risk=TRUE AND outcome=APPROVAL exists for **149 rows**. This proves the feature is NOT purely derived from CRL outcome.

**Source Distribution:**
```
enrichment_source      Total   CRLs   CRL_Rate
rule_based_v1            224    123     54.9%
web_search_batch1          3      3    100.0%
web_verified_v2           58     10     17.2%
```

**Concern:** The `rule_based_v1` source has 54.9% CRL rate with 224 rows - this is suspiciously high. We need to verify what rule assigned manufacturing_risk without using post-PDUFA information.

**Sample Approved Drugs with manufacturing_risk=TRUE:**
```
GMAB | DARZALEX using ENHANZE         | Antibody | APPROVAL
HALO | DARZALEX using ENHANZE         | Antibody | APPROVAL
RARE | CRYSVITA (burosumab)           | Antibody | APPROVAL
VTRS | Hulio (adalimumab-fkjp)        | Antibody | APPROVAL
```

**Pattern Detected:** Manufacturing risk appears to correlate with modality complexity:
```
Modality           MfgRisk_Rate
ADC                    100.0%
Cell/Gene Therapy       64.9%
RNA Therapy             63.4%
Vaccine                 62.5%
Antibody                27.5%
Small Molecule          12.4%
Peptide                  8.0%
```

### Verdict: ⚠️ INVESTIGATE FURTHER

**Finding:** Manufacturing_risk is NOT pure leakage (149 approved drugs have it), but the 11.6x lift is unusually strong. The source appears to be a modality-based rule (`rule_based_v1`) rather than post-PDUFA CRL reasons.

**Recommendation:** 
1. Document the exact rule used to derive manufacturing_risk
2. If based on modality complexity (which is T-1 compliant), KEEP as-is
3. If any rows derive from post-PDUFA CRL letters, REMOVE those rows

**Time Estimate:** 2-4 hours

---

## ACTION ITEM #2: Improve Specificity (CRL Detection)

### Perplexity's Claim
> "Current: 41.2% specificity (catches only 41% of CRLs)"
> "Target: 55-60% specificity without precision dropping below 85%"

### Empirical Findings

**Current Baseline:**
```
Total APPROVALs: 1,169 (86.7%)
Total CRLs: 180 (13.3%)

If model predicts ALL=APPROVAL:
- Specificity = 0%
- Precision = 86.7%

Current Claimed (41.2% specificity):
- Catches 74 of 180 CRLs
- Misses 106 CRLs (false negatives)

Target (55% specificity):
- Would catch 99 of 180 CRLs
- Improvement: +25 more CRLs detected
```

**CRL Concentration by Therapeutic Area:**
```
Area               CRL_Rate   Total
Pain Management      41.9%      31
Hematology           35.7%      14
Nephrology           31.0%      29
Ophthalmology        26.5%      34
CNS/Neurology        23.2%      95
Cardiovascular       21.4%      42
```

**CRL Drivers (from prior_crl_reason):**
```
CMC:      123 (68.3%)
CLINICAL:  50 (27.8%)
SAFETY:     6 (3.3%)
```

### Verdict: ✅ PROCEED

**Finding:** The data supports improving specificity. Pain Management (41.9% CRL rate) and CNS (23.2%) are key areas where CRL prediction can improve.

**Recommendation:**
1. Implement proposed objective weight changes:
   ```
   specificity: 0.35 → 0.50 (+43%)
   precision: 0.10 → 0.05 (-50%)
   ```
2. Run 100M config optimization
3. Validate on hold-out 2025-2026 data

**Expected Trade-off:**
- Specificity: 41% → 55% (catch 25 more CRLs)
- Precision: 89% → 85-87%
- This is a favorable trade for options trading (better put protection)

**Time Estimate:** 8-12 hours

---

## ACTION ITEM #3: Separate Social Sentiment Signals (S17-S20)

### Perplexity's Claim
> "S17-S20 likely have reverse causality (sentiment reacts to news, not predictive)"
> "Current weights: S19 = -0.183 (-18.3pp penalty) ← VERY STRONG"

### Empirical Findings

**Critical Finding:** Social sentiment columns (s17, s18, s19, s20) are **NOT IN THE DATASET**.

```
Social sentiment columns in dataset: 0
s17_social_sentiment: NOT IN DATASET
s18_engagement_spike: NOT IN DATASET
s19_social_silence: NOT IN DATASET
s20_smart_money_divergence: NOT IN DATASET
```

**LunarCrush Cache Status:**
```
Tickers with LunarCrush data: 14 / 294 (4.8%)

Classification Distribution:
- BULLISH: 3 (IBRX, MRNA, REGN)
- NEUTRAL: 10
- BEARISH: 1 (SRPT)
```

### Verdict: ⏸️ DEFER

**Finding:** Cannot validate social signal effectiveness because:
1. Social signals are not in the main dataset
2. Only 4.8% of tickers have LunarCrush data
3. The LunarCrush data is point-in-time (Jan 2026), not historical

**Recommendation:**
1. Complete LunarCrush enrichment for remaining 280 tickers
2. Retroactively collect T-1 social data for historical validation
3. Only then can we test causality

**Time Estimate:** BLOCKED until enrichment complete

---

## ACTION ITEM #4: AdCom Weight Validation

### Perplexity's Claim
> "w_adcom = 0.289 (+28.9pp bonus) seems high, needs empirical validation"
> "Empirical weight may be ~9pp, not 29pp"

### Empirical Findings

**AdCom Distribution:**
```
Events with AdCom: 49 (3.6% of dataset)
Events with AdCom vote %: 49 (all have votes)
```

**AdCom Vote → FDA Outcome:**
```
Vote Range    Events    Approved    CRL    Approval%
100%            44          44       0      100.0%
70-80%           4           4       0      100.0%
0-50%            1           1       0      100.0%
```

**Critical Finding:** Every single AdCom event in the dataset resulted in APPROVAL. Even the 0-50% vote case was approved.

**Empirical Calculation:**
```
Baseline approval rate: 86.7%
With AdCom (any vote): 100% approval (49/49)
Empirical lift: +13.3pp (not +28.9pp)
```

### Verdict: ✅ PROCEED

**Finding:** The +28.9pp AdCom weight is likely overfit to the 49 events. The empirical lift is ~13pp, not 29pp. However, the sample size is too small (49 events, 0 CRLs) to draw strong conclusions.

**Important Context:** The dataset only covers 2020-2026. Historically, AdCom has had more negative votes. The current data may reflect FDA's improved pre-AdCom screening.

**Recommendation:**
1. Reduce AdCom weight from 0.289 to ~0.15 (more conservative)
2. Consider removing AdCom signal if validation fails
3. Search for historical AdCom data (pre-2020) to expand sample

**Time Estimate:** 4-6 hours

---

## ACTION ITEM #5: Modality-Specific Models

### Perplexity's Claim
> "Gene therapy approval rate: 74.3% (lower base rate)"
> "Gene therapy: Higher CMC penalty (-0.50 vs -0.18)"

### Empirical Findings

**Modality Distribution & Outcomes:**
```
Modality            Total    Approval%   CRL_Rate
Small Molecule        822      84.9%      15.1%
Antibody              386      88.1%      11.9%
Cell/Gene Therapy      57      93.0%       7.0%  ← CONTRADICTS PERPLEXITY
RNA Therapy            41      92.7%       7.3%
Peptide                25      88.0%      12.0%
Vaccine                16     100.0%       0.0%
ADC                     2     100.0%       0.0%
```

**Critical Contradiction:** Perplexity claims gene therapy has 74.3% approval rate. **The actual data shows 93.0% approval rate** for Cell/Gene Therapy - one of the HIGHEST modalities.

**Sample Gene Therapy Events:**
```
Ticker   Asset                                      Outcome
GILD     TECARTUS (brexucabtagene autoleucel)      APPROVAL
VTRS     Dimethyl fumarate (generic)               APPROVAL
BMRN     Valoctocogene roxaparvovec (BMN 270)      CRL
BMY      BREYANZI (lisocabtagene maraleucel)       APPROVAL
GILD     YESCARTA - Axicabtagene ciloleucel        APPROVAL
BMY      ABECMA (idecabtagene vicleucel)           APPROVAL
LEGN     CARVYKTI (ciltacabtagene autoleucel)      APPROVAL
```

### Verdict: ❌ REJECT

**Finding:** Perplexity's recommendation is based on incorrect data. Gene therapy does NOT have a lower approval rate in our dataset - it has one of the HIGHEST (93.0%).

**Hypothesis for Discrepancy:** 
1. Perplexity may be citing older/broader literature
2. The 2020-2026 period may represent a "golden age" for gene therapy approvals
3. CAR-T therapies (which dominate our gene therapy category) have high approval rates

**Recommendation:** Do NOT implement modality-specific models based on faulty assumptions. The current global model is appropriate.

**Time Estimate:** 0 hours (do not implement)

---

## ACTION ITEM #6: Insider Transaction Signals

### Perplexity's Claim
> "Target improvement: +4-7pp specificity, +2-3pp precision"
> "Integrate SEC EDGAR API for Form 4 filings"

### Empirical Findings

**No existing data to validate.** The ODIN dataset does not contain insider transaction signals.

**Plausibility Assessment:**
- Insider selling before CRL is a known pattern in biotech
- SEC Form 4 data is T-1 compliant (must be filed within 2 business days)
- FinBrain API already provides insider transaction data

### Verdict: ⏸️ OPTIONAL

**Finding:** Cannot validate improvement claims without historical insider data. The concept is sound, but implementation would require significant data collection.

**Recommendation:**
1. Deprioritize until core optimizations complete
2. If implemented, start with FinBrain API (already integrated)
3. Validate on 50 recent events before full deployment

**Time Estimate:** 6-10 hours (optional)

---

## ACTION ITEM #7: Time-Series Validation

### Perplexity's Claim
> "Identify temporal drift, ensure model generalizes across decades"

### Empirical Findings

**Year-over-Year Approval Rates:**
```
Year    Total   Approved   CRL    Rate     YoY_Δ
2020      190       160     30   84.2%      N/A
2021      219       188     31   85.8%    +1.6pp
2022      176       149     27   84.7%    -1.1pp
2023      258       217     41   84.1%    -0.6pp
2024      276       249     27   90.2%    +6.1pp  ← Spike
2025      227       204     23   89.9%    -0.3pp
2026        3         2      1   66.7%   -23.2pp  ← Too early
```

**Observations:**
1. **2020-2023:** Stable approval rate (84-86%)
2. **2024-2025:** Elevated approval rate (89-90%)
3. **2024 Spike:** +6.1pp jump - potential FDA policy shift or drug mix change

**Temporal Drift Assessment:**
```
Period          Approval Rate   Notes
2020-2023       84.7% avg       Pre-improvement baseline
2024-2025       90.0% avg       Recent elevated rate
Drift:          +5.3pp          Moderate positive drift
```

### Verdict: ✅ PROCEED

**Finding:** Moderate temporal drift detected. The 2024-2025 approval rate is ~5pp higher than 2020-2023. This could indicate:
1. FDA policy became more permissive
2. Drug quality improved (better preclinical/clinical work)
3. Easier drugs advanced first during COVID backlog

**Recommendation:**
1. Implement walk-forward validation
2. Add recency weighting if performance degrades on recent data
3. Monitor 2026 events for trend confirmation

**Time Estimate:** 4-6 hours

---

## ACTION ITEM #8: Clinical Trial Design Feature Engineering

### Perplexity's Claim
> "Target improvement: +3-4pp specificity"
> "Extract trial metadata from ClinicalTrials.gov"

### Empirical Findings

**No existing data to validate.** The ODIN dataset does not contain trial design features (enrollment size, masking, endpoint type).

**Plausibility Assessment:**
- Underpowered trials are a known CRL risk factor
- Trial design is T-1 compliant (designed before PDUFA)
- ClinicalTrials.gov API is available via MCP connector

### Verdict: ⏸️ OPTIONAL

**Finding:** Conceptually valid but requires 12-16 hours of data collection and validation. Lower priority than core optimizations.

**Recommendation:**
1. Deprioritize until Action Items #1, #2, #4 complete
2. Start with high-CRL therapeutic areas (Pain Management, CNS)
3. Focus on enrollment size and endpoint type as initial features

**Time Estimate:** 12-16 hours (optional, after core items)

---

# PRIORITIZED IMPLEMENTATION ROADMAP

## Phase 1: CRITICAL PATH (Week 1)

### 1.1 Manufacturing Risk Audit (2-4 hours)
**Status:** ⚠️ REQUIRED BEFORE OTHER WORK

**Tasks:**
- [ ] Document the `rule_based_v1` logic that assigned manufacturing_risk
- [ ] Verify all TRUE rows have pre-PDUFA sources
- [ ] If modality-based (which is T-1 compliant), document and KEEP
- [ ] If CRL-derived, remove affected rows and retrain

**Output:** `ODIN_MANUFACTURING_RISK_SOURCE_AUDIT.md`

### 1.2 Specificity Optimization (8-12 hours)
**Status:** ✅ PROCEED

**Tasks:**
- [ ] Update objective weights in optimizer
- [ ] Run 100M config optimization
- [ ] Validate on 2025-2026 hold-out data
- [ ] If successful, update champion config

**Output:** `ODIN_v9_SPECIFICITY_CHAMPION.json`

## Phase 2: HIGH PRIORITY (Week 2)

### 2.1 AdCom Weight Validation (4-6 hours)
**Status:** ✅ PROCEED

**Tasks:**
- [ ] Create AdCom vote → outcome matrix
- [ ] Calculate empirical AdCom lift (~13pp)
- [ ] Test reduced weight (0.289 → 0.15)
- [ ] Validate on hold-out data

**Output:** `ODIN_ADCOM_VALIDATION_REPORT.md`

### 2.2 Time-Series Validation (4-6 hours)
**Status:** ✅ PROCEED

**Tasks:**
- [ ] Implement walk-forward validation
- [ ] Train on 2020-2023, test on 2024-2025
- [ ] Document temporal drift (+5.3pp)
- [ ] Recommend recency weighting if needed

**Output:** `ODIN_TEMPORAL_VALIDATION_REPORT.md`

## Phase 3: DEFERRED (Week 3+)

### 3.1 Social Signal Validation (BLOCKED)
**Status:** ⏸️ BLOCKED on LunarCrush enrichment

**Blocker:** Only 4.8% ticker coverage. Cannot validate until enrichment complete.

### 3.2 Modality-Specific Models (REJECTED)
**Status:** ❌ DO NOT IMPLEMENT

**Reason:** Based on faulty assumption. Gene therapy has 93% approval rate in our data, not 74%.

### 3.3 Insider Signals & Trial Design (OPTIONAL)
**Status:** ⏸️ DEFER until core items complete

---

# KEY CONTRADICTIONS FOUND

## Perplexity vs Reality

| Claim | Perplexity | ODIN Data | Discrepancy |
|-------|-----------|-----------|-------------|
| Gene therapy approval | 74.3% | 93.0% | **+18.7pp** |
| AdCom empirical lift | ~9pp | ~13pp (100% approval) | Sample too small |
| Social signals | Active and overweighted | Not in dataset | Cannot validate |
| Temporal drift | Significant concern | +5.3pp (moderate) | Less severe than claimed |

---

# FINAL RECOMMENDATIONS

## DO NOW (Priority 1-2)
1. **Audit manufacturing_risk source** - Critical for model validity
2. **Optimize for specificity** - Clear opportunity to catch more CRLs
3. **Validate AdCom weight** - Likely overfit

## DO LATER (Priority 3-4)
4. **Time-series validation** - Document temporal drift
5. **Complete LunarCrush enrichment** - Enable social signal validation

## DO NOT DO
6. **Modality-specific models** - Based on incorrect assumptions
7. **Insider/Trial features** - Low ROI for complexity

---

# APPENDIX: DATA TABLES

## A. Complete Outcome Distribution
```
APPROVAL: 1,169 (86.7%)
CRL: 180 (13.3%)
Total: 1,349 events
```

## B. Therapeutic Area CRL Rates
```
Pain Management:     41.9% (13/31)
Hematology:          35.7% (5/14)
Nephrology:          31.0% (9/29)
Ophthalmology:       26.5% (9/34)
CNS/Neurology:       23.2% (22/95)
Cardiovascular:      21.4% (9/42)
Metabolic/Endocrine: 20.0% (6/30)
Rare Disease:        17.6% (12/68)
Other:               15.2% (48/315)
Immunology:          11.8% (10/85)
Oncology:             7.3% (29/400)
Infectious Disease:   3.0% (4/132)
Respiratory:          4.3% (1/23)
Dermatology:         10.5% (2/19)
GI/Hepatology:        6.7% (1/15)
```

## C. Designation Effectiveness
```
Designation      With Rate   Without Rate   Lift
BTD              95.1%       84.8%         +10.3pp
Experienced      92.4%       81.0%         +11.4pp
Priority Review  90.4%       83.5%          +7.0pp
Fast Track       90.9%       84.3%          +6.6pp
Orphan           89.1%       85.9%          +3.2pp
```

---

**Report Generated:** 2026-01-26
**Author:** ODIN Research Authority
**Dataset Version:** ODIN_ENRICHED_PDUFA_1349_v2.csv

# PDUFA Catalyst Trading Cheat Sheet
## Quick Reference Card

---

## ⚡ THE CARDINAL RULE
```
╔══════════════════════════════════════════════════════╗
║  NEVER HOLD THROUGH FDA DECISION - EXIT BY T-7      ║
╚══════════════════════════════════════════════════════╝
```

---

## 📅 Trading Timeline

```
T-60 to T-45    │ ENTRY WINDOW - Screen & position
                │
T-45 to T-20    │ HOLD - Monitor, no changes
                │
T-20 to T-10    │ PREPARE EXIT - Watch for early signals
                │
T-10 to T-7     │ EXIT WINDOW - Close all positions
                │
T-7 to T-0      │ NO EXPOSURE - Binary risk zone
```

---

## ✅ Entry Checklist

Before entering ANY PDUFA position:

- [ ] PDUFA date confirmed from FDA source
- [ ] Market cap $100M - $2B
- [ ] NDA/BLA (not sNDA)
- [ ] Options available (OI ≥500)
- [ ] ODIN tier 1 or 2 (≥70% probability)
- [ ] No active CRL early warning signals
- [ ] Position size ≤5% portfolio

---

## 🚨 CRL Early Warning Signals

**Exit/Short if ≥3 present:**

| Signal | How to Check |
|--------|-------------|
| IV30 > IV90 (term inversion) | Options chain |
| Discretionary insider sales >60% | SEC Form 4 |
| CEO/CFO sold within T-14 | SEC Form 4 |
| Price peaked T-15, declining | Price chart |
| >50% sales in final 2 weeks | SEC Form 4 |

---

## 🎯 ODIN Tier Targets

| Tier | Probability | Action | Size |
|------|-------------|--------|------|
| **1** | ≥85% | Aggressive | 5% |
| **2** | 70-85% | Standard | 3% |
| **3** | 55-70% | Cautious | 2% |
| **4** | <55% | AVOID/Short | 0% |

---

## ⚠️ HIGH RISK Therapeutic Areas (AVOID)

| TA | CRL Rate | Note |
|----|----------|------|
| Pain Management | 42% | HIGHEST RISK |
| Hematology | 36% | |
| Nephrology | 31% | |
| Ophthalmology | 27% | |

---

## ✨ LOW RISK Therapeutic Areas (FAVOR)

| TA | CRL Rate | Note |
|----|----------|------|
| Vaccines | 0% | SAFEST |
| Infectious Disease | 3% | |
| Oncology | 7% | High volume |
| Cell/Gene | 7% | But CMC risk |

---

## 💰 Position Sizing Rules

```
Single event:     Max 5%
Total catalysts:  Max 25%
Concurrent:       Max 5 positions
Stop loss:        15-20%
Profit target:    Take 50% @ +20%
```

---

## 📊 Vol-Expansion Straddle Quick Guide

```
ENTRY:  IV30 < 60% (or <30th percentile)
        Buy ATM straddle, 2-3 month expiry
        Size: 3% max

TARGET: IV doubles → ~100% straddle gain

EXIT:   T-10 to T-7 (no exceptions)

STOP:   -20% straddle value
```

---

## 🔍 Data Sources Quick Links

| Need | Source |
|------|--------|
| PDUFA Calendar | biopharmcatalyst.com |
| Insider Sales | sec.gov/cgi-bin/browse-edgar |
| Drug Details | accessdata.fda.gov/scripts/cder/daf |
| Social Sentiment | LunarCrush (ODIN enriched) |
| Price Data | Yahoo Finance / FMP |

---

## 📈 Example: Quick Trade Math

**Entry:** $10 stock @ T-45  
**Exit:** $11.80 @ T-10 (after 18% runup)  
**Outcome:** FDA approves, stock gaps to $14  

```
You captured: $1.80 (18% of $10)
You "missed": $2.20 (additional 22%)
You avoided:  -$5.00 risk (50% gap on CRL)

Risk-adjusted, you won.
```

---

## 🚫 NEVER Do These

1. ❌ Hold through PDUFA decision
2. ❌ Average down on catalyst positions
3. ❌ Chase entry after T-30
4. ❌ Exceed 5% on single event
5. ❌ Trade without verifying official PDUFA date
6. ❌ Rely on stop losses (gap risk)
7. ❌ Short BTD+Orphan+Priority stacks

---

## ✅ ALWAYS Do These

1. ✓ Exit T-10 to T-7
2. ✓ Verify PDUFA from FDA source
3. ✓ Check ODIN tier before sizing
4. ✓ Review insider filings T-30 to T-1
5. ✓ Monitor IV evolution weekly
6. ✓ Keep 50% cash reserve
7. ✓ Document every trade rationale

---

*Print this. Tape it to your monitor.*

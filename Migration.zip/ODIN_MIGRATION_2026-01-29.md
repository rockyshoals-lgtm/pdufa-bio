# ODIN Migration File - 2026-01-29

**Session:** PDUFA Dataset Enrichment v4
**Status:** COMPLETE
**Next Priority:** Backtest v9.1 on enriched dataset

---

## What Was Accomplished This Session

### Dataset Enrichment (v3 → v4)
Successfully enriched the PDUFA backtest dataset from **1,349 to 1,906 events** (+41%):

| Component | Events Added | Source |
|-----------|--------------|--------|
| Original dataset | 1,349 | BioPharmCatalyst (2020-2026) |
| Historical CRLs | +151 | FDA CRL Transparency Database (2002-2019) |
| Historical Approvals | +404 | FDA NME Compilation (2009-2019) |
| 2026 Events | +2 | Web research (ATRA CRL, BHVN CRL) |

### Key Files Created
```
/home/claude/ODIN_ENRICHED_PDUFA_v4.csv      # Final enriched dataset (1,906 events)
/home/claude/ODIN_ENRICHMENT_REPORT_v4.md   # Comprehensive report
/home/claude/fda_crl_enrichment.csv          # Raw FDA CRL data (400 records)
/home/claude/fda_pre2020_approvals.csv       # Raw FDA NME approvals (404 records)
/home/claude/pre_2020_approvals_odin.csv     # ODIN-formatted pre-2020 approvals
/home/claude/pre_2020_crls_enrichment.csv    # ODIN-formatted pre-2020 CRLs
```

---

## Current Dataset Statistics (v4)

### Overall
- **Total Events:** 1,906
- **Approvals:** 1,573 (82.5%)
- **CRLs:** 333 (17.5%)
- **Year Coverage:** 2002-2026
- **Unique Companies:** 617

### By Era (Important for Training)
| Period | Events | CRL Rate | Usage |
|--------|--------|----------|-------|
| 2020-2026 | 1,351 | 13.5% | Primary training (balanced) |
| 2009-2019 | 555 | 27.2% | Supplementary (inflated CRL rate) |

### Therapeutic Area CRL Rates (2020+ Unbiased)
| TA | CRL Rate | Risk Tier |
|----|----------|-----------|
| Pain Management | 41.9% | HIGH |
| Hematology | 35.7% | HIGH |
| Nephrology | 31.0% | HIGH |
| Ophthalmology | 26.5% | HIGH |
| CNS/Neurology | 24.0% | MODERATE |
| Cardiovascular | 21.4% | MODERATE |
| Oncology | 7.5% | LOW |
| Infectious Disease | 3.0% | LOW |
| Vaccines | 0.0% | LOW |

---

## Project Files in /mnt/project/

| File | Description |
|------|-------------|
| ODIN_ENRICHED_PDUFA_1349_v2.csv | Original dataset (pre-enrichment) |
| ODIN_v91_CHAMPION_CONFIG.json | Current champion configuration |
| odin_v91_config.py | Python implementation with TA adjustments |
| lunarcrush_cache.json | Social sentiment data (14 tickers) |
| LUNARCRUSH_ENRICHMENT_PROGRESS.md | Social enrichment status |

---

## ODIN v9.1 Champion Performance

```json
{
  "brier_score": 0.08864,
  "tier1_approval_rate": 95.6%,
  "tier4_crl_rate": 85.7%,
  "crl_recall_at_85": 76.7%
}
```

Key insight: TA adjustment weight of 83% optimal for historical rates.

---

## Immediate Next Steps

### 1. Backtest v9.1 on Enriched Dataset
```python
# Load enriched dataset
df = pd.read_csv('/home/claude/ODIN_ENRICHED_PDUFA_v4.csv')

# Filter to balanced era for unbiased metrics
df_balanced = df[df['year'] >= 2020]  # 1,351 events

# Run v9.1 scoring and calculate Brier
```

### 2. Continue LunarCrush Enrichment
- 14/294 tickers cached (4.8%)
- Priority: LLY, AZN, AMGN, JNJ, PFE, BIIB, NVO, VRTX
- Use: `LunarCrush:Topic` tool for each ticker

### 3. Validate Supply Chain Signals
- RCKT (Mar 28) - 100% survival Phase 1/2
- DNLI (Apr 5) - Lonza shipment monitoring
- Check Panjiva/ImportYeti for CMO activity

---

## 2026 PDUFA Calendar (Confirmed)

| Date | Ticker | Drug | Indication | Status |
|------|--------|------|------------|--------|
| Jan 10 | ATRA | Tabelecleucel | EBV+ PTLD | **CRL** |
| Jan 13 | TRVN | Filspari | FSGS | Pending |
| Jan 31 | AQST | Anaphylm | Anaphylaxis | Pending |
| Feb 8 | RGNX | RGX-121 | Hunter syndrome | Pending |
| Mar 16 | ALDX | Reproxalap | Dry eye | Pending |
| Mar 20 | RYTM | Imcivree | Hypothalamic obesity | Pending |
| Mar 28 | RCKT | Kresladi | LAD-I | Pending |
| Apr 6 | ORCA | Orca-T | AML/ALL/MDS | Pending |

---

## API Keys Available (from env)

- FINBRAIN_API_KEY
- FMP_API_KEY  
- LUNARCRUSH_API_KEY
- PATENTSVIEW_API_KEY
- OPENFDA_API_KEY
- CENSUS_API_KEY
- FDA_OIIWEB_API_KEY
- OPENAI_API_KEY
- GEMINI_API_KEY

---

## Resume Instructions

1. Upload this migration file to new chat
2. Upload ODIN_ENRICHED_PDUFA_v4.csv (or reference /mnt/project/ version if updated)
3. Say: "Continue ODIN development from migration file"

### Priority Tasks
- [ ] Backtest v9.1 on v4 dataset
- [ ] Run GPU optimization with expanded CRL examples
- [ ] Continue LunarCrush social sentiment collection
- [ ] Validate RCKT/DNLI supply chain signals

---

## Technical Notes

### Pre-2020 Data Bias Warning
The pre-2020 data shows 27.2% CRL rate vs 13.5% for 2020+. This is due to:
1. FDA CRL database may not capture all historical CRLs
2. FDA NME compilation only includes novel approvals (not all PDUFAs)
3. Early years have sparse data

**Recommendation:** Use 2020-2026 data for CRL rate calculations. Use pre-2020 as supplementary CRL training examples with sample weights.

### T-1 Compliance
All features are T-1 compliant:
- Designations (BTD, Orphan, etc.) - assigned before PDUFA
- AdCom votes - occur before decision
- Sponsor experience - count of prior approvals before event
- TA adjustments - based on historical rates, not current event

---

*Migration file created: 2026-01-29 02:52 UTC*
